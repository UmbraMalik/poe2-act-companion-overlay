"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROJECT_FEEDBACK_URL = void 0;
exports.getReportTemplateLabels = getReportTemplateLabels;
exports.getReportZoneLabel = getReportZoneLabel;
exports.buildReportDiagnostics = buildReportDiagnostics;
exports.getDiagnosticsZoneLine = getDiagnosticsZoneLine;
exports.buildReportTemplateBody = buildReportTemplateBody;
const community_links_1 = require("./community-links");
Object.defineProperty(exports, "PROJECT_FEEDBACK_URL", { enumerable: true, get: function () { return community_links_1.PROJECT_FEEDBACK_URL; } });
const data_1 = require("../i18n/data");
const runtime_1 = require("../i18n/runtime");
const translations_1 = require("../i18n/translations");
function getReportTemplateLabels(language) {
    return {
        bug: (0, translations_1.translate)(language, 'reportTemplates.bug'),
        data: (0, translations_1.translate)(language, 'reportTemplates.data'),
        ui: (0, translations_1.translate)(language, 'reportTemplates.ui'),
        idea: (0, translations_1.translate)(language, 'reportTemplates.idea')
    };
}
function yesNo(value, language) {
    return value
        ? (0, translations_1.translate)(language, 'reportBody.yes')
        : (0, translations_1.translate)(language, 'reportBody.no');
}
function getReportZoneLabel(snapshot, language) {
    const guide = snapshot?.currentGuideEntry ?? snapshot?.currentZone.guide ?? null;
    if (guide) {
        const actLabel = guide.act === 'interlude'
            ? (0, translations_1.translate)(language, 'reportBody.actInterlude')
            : (0, translations_1.translate)(language, 'reportBody.actLabel', { act: guide.act });
        const guideView = (0, data_1.getGuideView)(guide, language);
        return `${guideView?.zoneName ?? guide.zone_ru} / ${guide.zone_en} (${actLabel})`;
    }
    return (snapshot?.currentZone.rawZoneName ||
        snapshot?.runtime.lastRawZoneName ||
        (0, translations_1.translate)(language, 'reportBody.zoneUndefined'));
}
function buildReportDiagnostics(snapshot, appVersion, language, options = {}) {
    const config = snapshot?.config;
    const runtime = snapshot?.runtime;
    const runTimer = config?.runTimer;
    const currentGuide = snapshot?.currentGuideEntry ?? snapshot?.currentZone.guide ?? null;
    const currentLevel = config?.currentLevel ?? null;
    const now = options.now ?? new Date();
    const userAgent = options.userAgent ??
        (typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown');
    const locale = language === 'en' ? 'en-US' : 'ru-RU';
    return [
        (0, translations_1.translate)(language, 'reportBody.appVersion', { value: appVersion }),
        (0, translations_1.translate)(language, 'reportBody.date', { value: now.toLocaleString(locale) }),
        (0, translations_1.translate)(language, 'reportBody.currentZone', { value: getReportZoneLabel(snapshot, language) }),
        (0, translations_1.translate)(language, 'reportBody.zoneId', { value: currentGuide?.id ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.rawZone', {
            value: snapshot?.currentZone.rawZoneName ?? runtime?.lastRawZoneName ?? '—'
        }),
        (0, translations_1.translate)(language, 'reportBody.zoneSource', { value: runtime?.lastZoneSource ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.matcherReason', {
            value: (0, runtime_1.formatZoneMatcherReason)(runtime?.lastMatcherReason, language)
        }),
        (0, translations_1.translate)(language, 'reportBody.sceneKind', { value: snapshot?.currentZone.sceneKind ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.characterLevel', { value: currentLevel ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.recommendedLevel', {
            value: currentGuide ? (0, data_1.translateDataText)(currentGuide.recommended_level_label, language) : '—'
        }),
        (0, translations_1.translate)(language, 'reportBody.logSelected', {
            value: yesNo(Boolean(config?.logFilePath), language)
        }),
        (0, translations_1.translate)(language, 'reportBody.logPath', { value: config?.logFilePath ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.logExists', {
            value: yesNo(Boolean(runtime?.logFileExists), language)
        }),
        (0, translations_1.translate)(language, 'reportBody.watcher', {
            status: (0, runtime_1.formatLogWatcherStatus)(runtime?.logWatcherStatus, language),
            message: (0, runtime_1.translateSystemText)(runtime?.logWatcherMessage ?? '—', language)
        }),
        (0, translations_1.translate)(language, 'reportBody.lastLogLine', {
            value: runtime?.lastLogLine ? runtime.lastLogLine.slice(0, 220) : '—'
        }),
        (0, translations_1.translate)(language, 'reportBody.lastRead', { value: runtime?.lastReadAt ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.lastMatch', { value: runtime?.lastMatchedAt ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.overlayMode', {
            value: runtime?.overlayMode ?? config?.mainOverlaySettings.overlayMode ?? '—'
        }),
        (0, translations_1.translate)(language, 'reportBody.overlayLayout', {
            density: config?.overlayDensity ?? '—',
            scale: config?.overlayScale ?? '—'
        }),
        (0, translations_1.translate)(language, 'reportBody.runTimer', { value: runTimer?.status ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.runTime', { value: runTimer?.elapsedMs ?? 0 }),
        (0, translations_1.translate)(language, 'reportBody.pauses', { value: runTimer?.pauseCount ?? '—' }),
        (0, translations_1.translate)(language, 'reportBody.userAgent', { value: userAgent })
    ].join('\n');
}
function getDiagnosticsZoneLine(diagnostics, language) {
    const prefix = (0, translations_1.translate)(language, 'reportBody.currentZone', { value: '' }).replace(/\s*$/, '');
    const line = diagnostics.split('\n').find((item) => item.startsWith(prefix));
    return line?.replace(prefix, '').trim() || '';
}
function buildReportTemplateBody(template, diagnostics, language) {
    if (template === 'data') {
        return (0, translations_1.translate)(language, 'reportBody.data', {
            zone: getDiagnosticsZoneLine(diagnostics, language),
            diagnostics
        });
    }
    if (template === 'ui') {
        return (0, translations_1.translate)(language, 'reportBody.ui', { diagnostics });
    }
    if (template === 'idea') {
        return (0, translations_1.translate)(language, 'reportBody.idea', { diagnostics });
    }
    return (0, translations_1.translate)(language, 'reportBody.bug', { diagnostics });
}
//# sourceMappingURL=report-issue.js.map