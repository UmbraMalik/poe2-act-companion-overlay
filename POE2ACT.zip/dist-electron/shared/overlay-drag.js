"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isOverlayDragBlockedTarget = isOverlayDragBlockedTarget;
exports.shouldStartOverlayDrag = shouldStartOverlayDrag;
const OVERLAY_DRAG_BLOCKING_SELECTORS = [
    'button',
    'a',
    'input',
    'textarea',
    'select',
    'label',
    '[role="button"]',
    '[data-overlay-control="true"]',
    '[contenteditable="true"]',
    '.no-drag',
    '.resize-grip'
].join(',');
function hasClosest(target) {
    return Boolean(target && typeof target.closest === 'function');
}
function isOverlayDragBlockedTarget(target) {
    if (!hasClosest(target)) {
        return true;
    }
    return Boolean(target.closest(OVERLAY_DRAG_BLOCKING_SELECTORS));
}
function shouldStartOverlayDrag(target, { button = 0 } = {}) {
    if (button !== 0) {
        return false;
    }
    return !isOverlayDragBlockedTarget(target);
}
//# sourceMappingURL=overlay-drag.js.map