"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMMUNITY_LINKS = exports.PROJECT_REPOSITORY_URL = exports.PROJECT_RELEASES_URL = exports.PROJECT_DONATION_ALERTS_URL = exports.PROJECT_FEEDBACK_URL = exports.PROJECT_CHAT_URL = exports.PROJECT_TELEGRAM_URL = exports.PROJECT_SITE_URL = void 0;
exports.PROJECT_SITE_URL = 'https://umbramalik.github.io/poe2-campaign-codex/';
exports.PROJECT_TELEGRAM_URL = 'https://t.me/POE2CampaignCodex';
exports.PROJECT_CHAT_URL = 'https://t.me/POE2CampaignCodexChat';
exports.PROJECT_FEEDBACK_URL = 'https://t.me/POE2CampaignCodex?direct';
exports.PROJECT_DONATION_ALERTS_URL = 'https://www.donationalerts.com/r/umbramalik';
exports.PROJECT_RELEASES_URL = 'https://github.com/UmbraMalik/poe2-campaign-codex-releases/releases';
exports.PROJECT_REPOSITORY_URL = 'https://github.com/UmbraMalik/poe2-campaign-codex-releases';
exports.COMMUNITY_LINKS = [
    {
        title: 'Сайт проекта',
        description: 'Описание, демо, установка и актуальная версия.',
        url: exports.PROJECT_SITE_URL,
        action: 'Открыть сайт'
    },
    {
        title: 'Telegram',
        description: 'Новости, релизы и важные объявления по overlay.',
        url: exports.PROJECT_TELEGRAM_URL,
        action: 'Открыть канал'
    },
    {
        title: 'Чат проекта',
        description: 'Вопросы, обсуждение, помощь с установкой и живой фидбек.',
        url: exports.PROJECT_CHAT_URL,
        action: 'Открыть чат'
    },
    {
        title: 'Обратная связь',
        description: 'Баги, ошибки в данных, предложения и скриншоты проблем.',
        url: exports.PROJECT_FEEDBACK_URL,
        action: 'Написать'
    },
    {
        title: 'GitHub Releases',
        description: 'Последние сборки, installer .exe и история релизов.',
        url: exports.PROJECT_RELEASES_URL,
        action: 'Открыть релизы'
    },
    {
        title: 'Исходный код',
        description: 'Открытый код проекта: можно посмотреть, проверить и собрать самому.',
        url: exports.PROJECT_REPOSITORY_URL,
        action: 'Открыть GitHub'
    }
];
//# sourceMappingURL=community-links.js.map