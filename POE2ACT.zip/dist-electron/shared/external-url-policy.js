"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ALLOWED_EXTERNAL_URL_EXAMPLES = void 0;
exports.isAllowedExternalUrl = isAllowedExternalUrl;
const community_links_1 = require("./community-links");
function normalizePathname(pathname) {
    const withoutTrailingSlash = pathname.replace(/\/+$/g, '');
    return withoutTrailingSlash || '/';
}
function parseUrlTarget(value) {
    const parsed = new URL(value);
    return {
        host: parsed.hostname.toLowerCase(),
        path: normalizePathname(parsed.pathname),
        search: parsed.search
    };
}
const projectSiteTarget = parseUrlTarget(community_links_1.PROJECT_SITE_URL);
const githubRepositoryTarget = parseUrlTarget(community_links_1.PROJECT_REPOSITORY_URL);
const exactAllowedTargets = [
    community_links_1.PROJECT_TELEGRAM_URL,
    community_links_1.PROJECT_CHAT_URL,
    community_links_1.PROJECT_FEEDBACK_URL,
    community_links_1.PROJECT_DONATION_ALERTS_URL
].map(parseUrlTarget);
function isSameOrChildPath(pathname, parentPath) {
    return pathname === parentPath || pathname.startsWith(`${parentPath}/`);
}
function matchesExactTarget(target, allowed) {
    return (target.host === allowed.host &&
        target.path === allowed.path &&
        target.search === allowed.search);
}
function isAllowedExternalUrl(value) {
    if (typeof value !== 'string') {
        return false;
    }
    let parsed;
    try {
        parsed = new URL(value);
    }
    catch {
        return false;
    }
    if (parsed.protocol !== 'https:') {
        return false;
    }
    if (parsed.username || parsed.password || parsed.hash) {
        return false;
    }
    const target = {
        host: parsed.hostname.toLowerCase(),
        path: normalizePathname(parsed.pathname),
        search: parsed.search
    };
    if (exactAllowedTargets.some((allowed) => matchesExactTarget(target, allowed))) {
        return true;
    }
    if (target.host === projectSiteTarget.host &&
        target.search === '' &&
        isSameOrChildPath(target.path, projectSiteTarget.path)) {
        return true;
    }
    if (target.host === githubRepositoryTarget.host &&
        target.search === '' &&
        isSameOrChildPath(target.path, githubRepositoryTarget.path)) {
        return true;
    }
    return false;
}
exports.ALLOWED_EXTERNAL_URL_EXAMPLES = Object.freeze([
    community_links_1.PROJECT_SITE_URL,
    community_links_1.PROJECT_TELEGRAM_URL,
    community_links_1.PROJECT_CHAT_URL,
    community_links_1.PROJECT_FEEDBACK_URL,
    community_links_1.PROJECT_RELEASES_URL,
    community_links_1.PROJECT_REPOSITORY_URL,
    community_links_1.PROJECT_DONATION_ALERTS_URL
]);
//# sourceMappingURL=external-url-policy.js.map