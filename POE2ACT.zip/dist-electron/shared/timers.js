"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatDuration = formatDuration;
exports.getRunTimerDisplayElapsed = getRunTimerDisplayElapsed;
exports.getZoneTimerDisplayElapsed = getZoneTimerDisplayElapsed;
exports.getTownTimerDisplayElapsed = getTownTimerDisplayElapsed;
exports.getTownTimerTotalElapsed = getTownTimerTotalElapsed;
exports.getCountdownDisplayMs = getCountdownDisplayMs;
function formatDuration(ms) {
    const safeMs = Math.max(0, Math.floor(ms));
    const totalSeconds = Math.floor(safeMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    if (hours > 0) {
        return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}
function getRunTimerDisplayElapsed(runTimer, now) {
    if (runTimer.status === 'running' && runTimer.resumedAt !== null) {
        return runTimer.elapsedMs + Math.max(0, now - runTimer.resumedAt);
    }
    return runTimer.elapsedMs;
}
function getZoneTimerDisplayElapsed(runTimer, now) {
    if (runTimer.status === 'running' && runTimer.lastZoneEnteredAt !== null) {
        return runTimer.currentZoneElapsedMs + Math.max(0, now - runTimer.lastZoneEnteredAt);
    }
    return runTimer.currentZoneElapsedMs;
}
function getTownTimerDisplayElapsed(runTimer, townTimer, now) {
    if (townTimer.isInTown &&
        runTimer.status === 'running' &&
        townTimer.townEnteredAt !== null) {
        return townTimer.currentTownElapsedMs + Math.max(0, now - townTimer.townEnteredAt);
    }
    return townTimer.currentTownElapsedMs;
}
function getTownTimerTotalElapsed(runTimer, townTimer, now) {
    if (townTimer.isInTown) {
        return townTimer.totalTownElapsedMs + getTownTimerDisplayElapsed(runTimer, townTimer, now);
    }
    return townTimer.totalTownElapsedMs;
}
function getCountdownDisplayMs(settings, now) {
    if (!settings.leagueStartAt) {
        return null;
    }
    return Math.max(0, settings.leagueStartAt - now);
}
//# sourceMappingURL=timers.js.map