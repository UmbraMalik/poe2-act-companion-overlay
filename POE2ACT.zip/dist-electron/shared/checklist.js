"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GENERAL_LOG_REWARD_KEYWORDS = void 0;
exports.normalizeMatchText = normalizeMatchText;
exports.hasKeywordSignal = hasKeywordSignal;
exports.buildChecklistDefinition = buildChecklistDefinition;
exports.shouldItemBeMissed = shouldItemBeMissed;
exports.getChecklistItemProgress = getChecklistItemProgress;
exports.buildChecklistViewItems = buildChecklistViewItems;
exports.sortChecklistViewItems = sortChecklistViewItems;
exports.matchChecklistItemIdsFromLine = matchChecklistItemIdsFromLine;
exports.matchChecklistItemIdsFromKeywords = matchChecklistItemIdsFromKeywords;
exports.summarizeMissedWarning = summarizeMissedWarning;
exports.getChecklistBadges = getChecklistBadges;
exports.getCurrentChecklistItem = getCurrentChecklistItem;
exports.getMissableUncheckedItems = getMissableUncheckedItems;
exports.getChecklistStateForZone = getChecklistStateForZone;
exports.getVisibleHudChecklist = getVisibleHudChecklist;
exports.findZoneProgressForCurrentZone = findZoneProgressForCurrentZone;
exports.GENERAL_LOG_REWARD_KEYWORDS = [
    'сопротивление холоду',
    'сопротивления холоду',
    'сопротивлению холоду',
    '+10% к сопротивлению холоду',
    'cold resistance',
    '+10% to cold resistance',
    'сопротивление молнии',
    'сопротивления молнии',
    'сопротивлению молнии',
    '+10% к сопротивлению молнии',
    'lightning resistance',
    '+10% to lightning resistance',
    'сопротивление огню',
    'сопротивления огню',
    'сопротивлению огню',
    '+10% к сопротивлению огню',
    'fire resistance',
    '+10% to fire resistance',
    'дух',
    'spirit',
    'пассив',
    'пассивных',
    'пассивное умение',
    'passive skill point',
    'weapon set passive skill point',
    'максимум здоровья',
    'maximum life',
    'максимум маны',
    'maximum mana',
    'сфера ювелира',
    'сфера царей',
    'сфера алхимии',
    'экзальт',
    'руна'
];
const KEYWORD_GROUPS = [
    {
        phrases: [
            'сопротивление холоду',
            'сопротивления холоду',
            'сопротивлению холоду',
            '+10% к сопротивлению холоду'
        ],
        type: 'resistance',
        required: true
    },
    {
        phrases: [
            'сопротивление молнии',
            'сопротивления молнии',
            'сопротивлению молнии',
            '+10% к сопротивлению молнии'
        ],
        type: 'resistance',
        required: true
    },
    {
        phrases: [
            'сопротивление огню',
            'сопротивления огню',
            'сопротивлению огню',
            '+10% к сопротивлению огню'
        ],
        type: 'resistance',
        required: true
    },
    {
        phrases: ['дух', 'камень духа'],
        type: 'spirit',
        required: true
    },
    {
        phrases: ['пассив', 'пассивных', 'пассивное умение'],
        type: 'passive',
        required: true
    },
    {
        phrases: ['максимум здоровья'],
        type: 'life',
        required: true
    },
    {
        phrases: ['максимум маны'],
        type: 'mana',
        required: true
    },
    {
        phrases: ['сфера ювелира', 'сфера царей', 'сфера алхимии', 'экзальт'],
        type: 'currency',
        required: false
    },
    {
        phrases: ['руна'],
        type: 'crafting',
        required: false
    }
];
const QUEST_ITEM_HINTS = [
    'квестовый предмет',
    'письмо',
    'сердце',
    'реликв',
    'ядро души',
    'ключ',
    'горн',
    'жемчужин'
];
const CRAFTING_HINTS = [
    'верстак',
    'руна',
    'точиль',
    'обрывки брони',
    'сфера ремесленника',
    'инструменты кузнеца',
    'кузнечные инструменты'
];
const MISSED_TYPES = new Set([
    'permanent_reward',
    'passive',
    'resistance',
    'spirit',
    'life',
    'mana'
]);
function normalizeMatchText(input) {
    return String(input ?? '')
        .replace(/\[[^\]|]+\|([^\]]+)\]/g, '$1')
        .toLowerCase()
        .replace(/\u0451/g, '\u0435')
        .replace(/['".,:;!?()[\]{}\u2014\u2013-]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}
function stemMatchToken(token) {
    return token
        .replace(/[ьъ]$/g, '')
        .replace(/(иями|ями|ами|ого|ему|ому|его|ыми|ими|иях|ах|ях|ов|ев|ий|ый|ой|ая|яя|ое|ее|ую|юю|ом|ем|ам|ям|у|ю|а|я|е|и|ы|о)$/g, '');
}
function getMatchTokens(input) {
    return normalizeMatchText(input)
        .split(' ')
        .map((token) => stemMatchToken(token))
        .filter((token) => token.length >= 3);
}
function hasKeywordSignal(haystack, keyword) {
    const normalizedHaystack = normalizeMatchText(haystack);
    const normalizedKeyword = normalizeMatchText(keyword);
    if (!normalizedKeyword) {
        return false;
    }
    if (normalizedHaystack.includes(normalizedKeyword) ||
        normalizedKeyword.includes(normalizedHaystack)) {
        return true;
    }
    const haystackTokens = new Set(getMatchTokens(normalizedHaystack));
    const keywordTokens = getMatchTokens(normalizedKeyword);
    return keywordTokens.length > 0
        ? keywordTokens.every((token) => haystackTokens.has(token))
        : false;
}
function createChecklistItemId(zoneId, bucket, index, text) {
    const slug = normalizeMatchText(text)
        .replace(/[^a-z0-9а-я]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 40);
    return `${zoneId}_${bucket}_${index + 1}${slug ? `_${slug}` : ''}`;
}
function inferChecklistItemType(text) {
    const normalizedText = normalizeMatchText(text);
    const matchingGroups = KEYWORD_GROUPS.filter((group) => group.phrases.some((phrase) => hasKeywordSignal(normalizedText, phrase)));
    if (matchingGroups.length > 0) {
        const primary = matchingGroups[0];
        return {
            type: primary.type === 'currency' || primary.type === 'crafting'
                ? primary.type
                : primary.type === 'resistance' ||
                    primary.type === 'spirit' ||
                    primary.type === 'passive' ||
                    primary.type === 'life' ||
                    primary.type === 'mana'
                    ? primary.type
                    : 'permanent_reward',
            required: primary.required,
            phrases: matchingGroups.flatMap((group) => group.phrases)
        };
    }
    if (normalizedText.startsWith('убить ') ||
        normalizedText.includes(' убить ') ||
        normalizedText.includes('босса')) {
        return {
            type: 'boss',
            required: true,
            phrases: []
        };
    }
    if (QUEST_ITEM_HINTS.some((hint) => normalizedText.includes(hint))) {
        return {
            type: 'reward',
            required: true,
            phrases: []
        };
    }
    if (CRAFTING_HINTS.some((hint) => normalizedText.includes(hint))) {
        return {
            type: 'crafting',
            required: false,
            phrases: CRAFTING_HINTS
        };
    }
    return {
        type: 'route_task',
        required: false,
        phrases: []
    };
}
function createChecklistItem(zoneId, bucket, index, text, guideKeywords, forceType, forceRequired) {
    const inferred = inferChecklistItemType(text);
    const autoCompleteKeywords = new Set([text, ...inferred.phrases]);
    for (const keyword of guideKeywords) {
        if (hasKeywordSignal(text, keyword) || hasKeywordSignal(keyword, text)) {
            autoCompleteKeywords.add(keyword);
        }
    }
    return {
        id: createChecklistItemId(zoneId, bucket, index, text),
        text,
        type: forceType ?? inferred.type,
        required: forceRequired ?? inferred.required,
        autoCompleteKeywords: [...autoCompleteKeywords].filter(Boolean),
        linkedChecklistItemIds: []
    };
}
function buildChecklistDefinition(guide) {
    const explicitChecklist = guide.checklist ?? [];
    if (explicitChecklist.length > 0) {
        return explicitChecklist.map((item, index) => {
            const inferred = inferChecklistItemType(item.text);
            const autoCompleteKeywords = new Set([
                item.text,
                ...(item.autoCompleteKeywords ?? []),
                ...inferred.phrases
            ]);
            for (const keyword of guide.keywords_done) {
                if (hasKeywordSignal(item.text, keyword) ||
                    hasKeywordSignal(keyword, item.text)) {
                    autoCompleteKeywords.add(keyword);
                }
            }
            return {
                id: item.id ||
                    createChecklistItemId(guide.id, 'checklist', index, item.text),
                text: item.text,
                type: item.type ?? inferred.type,
                required: item.required ?? inferred.required,
                autoCompleteKeywords: [...autoCompleteKeywords].filter(Boolean),
                autoCompleteMode: item.autoCompleteMode,
                linkedChecklistItemIds: item.linkedChecklistItemIds ?? []
            };
        });
    }
    const items = [];
    const seenTexts = new Set();
    const pushUniqueItem = (bucket, index, text, forceType, forceRequired) => {
        const normalizedText = normalizeMatchText(text);
        const alreadyRepresented = items.some((item) => hasKeywordSignal(item.text, text) || hasKeywordSignal(text, item.text));
        if (!normalizedText || seenTexts.has(normalizedText) || alreadyRepresented) {
            return;
        }
        seenTexts.add(normalizedText);
        items.push(createChecklistItem(guide.id, bucket, index, text, guide.keywords_done, forceType, forceRequired));
    };
    guide.priority.forEach((text, index) => {
        const inferred = inferChecklistItemType(text);
        pushUniqueItem('priority', index, text, inferred.type === 'route_task' ? 'route_task' : inferred.type, inferred.required);
    });
    guide.rewards.forEach((text, index) => {
        const inferred = inferChecklistItemType(text);
        pushUniqueItem('reward', index, text, inferred.type === 'route_task'
            ? 'reward'
            : inferred.required
                ? 'permanent_reward'
                : inferred.type, inferred.required);
    });
    guide.important.forEach((text, index) => {
        const inferred = inferChecklistItemType(text);
        if (!inferred.required) {
            return;
        }
        pushUniqueItem('important', index, text, inferred.type === 'route_task' || inferred.type === 'reward'
            ? 'permanent_reward'
            : inferred.type, true);
    });
    guide.keywords_done.forEach((text, index) => {
        const inferred = inferChecklistItemType(text);
        pushUniqueItem('keyword', index, text, inferred.type === 'route_task' ? 'reward' : inferred.type, inferred.required);
    });
    return items;
}
function shouldItemBeMissed(item) {
    return MISSED_TYPES.has(item.type);
}
function getChecklistItemProgress(zoneProgress, itemId) {
    return zoneProgress?.itemStates[itemId] ?? null;
}
function resolveStoredState(progress) {
    if (!progress) {
        return null;
    }
    // The overlay stays a reminder, not a punishment system:
    // show only soft positive states from real/manual events, never missed warnings.
    if (progress.state === 'done' || progress.state === 'likely_done') {
        return progress.state;
    }
    return null;
}
function buildChecklistViewItems(guide, zoneProgress) {
    if (!guide) {
        return [];
    }
    const checklist = buildChecklistDefinition(guide);
    const storedStates = checklist.map((item) => resolveStoredState(getChecklistItemProgress(zoneProgress, item.id)));
    const firstPendingIndex = storedStates.findIndex((state) => state === null);
    return checklist.map((item, index) => {
        const progress = getChecklistItemProgress(zoneProgress, item.id);
        const storedState = storedStates[index];
        const displayState = storedState ??
            (index === firstPendingIndex ? 'current' : 'pending');
        return {
            ...item,
            displayState,
            detectedBy: progress?.detectedBy ?? null,
            timestamp: progress?.timestamp ?? null,
            originalIndex: index
        };
    });
}
function sortChecklistViewItems(items) {
    return [...items].sort((left, right) => {
        if (left.displayState === 'current' && right.displayState !== 'current') {
            return -1;
        }
        if (right.displayState === 'current' && left.displayState !== 'current') {
            return 1;
        }
        return left.originalIndex - right.originalIndex;
    });
}
function matchChecklistItemIdsFromLine(line, guide) {
    if (!guide) {
        return { itemIds: [], matchedKeywords: [] };
    }
    const checklist = buildChecklistDefinition(guide);
    const matchedKeywords = new Set();
    const itemIds = checklist
        .filter((item) => {
        const candidates = [item.text, ...item.autoCompleteKeywords];
        const matches = candidates.filter((keyword) => hasKeywordSignal(line, keyword));
        for (const match of matches) {
            matchedKeywords.add(match);
        }
        return matches.length > 0;
    })
        .map((item) => item.id);
    return {
        itemIds: [...new Set(itemIds)],
        matchedKeywords: [...matchedKeywords]
    };
}
function matchChecklistItemIdsFromKeywords(guide, keywords) {
    if (!guide || keywords.length === 0) {
        return { itemIds: [], matchedKeywords: [] };
    }
    const checklist = buildChecklistDefinition(guide);
    const matchedKeywords = new Set();
    const itemIds = checklist
        .filter((item) => {
        const candidates = [item.text, ...item.autoCompleteKeywords];
        const matches = keywords.filter((keyword) => candidates.some((candidate) => hasKeywordSignal(candidate, keyword) || hasKeywordSignal(keyword, candidate)));
        for (const match of matches) {
            matchedKeywords.add(match);
        }
        return matches.length > 0;
    })
        .map((item) => item.id);
    return {
        itemIds: [...new Set(itemIds)],
        matchedKeywords: [...matchedKeywords]
    };
}
function summarizeMissedWarning(items) {
    return items.join(', ');
}
function getChecklistBadges(guide) {
    if (!guide) {
        return [];
    }
    const badges = [];
    if (guide.skip.length > 0) {
        badges.push('есть skip');
    }
    if (guide.important.length > 0) {
        badges.push('есть важное');
    }
    if (guide.after.length > 0) {
        badges.push('есть после');
    }
    return badges;
}
function getCurrentChecklistItem(guide, zoneProgress) {
    return (buildChecklistViewItems(guide, zoneProgress).find((item) => item.displayState === 'current') ?? null);
}
function getMissableUncheckedItems(_guide, _zoneProgress) {
    // Missed reward warnings were too noisy and unreliable for this workflow.
    // Keep the guide as a reminder, not as a pass/fail tracker.
    return [];
}
function getChecklistStateForZone(guide, zoneProgress, itemId) {
    return (buildChecklistViewItems(guide, zoneProgress).find((item) => item.id === itemId)
        ?.displayState ?? 'pending');
}
function getVisibleHudChecklist(guide, zoneProgress, limit = 4) {
    const sortedItems = sortChecklistViewItems(buildChecklistViewItems(guide, zoneProgress));
    const visibleItems = sortedItems.slice(0, limit);
    return {
        visibleItems,
        hiddenCount: Math.max(0, sortedItems.length - visibleItems.length),
        totalCount: sortedItems.length
    };
}
function findZoneProgressForCurrentZone(currentZone, zoneProgress) {
    const guideId = currentZone.guide?.id;
    return guideId ? zoneProgress[guideId] : undefined;
}
//# sourceMappingURL=checklist.js.map