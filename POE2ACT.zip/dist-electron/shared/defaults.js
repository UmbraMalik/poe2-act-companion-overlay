"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_CONFIG = exports.DEFAULT_RUN_TIMER_SETTINGS = exports.DEFAULT_HOTKEYS = exports.DEFAULT_TOWN_TIMER = exports.DEFAULT_RUN_TIMER = exports.DEFAULT_COMPANION_BOUNDS = exports.DEFAULT_COMPACT_OVERLAY_BOUNDS = exports.DEFAULT_TIMER_ONLY_OVERLAY_BOUNDS = exports.DEFAULT_OVERLAY_BOUNDS = void 0;
exports.DEFAULT_OVERLAY_BOUNDS = {
    width: 500,
    height: 650
};
exports.DEFAULT_TIMER_ONLY_OVERLAY_BOUNDS = {
    width: 360,
    height: 238
};
exports.DEFAULT_COMPACT_OVERLAY_BOUNDS = {
    width: 350,
    height: 470
};
exports.DEFAULT_COMPANION_BOUNDS = {
    width: 900,
    height: 760
};
exports.DEFAULT_RUN_TIMER = {
    status: 'not_started',
    elapsedMs: 0,
    startedAt: null,
    resumedAt: null,
    pausedAt: null,
    finishedAt: null,
    lastZoneEnteredAt: null,
    currentZoneElapsedMs: 0,
    currentZoneStartedAt: null,
    pauseReason: null,
    pauseCount: 0,
    actSplits: []
};
exports.DEFAULT_TOWN_TIMER = {
    isInTown: false,
    currentTownName: null,
    townEnteredAt: null,
    currentTownElapsedMs: 0,
    totalTownElapsedMs: 0,
    townVisits: []
};
exports.DEFAULT_HOTKEYS = {
    markChecklistDone: 'F6',
    undoChecklistMark: 'F7',
    toggleTimerPause: 'F8',
    openCompanion: 'F9',
    toggleOverlayMode: 'F10'
};
exports.DEFAULT_RUN_TIMER_SETTINGS = {
    autoStartMode: 'scheduled_time',
    leagueStartAt: null,
    leagueStartTimeLabel: null,
    autoStart: true,
    showCountdownBeforeStart: true,
    showZoneTimer: true,
    showActTimer: true
};
exports.DEFAULT_CONFIG = {
    appLanguage: 'ru',
    logFilePath: null,
    logFileSelectionMode: null,
    lastZoneName: null,
    ignoreExistingLogOnNextStart: false,
    currentLevel: null,
    overlayBounds: null,
    overlayCompactBounds: null,
    overlayTimerOnlyBounds: null,
    overlayOpacity: 0.96,
    overlayMovementLocked: false,
    overlayScale: 90,
    overlayDensity: 'normal',
    overlayVisibleSections: {
        rewards: true,
        important: true,
        boss_tips: true,
        xp_notes: true,
        crafting_tips: true,
        skip: true,
        after: false
    },
    mainOverlaySettings: {
        showOverlaySkip: true,
        showOverlayCriticalImportant: true,
        showOverlayBossTip: true,
        showOverlayVendorReminder: true,
        showOverlayXpStatus: true,
        showOverlayPowerSpike: true,
        overlayMode: 'full',
        overlayTimerOnlyMode: false
    },
    devPanelEnabled: false,
    manualHotkeysEnabled: false,
    hotkeys: {
        ...exports.DEFAULT_HOTKEYS
    },
    companionBounds: null,
    companionAlwaysOnTop: false,
    guideProfile: 'universal',
    trainingModeEnabled: false,
    trainingTargetActTimes: {
        act1: null,
        act2: null,
        act3: null,
        act4: null
    },
    zoneProgress: {},
    visitedZones: [],
    zoneTimeHistory: [],
    bestRun: null,
    lastRunSummary: null,
    levelRemindersState: {
        shown: [],
        dismissed: [],
        activeLevelReminderId: null
    },
    runTimer: {
        ...exports.DEFAULT_RUN_TIMER
    },
    townTimer: {
        ...exports.DEFAULT_TOWN_TIMER
    },
    runTimerSettings: {
        ...exports.DEFAULT_RUN_TIMER_SETTINGS
    },
    campaignBonusProgress: {}
};
//# sourceMappingURL=defaults.js.map