"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runClearMissedWarning = runClearMissedWarning;
exports.runSyncRuntimeZoneFields = runSyncRuntimeZoneFields;
exports.runUpdateZoneProgress = runUpdateZoneProgress;
exports.runGetZoneProgress = runGetZoneProgress;
exports.runMergeLikelyDoneKeywords = runMergeLikelyDoneKeywords;
exports.runMarkCurrentChecklistItemDone = runMarkCurrentChecklistItemDone;
exports.runUndoLastChecklistMark = runUndoLastChecklistMark;
exports.runSetLogStatus = runSetLogStatus;
exports.runGetSnapshot = runGetSnapshot;
exports.runClearBroadcastTimer = runClearBroadcastTimer;
exports.runFlushBroadcastState = runFlushBroadcastState;
exports.runBroadcastState = runBroadcastState;
const checklist_1 = require("../shared/checklist");
const app_environment_1 = require("./app-environment");
function runClearMissedWarning() {
    this.runtime.missedWarningZoneRu = null;
    this.runtime.missedWarningItems = [];
}
function runSyncRuntimeZoneFields(rawZoneName, guide) {
    this.runtime.lastRawZoneName = rawZoneName;
    this.runtime.lastMatchedZoneEn = guide?.zone_en ?? null;
    this.runtime.lastMatchedZoneRu = guide?.zone_ru ?? null;
    this.runtime.lastMatchedGuideId = guide?.id ?? null;
}
function runUpdateZoneProgress(guide) {
    if (!guide) {
        return;
    }
    const currentProgress = this.getZoneProgress(guide.id);
    this.config = this.configStore.update({
        zoneProgress: {
            ...this.config.zoneProgress,
            [guide.id]: {
                ...currentProgress,
                lastVisitedAt: new Date().toISOString()
            }
        }
    });
}
function runGetZoneProgress(zoneId) {
    return (this.config.zoneProgress[zoneId] ?? {
        itemStates: {},
        likelyDoneKeywords: [],
        lastVisitedAt: null
    });
}
function runMergeLikelyDoneKeywords(guide, matchedKeywords) {
    const currentProgress = this.getZoneProgress(guide.id);
    const mergedKeywords = [
        ...new Set([
            ...currentProgress.likelyDoneKeywords,
            ...matchedKeywords
        ])
    ];
    const hasChanges = mergedKeywords.length !== currentProgress.likelyDoneKeywords.length ||
        mergedKeywords.some((keyword, index) => keyword !== currentProgress.likelyDoneKeywords[index]);
    if (!hasChanges) {
        return false;
    }
    this.config = this.configStore.update({
        zoneProgress: {
            ...this.config.zoneProgress,
            [guide.id]: {
                ...currentProgress,
                likelyDoneKeywords: mergedKeywords,
                lastVisitedAt: currentProgress.lastVisitedAt ?? new Date().toISOString()
            }
        }
    });
    this.broadcastState();
    return true;
}
function runMarkCurrentChecklistItemDone() {
    // Manual checklist completion disabled. Items are reminders only.
}
function runUndoLastChecklistMark() {
    // Manual checklist completion disabled. Nothing to undo.
}
function runSetLogStatus(status, message) {
    this.runtime.logWatcherStatus = status;
    this.runtime.logWatcherMessage = message;
    this.scheduleLogFileInfoRefresh();
    this.broadcastState();
}
function runGetSnapshot() {
    const currentGuideEntry = this.currentZone.guide;
    const currentZoneProgress = currentGuideEntry
        ? this.getZoneProgress(currentGuideEntry.id)
        : null;
    return {
        config: this.config,
        currentZone: this.currentZone,
        currentGuideEntry,
        currentZoneProgress,
        currentChecklist: (0, checklist_1.buildChecklistViewItems)(currentGuideEntry, currentZoneProgress ?? undefined),
        guideEntries: this.guideService.getAll(),
        vendorCheckpoints: this.guideService.getVendorCheckpoints(),
        powerSpikes: this.guideService.getPowerSpikes(),
        campaignBonuses: this.campaignBonuses,
        activeLevelReminder: this.getActiveLevelReminder(),
        runtime: {
            ...this.runtime,
            timerNowMs: Date.now()
        }
    };
}
function runClearBroadcastTimer() {
    if (this.broadcastTimer) {
        clearTimeout(this.broadcastTimer);
        this.broadcastTimer = null;
    }
}
function runFlushBroadcastState() {
    this.broadcastTimer = null;
    const snapshot = this.pendingSnapshot ?? this.getSnapshot();
    this.pendingSnapshot = null;
    for (const win of [this.overlayWindow, this.settingsWindow, this.companionWindow, this.infoWindow, this.communityWindow, this.supportWindow]) {
        if (win && !win.isDestroyed()) {
            win.webContents.send('app:state-changed', snapshot);
        }
    }
}
function runBroadcastState() {
    // Build snapshots lazily in flushBroadcastState(). Creating a full snapshot is
    // relatively expensive (guide lists, checklist view, bonuses). During combat
    // and area loading the log watcher can request several broadcasts in a short
    // burst; doing getSnapshot() for each request was enough to make the overlay
    // feel frozen. The flush always reads the latest app state, so no data is lost.
    this.pendingSnapshot = null;
    if (this.broadcastTimer) {
        return;
    }
    this.broadcastTimer = setTimeout(() => {
        this.flushBroadcastState();
    }, app_environment_1.BROADCAST_THROTTLE_MS);
}
//# sourceMappingURL=app-state-controller.js.map