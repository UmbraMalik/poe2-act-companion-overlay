"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimerDiagnosticsLog = exports.TIMER_DIAGNOSTICS_FILE_NAME = exports.TIMER_DIAGNOSTICS_DIRECTORY_NAME = exports.TIMER_DIAGNOSTICS_ENV_FLAG = void 0;
exports.isTimerDiagnosticsEnabled = isTimerDiagnosticsEnabled;
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const electron_1 = require("electron");
exports.TIMER_DIAGNOSTICS_ENV_FLAG = 'POE2_TIMER_DIAGNOSTICS';
exports.TIMER_DIAGNOSTICS_DIRECTORY_NAME = 'logs';
exports.TIMER_DIAGNOSTICS_FILE_NAME = 'timer-diagnostics.log';
function isTimerDiagnosticsEnabled() {
    return process.env[exports.TIMER_DIAGNOSTICS_ENV_FLAG] === '1';
}
class TimerDiagnosticsLog {
    constructor() {
        this.writeChain = Promise.resolve();
    }
    isEnabled() {
        return isTimerDiagnosticsEnabled();
    }
    getLogDirectoryPath() {
        return (0, node_path_1.join)(electron_1.app.getPath('userData'), exports.TIMER_DIAGNOSTICS_DIRECTORY_NAME);
    }
    getLogFilePath() {
        return (0, node_path_1.join)(this.getLogDirectoryPath(), exports.TIMER_DIAGNOSTICS_FILE_NAME);
    }
    async write(record) {
        if (!this.isEnabled()) {
            return false;
        }
        let didWrite = false;
        const logDirectoryPath = this.getLogDirectoryPath();
        const logFilePath = this.getLogFilePath();
        const serialized = `${JSON.stringify(record)}\n`;
        this.writeChain = this.writeChain.then(async () => {
            try {
                await (0, promises_1.mkdir)(logDirectoryPath, { recursive: true });
                await (0, promises_1.appendFile)(logFilePath, serialized, 'utf8');
                didWrite = true;
            }
            catch {
                didWrite = false;
            }
        });
        await this.writeChain.catch(() => undefined);
        return didWrite;
    }
    async whenIdle() {
        await this.writeChain.catch(() => undefined);
    }
}
exports.TimerDiagnosticsLog = TimerDiagnosticsLog;
//# sourceMappingURL=timer-diagnostics-log.js.map