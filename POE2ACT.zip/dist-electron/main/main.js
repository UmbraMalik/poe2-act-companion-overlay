"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PoeOverlayApp = exports.inferActHintFromInternalAreaId = void 0;
const node_path_1 = require("node:path");
const electron_1 = require("electron");
const config_store_1 = require("./services/config-store");
const guide_service_1 = require("./services/guide-service");
const log_watcher_1 = require("./services/log-watcher");
const auto_update_service_1 = require("./services/auto-update-service");
const timer_diagnostics_log_1 = require("./timer-diagnostics-log");
const translations_1 = require("../i18n/translations");
const electron_startup_1 = require("./electron-startup");
const campaign_bonuses_json_1 = __importDefault(require("../data/campaign-bonuses.json"));
const app_environment_1 = require("./app-environment");
var app_environment_2 = require("./app-environment");
Object.defineProperty(exports, "inferActHintFromInternalAreaId", { enumerable: true, get: function () { return app_environment_2.inferActHintFromInternalAreaId; } });
const app_update_controller_1 = require("./app-update-controller");
const app_close_confirmation_1 = require("./app-close-confirmation");
const app_ipc_handlers_1 = require("./app-ipc-handlers");
const app_overlay_bounds_controller_1 = require("./app-overlay-bounds-controller");
const app_window_controller_1 = require("./app-window-controller");
const app_guide_log_controller_1 = require("./app-guide-log-controller");
const app_timer_controller_1 = require("./app-timer-controller");
const app_campaign_bonus_controller_1 = require("./app-campaign-bonus-controller");
const app_state_controller_1 = require("./app-state-controller");
(0, electron_startup_1.configureElectronStartup)();
class PoeOverlayApp {
    constructor() {
        this.configStore = new config_store_1.ConfigStore((0, node_path_1.join)(electron_1.app.getPath('userData'), 'config.json'));
        this.guideService = new guide_service_1.GuideService();
        this.campaignBonuses = campaign_bonuses_json_1.default.bonuses;
        this.logWatcher = new log_watcher_1.LogWatcher(this.guideService, {
            onLine: (line, source) => {
                this.runtime.lastLogLineAt = new Date().toISOString();
                this.runtime.lastLogLine = line;
                this.processRunTimerActivityFromLogLine(line, source);
                this.processLevelUpFromLogLine(line, source);
                this.applyCampaignBonusMatchesFromLogLine(line, source);
                // Do not broadcast the full app snapshot for every log line. Zone changes,
                // level ups and reward callbacks broadcast only when they actually
                // change user-visible state. This keeps the overlay renderer from being
                // flooded while the game writes many log lines during combat/area loads.
            },
            onAppendLine: (line) => {
                this.runtime.lastAppendedLine = line;
            },
            onZoneDetected: (zoneMatch) => {
                this.runtime.lastMatcherReason = zoneMatch.matcherReason;
                this.runtime.lastMatchedAt = new Date().toISOString();
            },
            onStatusChange: (status, message) => {
                this.setLogStatus(status, message);
            },
            onRuntimeStateChange: (state) => {
                const shouldBroadcast = this.runtime.watchedLogPath !== state.watchedLogPath ||
                    this.runtime.logFileExists !== state.fileExists ||
                    this.runtime.watcherLastMatchedZone !== state.lastMatchedZone;
                this.runtime.watchedLogPath = state.watchedLogPath;
                this.runtime.currentLogOffset = state.currentOffset;
                this.runtime.logFileExists = state.fileExists;
                this.runtime.logFileSize = state.lastFileSize;
                this.runtime.lastAppendedLine = state.lastAppendedLine;
                this.runtime.watcherLastMatchedZone = state.lastMatchedZone;
                this.runtime.lastWatcherUpdateAt = state.lastUpdateTimestamp;
                this.runtime.lastReadAt = state.lastReadAt;
                this.runtime.lastMatchedAt = state.lastMatchedAt;
                this.runtime.lastMatcherReason = state.lastMatcherReason;
                if (shouldBroadcast) {
                    this.broadcastState();
                }
            }
        });
        this.overlayWindow = null;
        this.settingsWindow = null;
        this.companionWindow = null;
        this.infoWindow = null;
        this.communityWindow = null;
        this.supportWindow = null;
        this.reportWindow = null;
        this.closeConfirmWindow = null;
        this.updateWindow = null;
        this.tray = null;
        this.processedCampaignRewardLogLineKeys = new Set();
        this.processedCampaignRewardLogLineOrder = [];
        this.cachedUpdateCheckResult = null;
        this.startupUpdateInfo = null;
        this.autoUpdateService = new auto_update_service_1.AutoUpdateService();
        this.autoUpdateService.onStateChanged((state) => this.broadcastAutoUpdateState(state));
        this.timerDiagnosticsLog = new timer_diagnostics_log_1.TimerDiagnosticsLog();
        this.config = this.configStore.load();
        this.overlayMode = 'full';
        this.currentZone = {
            rawZoneName: null,
            guide: null,
            sceneKind: 'unknown',
            actHint: null
        };
        this.pendingZoneAreaId = null;
        this.runtime = {
            timerNowMs: Date.now(),
            guideLoadedAt: null,
            lastLogLine: null,
            lastRawZoneName: null,
            lastMatchedZoneEn: null,
            lastMatchedZoneRu: null,
            lastMatchedGuideId: null,
            lastZoneSource: null,
            logWatcherStatus: 'idle',
            logWatcherMessage: app_environment_1.DEFAULT_LOG_STATUS_MESSAGE,
            logFileExists: false,
            logFileSize: null,
            watchedLogPath: null,
            currentLogOffset: 0,
            lastAppendedLine: null,
            watcherLastMatchedZone: null,
            lastWatcherUpdateAt: null,
            lastReadAt: null,
            lastMatchedAt: null,
            lastMatcherReason: 'none',
            lastLevelUpDetectedAt: null,
            lastLogLineAt: null,
            lastValidGameplayZoneAt: null,
            lastGameplayGuideId: null,
            lastGameplayZoneRu: null,
            lastGameplayAct: null,
            lastSceneSource: null,
            lastSceneSourceAt: null,
            overlayMode: 'full',
            missedWarningZoneRu: null,
            missedWarningItems: []
        };
        this.isQuitting = false;
        this.isClosingOverlayWindow = false;
        this.isQuittingConfirmed = false;
        this.isQuitConfirmationInFlight = false;
        this.isOverlayCloseConfirmationInFlight = false;
        this.pendingCloseConfirmResult = null;
        this.resolveCloseConfirmResult = null;
        this.logInfoRefreshTimer = null;
        this.checklistHistory = [];
        this.broadcastTimer = null;
        this.pendingSnapshot = null;
        this.overlayBoundsTimer = null;
        this.overlayAutoResizeSuspendedUntil = 0;
        this.overlayDragInProgress = false;
        this.overlayDragBounds = null;
        this.lastOverlayKnownBounds = null;
        this.overlayBoundsSourceHint = null;
        this.companionBoundsTimer = null;
        this.runTimerStartTimer = null;
        this.timerVisualHeartbeat = null;
        this.lastTimerVisualHeartbeatSentAtMs = null;
        this.updateCheckTimer = null;
        this.isAutoUpdateCheckInFlight = false;
        this.globalHotkeysRegistered = false;
        this.registeredGlobalHotkeys = new Set();
    }
    async bootstrap() {
        this.overlayMode = this.getStartupOverlayMode();
        this.runtime.overlayMode = this.overlayMode;
        this.loadGuide();
        this.restoreLastZoneFromConfig();
        this.reconcileRunTimerState();
        await this.ensureLogFile();
        this.registerGlobalHotkeys();
        this.registerIpc();
        this.logTimerDiagnostics('timer-diagnostics-enabled', {
            source: 'main',
            note: 'env-flag-detected-at-bootstrap'
        });
        if (electron_startup_1.DIRECT_COMPOSITION_COMPAT_ENABLED) {
            this.logTimerDiagnostics('overlay-direct-composition-compat-enabled', {
                source: 'main.command-line',
                note: 'Windows compatibility mode: Chromium DirectComposition disabled for smoother inactive overlay rendering over games'
            });
        }
        this.createOverlayWindow();
        this.startTimerVisualHeartbeat();
        this.createTray();
        this.bindAppEvents();
        this.scheduleStartupUpdateCheck();
        if (!this.config.logFilePath) {
            this.openSettingsWindow();
        }
        else {
            await this.startLogWatcher(this.config.logFilePath, this.config.ignoreExistingLogOnNextStart);
        }
        this.broadcastState();
    }
    bindAppEvents() {
        electron_1.app.on('before-quit', (event) => {
            if (this.isQuittingConfirmed) {
                this.prepareForQuit();
                return;
            }
            if (this.isQuitConfirmationInFlight) {
                event.preventDefault();
                this.closeConfirmWindow?.show();
                this.closeConfirmWindow?.focus();
                return;
            }
            if (this.config.runTimer.status !== 'running') {
                this.isQuittingConfirmed = true;
                this.prepareForQuit();
                return;
            }
            event.preventDefault();
            void this.confirmQuitWhileRunTimerIsRunning();
        });
        electron_1.app.on('window-all-closed', () => {
            // Keep the tray app alive when the overlay window itself is closed.
            // Explicit app.quit() still works through the tray/menu and goes through before-quit above.
        });
    }
    prepareForQuit() {
        if (this.isQuitting) {
            return;
        }
        this.isQuitting = true;
        this.stopTimerVisualHeartbeat();
        if (this.closeConfirmWindow && !this.closeConfirmWindow.isDestroyed()) {
            this.closeConfirmWindow.destroy();
        }
        this.closeConfirmWindow = null;
        if (this.communityWindow && !this.communityWindow.isDestroyed()) {
            this.communityWindow.destroy();
        }
        this.communityWindow = null;
        if (this.supportWindow && !this.supportWindow.isDestroyed()) {
            this.supportWindow.destroy();
        }
        this.supportWindow = null;
        if (this.reportWindow && !this.reportWindow.isDestroyed()) {
            this.reportWindow.destroy();
        }
        this.reportWindow = null;
        if (this.updateWindow && !this.updateWindow.isDestroyed()) {
            this.updateWindow.destroy();
        }
        this.updateWindow = null;
        this.pendingCloseConfirmResult = null;
        this.resolveCloseConfirmResult = null;
        if (this.updateCheckTimer) {
            clearTimeout(this.updateCheckTimer);
            this.updateCheckTimer = null;
        }
        this.clearLogFileInfoRefreshTimer();
        this.clearBroadcastTimer();
        if (this.overlayBoundsTimer) {
            clearTimeout(this.overlayBoundsTimer);
            this.overlayBoundsTimer = null;
        }
        if (this.companionBoundsTimer) {
            clearTimeout(this.companionBoundsTimer);
            this.companionBoundsTimer = null;
        }
        this.clearRunTimerStartTimer();
        electron_1.globalShortcut.unregisterAll();
        this.registeredGlobalHotkeys.clear();
        this.globalHotkeysRegistered = false;
        this.logWatcher.stop();
    }
    getQuitDialogOwnerWindow() {
        const focusedWindow = electron_1.BrowserWindow.getFocusedWindow();
        if (focusedWindow && !focusedWindow.isDestroyed()) {
            return focusedWindow;
        }
        return [this.overlayWindow, this.settingsWindow, this.companionWindow, this.infoWindow, this.communityWindow, this.supportWindow, this.reportWindow].find((win) => Boolean(win && !win.isDestroyed() && win.isVisible()));
    }
    async showMessageBoxSafe(options) {
        const owner = this.getQuitDialogOwnerWindow();
        return owner ? electron_1.dialog.showMessageBox(owner, options) : electron_1.dialog.showMessageBox(options);
    }
    getCurrentLanguage() {
        return this.config?.appLanguage === 'en' ? 'en' : 'ru';
    }
    t(key, params) {
        return (0, translations_1.translate)(this.getCurrentLanguage(), key, params);
    }
    getUpdateWindowOwner() {
        return app_update_controller_1.runGetUpdateWindowOwner.apply(this, arguments);
    }
    broadcastAutoUpdateState(state) {
        return app_update_controller_1.runBroadcastAutoUpdateState.apply(this, arguments);
    }
    scheduleStartupUpdateCheck() {
        return app_update_controller_1.runScheduleStartupUpdateCheck.apply(this, arguments);
    }
    async runStartupUpdateCheck() {
        return app_update_controller_1.runRunStartupUpdateCheck.apply(this, arguments);
    }
    async checkForUpdates(showErrors = true) {
        return app_update_controller_1.runCheckForUpdates.apply(this, arguments);
    }
    openUpdateWindow(updateInfo = null) {
        return app_update_controller_1.runOpenUpdateWindow.apply(this, arguments);
    }
    settleCloseConfirm(result) {
        return app_close_confirmation_1.runSettleCloseConfirm.apply(this, arguments);
    }
    async showCustomQuitConfirmation() {
        return app_close_confirmation_1.runShowCustomQuitConfirmation.apply(this, arguments);
    }
    async showNativeQuitConfirmation() {
        return app_close_confirmation_1.runShowNativeQuitConfirmation.apply(this, arguments);
    }
    buildManualPausedRunTimer(now) {
        return app_close_confirmation_1.runBuildManualPausedRunTimer.apply(this, arguments);
    }
    pauseRunTimerForQuit(now = Date.now()) {
        return app_close_confirmation_1.runPauseRunTimerForQuit.apply(this, arguments);
    }
    async confirmQuitWhileRunTimerIsRunning() {
        return app_close_confirmation_1.runConfirmQuitWhileRunTimerIsRunning.apply(this, arguments);
    }
    async installAutoUpdate() {
        return app_update_controller_1.runInstallAutoUpdate.apply(this, arguments);
    }
    registerIpc() {
        return app_ipc_handlers_1.runRegisterIpc.apply(this, arguments);
    }
    logOverlayBoundsEvent(level, payload) {
        return app_overlay_bounds_controller_1.runLogOverlayBoundsEvent.apply(this, arguments);
    }
    getOverlayBoundsSourceHint() {
        return app_overlay_bounds_controller_1.runGetOverlayBoundsSourceHint.apply(this, arguments);
    }
    setOverlayBoundsSourceHint(source, applyMode) {
        return app_overlay_bounds_controller_1.runSetOverlayBoundsSourceHint.apply(this, arguments);
    }
    applyOverlayWindowBounds(source, requestedBounds, options = {}) {
        return app_overlay_bounds_controller_1.runApplyOverlayWindowBounds.apply(this, arguments);
    }
    handleOverlayWindowBoundsEvent(eventName) {
        return app_overlay_bounds_controller_1.runHandleOverlayWindowBoundsEvent.apply(this, arguments);
    }
    createOverlayWindow() {
        return app_window_controller_1.runCreateOverlayWindow.apply(this, arguments);
    }
    getConfiguredHotkeys() {
        return app_window_controller_1.runGetConfiguredHotkeys.apply(this, arguments);
    }
    registerGlobalHotkeys() {
        return app_window_controller_1.runRegisterGlobalHotkeys.apply(this, arguments);
    }
    getLocalInputAccelerator(input) {
        return app_window_controller_1.runGetLocalInputAccelerator.apply(this, arguments);
    }
    attachManualHotkeys(window) {
        return app_window_controller_1.runAttachManualHotkeys.apply(this, arguments);
    }
    toggleSettingsWindow() {
        return app_window_controller_1.runToggleSettingsWindow.apply(this, arguments);
    }
    openSettingsWindow() {
        return app_window_controller_1.runOpenSettingsWindow.apply(this, arguments);
    }
    toggleCompanionWindow() {
        return app_window_controller_1.runToggleCompanionWindow.apply(this, arguments);
    }
    openCompanionWindow() {
        return app_window_controller_1.runOpenCompanionWindow.apply(this, arguments);
    }
    openInfoWindow() {
        return app_window_controller_1.runOpenInfoWindow.apply(this, arguments);
    }
    openCommunityWindow() {
        return app_window_controller_1.runOpenCommunityWindow.apply(this, arguments);
    }
    openSupportWindow() {
        return app_window_controller_1.runOpenSupportWindow.apply(this, arguments);
    }
    openReportIssueWindow() {
        return app_window_controller_1.runOpenReportIssueWindow.apply(this, arguments);
    }
    createTray() {
        return app_window_controller_1.runCreateTray.apply(this, arguments);
    }
    getHotkeyTrayLabel() {
        return app_window_controller_1.runGetHotkeyTrayLabel.apply(this, arguments);
    }
    refreshTrayMenu() {
        return app_window_controller_1.runRefreshTrayMenu.apply(this, arguments);
    }
    async appendDevSampleLine() {
        return app_window_controller_1.runAppendDevSampleLine.apply(this, arguments);
    }
    async requestCloseOverlayWindow() {
        return app_close_confirmation_1.runRequestCloseOverlayWindow.apply(this, arguments);
    }
    quitApplicationFromOverlayClose() {
        return app_close_confirmation_1.runQuitApplicationFromOverlayClose.apply(this, arguments);
    }
    closeOverlayWindow() {
        return app_close_confirmation_1.runCloseOverlayWindow.apply(this, arguments);
    }
    showOverlayInactive() {
        return app_window_controller_1.runShowOverlayInactive.apply(this, arguments);
    }
    showOverlay() {
        return app_window_controller_1.runShowOverlay.apply(this, arguments);
    }
    setOverlayMode(mode) {
        return app_window_controller_1.runSetOverlayMode.apply(this, arguments);
    }
    toggleOverlayMode() {
        return app_window_controller_1.runToggleOverlayMode.apply(this, arguments);
    }
    async loadWindowPage(window, page) {
        return app_window_controller_1.runLoadWindowPage.apply(this, arguments);
    }
    getStartupOverlayMode() {
        return app_window_controller_1.runGetStartupOverlayMode.apply(this, arguments);
    }
    getOverlayMinimumSize(mode, density = this.config.overlayDensity, scale = this.config.overlayScale) {
        return app_overlay_bounds_controller_1.runGetOverlayMinimumSize.apply(this, arguments);
    }
    getOverlayMaximumOffscreenX(width) {
        return app_overlay_bounds_controller_1.runGetOverlayMaximumOffscreenX.apply(this, arguments);
    }
    getOverlayMinimumVisibleWidth(width) {
        return app_overlay_bounds_controller_1.runGetOverlayMinimumVisibleWidth.apply(this, arguments);
    }
    getOverlayMinimumVisibleHeight(height) {
        return app_overlay_bounds_controller_1.runGetOverlayMinimumVisibleHeight.apply(this, arguments);
    }
    getOverlayScaledDefaultBounds(mode, density = this.config.overlayDensity) {
        return app_overlay_bounds_controller_1.runGetOverlayScaledDefaultBounds.apply(this, arguments);
    }
    getOverlayVirtualWorkArea() {
        return app_overlay_bounds_controller_1.runGetOverlayVirtualWorkArea.apply(this, arguments);
    }
    normalizeOverlayBoundsForMode(bounds, mode, density = this.config.overlayDensity) {
        return app_overlay_bounds_controller_1.runNormalizeOverlayBoundsForMode.apply(this, arguments);
    }
    isBoundsVisible(bounds) {
        return app_overlay_bounds_controller_1.runIsBoundsVisible.apply(this, arguments);
    }
    getFullOverlayFallbackBounds() {
        return app_overlay_bounds_controller_1.runGetFullOverlayFallbackBounds.apply(this, arguments);
    }
    getTimerOnlyOverlayFallbackBounds() {
        return app_overlay_bounds_controller_1.runGetTimerOnlyOverlayFallbackBounds.apply(this, arguments);
    }
    getCompactOverlayFallbackBounds() {
        return app_overlay_bounds_controller_1.runGetCompactOverlayFallbackBounds.apply(this, arguments);
    }
    getSavedOverlayBoundsForState(mode, density = this.config.overlayDensity) {
        return app_overlay_bounds_controller_1.runGetSavedOverlayBoundsForState.apply(this, arguments);
    }
    getFallbackOverlayBoundsForState(mode, density = this.config.overlayDensity) {
        return app_overlay_bounds_controller_1.runGetFallbackOverlayBoundsForState.apply(this, arguments);
    }
    getOverlayBoundsForMode(mode, density = this.config.overlayDensity) {
        return app_overlay_bounds_controller_1.runGetOverlayBoundsForMode.apply(this, arguments);
    }
    getCompanionBounds() {
        return app_overlay_bounds_controller_1.runGetCompanionBounds.apply(this, arguments);
    }
    persistOverlayBoundsForState(mode, density, bounds) {
        return app_overlay_bounds_controller_1.runPersistOverlayBoundsForState.apply(this, arguments);
    }
    persistOverlayBoundsForCurrentState(bounds) {
        return app_overlay_bounds_controller_1.runPersistOverlayBoundsForCurrentState.apply(this, arguments);
    }
    persistOverlayBoundsImmediately() {
        return app_overlay_bounds_controller_1.runPersistOverlayBoundsImmediately.apply(this, arguments);
    }
    persistOverlayBounds() {
        return app_overlay_bounds_controller_1.runPersistOverlayBounds.apply(this, arguments);
    }
    persistCompanionBounds() {
        return app_overlay_bounds_controller_1.runPersistCompanionBounds.apply(this, arguments);
    }
    loadGuide() {
        return app_guide_log_controller_1.runLoadGuide.apply(this, arguments);
    }
    restoreLastZoneFromConfig() {
        return app_guide_log_controller_1.runRestoreLastZoneFromConfig.apply(this, arguments);
    }
    rebindCurrentZoneAfterGuideReload() {
        return app_guide_log_controller_1.runRebindCurrentZoneAfterGuideReload.apply(this, arguments);
    }
    async ensureLogFile() {
        return app_guide_log_controller_1.runEnsureLogFile.apply(this, arguments);
    }
    async findAutoLogFile() {
        return app_guide_log_controller_1.runFindAutoLogFile.apply(this, arguments);
    }
    async isReadable(filePath) {
        return app_guide_log_controller_1.runIsReadable.apply(this, arguments);
    }
    clearLogFileInfoRefreshTimer() {
        return app_guide_log_controller_1.runClearLogFileInfoRefreshTimer.apply(this, arguments);
    }
    scheduleLogFileInfoRefresh() {
        return app_guide_log_controller_1.runScheduleLogFileInfoRefresh.apply(this, arguments);
    }
    async refreshLogFileInfo(filePath = this.config.logFilePath) {
        return app_guide_log_controller_1.runRefreshLogFileInfo.apply(this, arguments);
    }
    async startLogWatcher(filePath, skipBootstrap = false) {
        return app_guide_log_controller_1.runStartLogWatcher.apply(this, arguments);
    }
    setCurrentZone(rawZoneName, source, guide = this.guideService.findByZoneName(rawZoneName), actHint = null) {
        return app_guide_log_controller_1.runSetCurrentZone.apply(this, arguments);
    }
    handleZoneLeave(_previousGuide) {
        return app_guide_log_controller_1.runHandleZoneLeave.apply(this, arguments);
    }
    getRunTimerDisplayElapsedMs(now = Date.now()) {
        return app_timer_controller_1.runGetRunTimerDisplayElapsedMs.apply(this, arguments);
    }
    getCurrentZoneElapsedMs(now = Date.now()) {
        return app_timer_controller_1.runGetCurrentZoneElapsedMs.apply(this, arguments);
    }
    getCurrentTownElapsedMs(_now = Date.now()) {
        return app_timer_controller_1.runGetCurrentTownElapsedMs.apply(this, arguments);
    }
    getTotalTownElapsedMs(_now = Date.now()) {
        return app_timer_controller_1.runGetTotalTownElapsedMs.apply(this, arguments);
    }
    getCurrentTimerAct() {
        return app_timer_controller_1.runGetCurrentTimerAct.apply(this, arguments);
    }
    getCurrentActElapsedForDiagnostics(now = Date.now(), currentAct = this.getCurrentTimerAct()) {
        return app_timer_controller_1.runGetCurrentActElapsedForDiagnostics.apply(this, arguments);
    }
    buildTimerDiagnosticsRecord(payload) {
        return app_timer_controller_1.runBuildTimerDiagnosticsRecord.apply(this, arguments);
    }
    logTimerDiagnostics(event, payload = {}) {
        return app_timer_controller_1.runLogTimerDiagnostics.apply(this, arguments);
    }
    setSceneWithoutGuide(rawZoneName, source, sceneKind, actHint = null) {
        return app_guide_log_controller_1.runSetSceneWithoutGuide.apply(this, arguments);
    }
    setTownScene(rawZoneName, source) {
        return app_guide_log_controller_1.runSetTownScene.apply(this, arguments);
    }
    recordVisitedZone(guide, enteredAt) {
        return app_guide_log_controller_1.runRecordVisitedZone.apply(this, arguments);
    }
    openTownVisit(_townName, _now) {
        return app_guide_log_controller_1.runOpenTownVisit.apply(this, arguments);
    }
    closeTownVisit(_now) {
        return app_guide_log_controller_1.runCloseTownVisit.apply(this, arguments);
    }
    handleRunTimerAfterTownEntered(_now) {
        return app_guide_log_controller_1.runHandleRunTimerAfterTownEntered.apply(this, arguments);
    }
    recordZoneTimeEntry(guide, now) {
        return app_guide_log_controller_1.runRecordZoneTimeEntry.apply(this, arguments);
    }
    collectVisitedGuides() {
        return app_guide_log_controller_1.runCollectVisitedGuides.apply(this, arguments);
    }
    buildRunSummary(runTimer, totalElapsedMs, finishedAt) {
        return app_guide_log_controller_1.runBuildRunSummary.apply(this, arguments);
    }
    getActiveLevelReminder() {
        return app_guide_log_controller_1.runGetActiveLevelReminder.apply(this, arguments);
    }
    normalizeSceneSource(rawSceneSource) {
        return app_guide_log_controller_1.runNormalizeSceneSource.apply(this, arguments);
    }
    getZoneMatchActHint(zoneMatch) {
        return app_guide_log_controller_1.runGetZoneMatchActHint.apply(this, arguments);
    }
    getFallbackActHintForScene(sceneKind, explicitActHint = null) {
        return app_guide_log_controller_1.runGetFallbackActHintForScene.apply(this, arguments);
    }
    isUnknownOrNullScene(rawSceneSource) {
        return app_guide_log_controller_1.runIsUnknownOrNullScene.apply(this, arguments);
    }
    isActLabelScene(rawSceneSource) {
        return app_guide_log_controller_1.runIsActLabelScene.apply(this, arguments);
    }
    isLoginLikeScene(rawSceneSource) {
        return app_guide_log_controller_1.runIsLoginLikeScene.apply(this, arguments);
    }
    isTownScene(rawSceneSource) {
        return app_guide_log_controller_1.runIsTownScene.apply(this, arguments);
    }
    isTownSceneWithGuide(rawSceneSource, guide) {
        return app_guide_log_controller_1.runIsTownSceneWithGuide.apply(this, arguments);
    }
    isValidGameplaySceneSource(rawSceneSource, guide = rawSceneSource ? this.guideService.findByZoneName(rawSceneSource) : null) {
        return app_guide_log_controller_1.runIsValidGameplaySceneSource.apply(this, arguments);
    }
    getIgnoredZoneEventReason(zoneMatch) {
        return app_guide_log_controller_1.runGetIgnoredZoneEventReason.apply(this, arguments);
    }
    logZoneEventDecision(zoneMatch, action, reason = null) {
        return app_guide_log_controller_1.runLogZoneEventDecision.apply(this, arguments);
    }
    shouldKeepPendingZoneAreaId(zoneName) {
        return app_guide_log_controller_1.runShouldKeepPendingZoneAreaId.apply(this, arguments);
    }
    extractZoneMatchFromLogLine(line) {
        return app_guide_log_controller_1.runExtractZoneMatchFromLogLine.apply(this, arguments);
    }
    processRunTimerActivityFromLogLine(line, source) {
        return app_timer_controller_1.runProcessRunTimerActivityFromLogLine.apply(this, arguments);
    }
    clearRunTimerStartTimer() {
        return app_timer_controller_1.runClearRunTimerStartTimer.apply(this, arguments);
    }
    persistRunTimer(nextRunTimer, diagnosticsPayload = null) {
        return app_timer_controller_1.runPersistRunTimer.apply(this, arguments);
    }
    scheduleRunTimerAutoStart() {
        return app_timer_controller_1.runScheduleRunTimerAutoStart.apply(this, arguments);
    }
    reconcileRunTimerState() {
        return app_timer_controller_1.runReconcileRunTimerState.apply(this, arguments);
    }
    armRunTimer(shouldBroadcast = true) {
        return app_timer_controller_1.runArmRunTimer.apply(this, arguments);
    }
    startRunTimerFromAnchor(startedAt, source = 'main.start-run-timer') {
        return app_timer_controller_1.runStartRunTimerFromAnchor.apply(this, arguments);
    }
    startRunTimerNow() {
        return app_timer_controller_1.runStartRunTimerNow.apply(this, arguments);
    }
    pauseRunTimer() {
        return app_timer_controller_1.runPauseRunTimer.apply(this, arguments);
    }
    resumeRunTimer() {
        return app_timer_controller_1.runResumeRunTimer.apply(this, arguments);
    }
    resetRunTimer() {
        return app_timer_controller_1.runResetRunTimer.apply(this, arguments);
    }
    finishRunTimer() {
        return app_timer_controller_1.runFinishRunTimer.apply(this, arguments);
    }
    finalizeCurrentActSplit(runTimer, now) {
        return app_timer_controller_1.runFinalizeCurrentActSplit.apply(this, arguments);
    }
    tryRecordActSplitByAct(previousAct, nextAct, now) {
        return app_timer_controller_1.runTryRecordActSplitByAct.apply(this, arguments);
    }
    recordActTransitionByHint(previousAct, nextAct, now) {
        return app_timer_controller_1.runRecordActTransitionByHint.apply(this, arguments);
    }
    tryRecordActSplit(previousGuide, nextGuide, now) {
        return app_timer_controller_1.runTryRecordActSplit.apply(this, arguments);
    }
    handleRunTimerAfterZoneEntered(previousGuide, nextGuide, now) {
        return app_timer_controller_1.runHandleRunTimerAfterZoneEntered.apply(this, arguments);
    }
    processLevelUpFromLogLine(line, source) {
        return app_timer_controller_1.runProcessLevelUpFromLogLine.apply(this, arguments);
    }
    normalizeCampaignBonusSceneName(value) {
        return app_campaign_bonus_controller_1.runNormalizeCampaignBonusSceneName.apply(this, arguments);
    }
    getCampaignBonusContextGuideIds() {
        return app_campaign_bonus_controller_1.runGetCampaignBonusContextGuideIds.apply(this, arguments);
    }
    campaignBonusRuleMatches(rule, line) {
        return app_campaign_bonus_controller_1.runCampaignBonusRuleMatches.apply(this, arguments);
    }
    setCampaignBonusDone(bonusId, detectedBy, line = null) {
        return app_campaign_bonus_controller_1.runSetCampaignBonusDone.apply(this, arguments);
    }
    campaignBonusMatchesChecklistItem(bonus, item, normalizedLine) {
        return app_campaign_bonus_controller_1.runCampaignBonusMatchesChecklistItem.apply(this, arguments);
    }
    syncCampaignBonusWithChecklist(bonus, detectedBy, line) {
        return app_campaign_bonus_controller_1.runSyncCampaignBonusWithChecklist.apply(this, arguments);
    }
    campaignBonusTextIncludesAny(bonus, keywords) {
        return app_campaign_bonus_controller_1.runCampaignBonusTextIncludesAny.apply(this, arguments);
    }
    campaignBonusTextIncludesAll(bonus, keywords) {
        return app_campaign_bonus_controller_1.runCampaignBonusTextIncludesAll.apply(this, arguments);
    }
    campaignBonusRewardMatchesParsedReward(bonus, reward) {
        return app_campaign_bonus_controller_1.runCampaignBonusRewardMatchesParsedReward.apply(this, arguments);
    }
    getCampaignBonusRewardFallbackScore(bonus) {
        return app_campaign_bonus_controller_1.runGetCampaignBonusRewardFallbackScore.apply(this, arguments);
    }
    getCampaignBonusRewardFallbackMinScore(parsedReward) {
        return app_campaign_bonus_controller_1.runGetCampaignBonusRewardFallbackMinScore.apply(this, arguments);
    }
    findCampaignBonusFromParsedReward(line, parsedReward) {
        return app_campaign_bonus_controller_1.runFindCampaignBonusFromParsedReward.apply(this, arguments);
    }
    getCampaignBonusLogLineDedupeKey(line, parsedReward) {
        return app_campaign_bonus_controller_1.runGetCampaignBonusLogLineDedupeKey.apply(this, arguments);
    }
    rememberCampaignBonusLogLineKey(key) {
        return app_campaign_bonus_controller_1.runRememberCampaignBonusLogLineKey.apply(this, arguments);
    }
    applyCampaignBonusMatchesFromLogLine(line, source) {
        return app_campaign_bonus_controller_1.runApplyCampaignBonusMatchesFromLogLine.apply(this, arguments);
    }
    clearMissedWarning() {
        return app_state_controller_1.runClearMissedWarning.apply(this, arguments);
    }
    syncRuntimeZoneFields(rawZoneName, guide) {
        return app_state_controller_1.runSyncRuntimeZoneFields.apply(this, arguments);
    }
    updateZoneProgress(guide) {
        return app_state_controller_1.runUpdateZoneProgress.apply(this, arguments);
    }
    getZoneProgress(zoneId) {
        return app_state_controller_1.runGetZoneProgress.apply(this, arguments);
    }
    mergeLikelyDoneKeywords(guide, matchedKeywords) {
        return app_state_controller_1.runMergeLikelyDoneKeywords.apply(this, arguments);
    }
    markCurrentChecklistItemDone() {
        return app_state_controller_1.runMarkCurrentChecklistItemDone.apply(this, arguments);
    }
    undoLastChecklistMark() {
        return app_state_controller_1.runUndoLastChecklistMark.apply(this, arguments);
    }
    setLogStatus(status, message) {
        return app_state_controller_1.runSetLogStatus.apply(this, arguments);
    }
    startTimerVisualHeartbeat() {
        return app_timer_controller_1.runStartTimerVisualHeartbeat.apply(this, arguments);
    }
    stopTimerVisualHeartbeat() {
        return app_timer_controller_1.runStopTimerVisualHeartbeat.apply(this, arguments);
    }
    emitRunTimerState() {
        return app_timer_controller_1.runEmitRunTimerState.apply(this, arguments);
    }
    getSnapshot() {
        return app_state_controller_1.runGetSnapshot.apply(this, arguments);
    }
    clearBroadcastTimer() {
        return app_state_controller_1.runClearBroadcastTimer.apply(this, arguments);
    }
    flushBroadcastState() {
        return app_state_controller_1.runFlushBroadcastState.apply(this, arguments);
    }
    broadcastState() {
        return app_state_controller_1.runBroadcastState.apply(this, arguments);
    }
}
exports.PoeOverlayApp = PoeOverlayApp;
const singleInstance = electron_1.app.requestSingleInstanceLock();
if (!singleInstance) {
    electron_1.app.quit();
}
else {
    electron_1.app.whenReady().then(async () => {
        const poeOverlayApp = new PoeOverlayApp();
        await poeOverlayApp.bootstrap();
    });
}
//# sourceMappingURL=main.js.map