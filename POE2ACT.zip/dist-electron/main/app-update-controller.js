"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runGetUpdateWindowOwner = runGetUpdateWindowOwner;
exports.runBroadcastAutoUpdateState = runBroadcastAutoUpdateState;
exports.runScheduleStartupUpdateCheck = runScheduleStartupUpdateCheck;
exports.runRunStartupUpdateCheck = runRunStartupUpdateCheck;
exports.runCheckForUpdates = runCheckForUpdates;
exports.runOpenUpdateWindow = runOpenUpdateWindow;
exports.runInstallAutoUpdate = runInstallAutoUpdate;
const node_path_1 = require("node:path");
const electron_1 = require("electron");
const update_service_1 = require("./services/update-service");
const app_icons_1 = require("./app-icons");
const app_environment_1 = require("./app-environment");
function runGetUpdateWindowOwner() {
    const focusedWindow = electron_1.BrowserWindow.getFocusedWindow();
    if (focusedWindow &&
        !focusedWindow.isDestroyed() &&
        focusedWindow !== this.updateWindow) {
        return focusedWindow;
    }
    return [this.settingsWindow, this.companionWindow, this.infoWindow, this.communityWindow, this.supportWindow, this.reportWindow, this.overlayWindow].find((win) => Boolean(win && !win.isDestroyed() && win.isVisible()));
}
function runBroadcastAutoUpdateState(state) {
    const windows = [
        this.settingsWindow,
        this.updateWindow,
        this.companionWindow,
        this.infoWindow,
        this.communityWindow,
        this.supportWindow,
        this.reportWindow,
        this.overlayWindow
    ];
    for (const window of windows) {
        if (window && !window.isDestroyed()) {
            window.webContents.send('app:auto-update-changed', state);
        }
    }
}
function runScheduleStartupUpdateCheck() {
    if (this.updateCheckTimer) {
        clearTimeout(this.updateCheckTimer);
    }
    this.updateCheckTimer = setTimeout(() => {
        this.updateCheckTimer = null;
        void this.runStartupUpdateCheck();
    }, app_environment_1.UPDATE_CHECK_DELAY_MS);
}
async function runRunStartupUpdateCheck() {
    if (this.isQuitting || this.isAutoUpdateCheckInFlight) {
        return;
    }
    this.isAutoUpdateCheckInFlight = true;
    try {
        const autoState = await this.autoUpdateService.checkForUpdates();
        if (autoState.status === 'available') {
            this.openUpdateWindow();
            return;
        }
        // Dev fallback: electron-updater usually cannot work without packaged update config.
        // Keep the existing GitHub Releases checker useful for local testing.
        if (autoState.status === 'error' && app_environment_1.isDev) {
            const result = await this.checkForUpdates(false);
            if (result.status === 'available' && result.update) {
                this.openUpdateWindow(result.update);
            }
        }
    }
    finally {
        this.isAutoUpdateCheckInFlight = false;
    }
}
async function runCheckForUpdates(showErrors = true) {
    const result = await (0, update_service_1.checkForUpdates)(electron_1.app.getVersion());
    if (result.status === 'error') {
        if (showErrors) {
            this.cachedUpdateCheckResult = result;
        }
        return result;
    }
    this.cachedUpdateCheckResult = result;
    this.startupUpdateInfo = result.status === 'available' ? result.update ?? null : null;
    return result;
}
function runOpenUpdateWindow(updateInfo = null) {
    this.startupUpdateInfo = updateInfo;
    if (this.updateWindow && !this.updateWindow.isDestroyed()) {
        this.updateWindow.show();
        this.updateWindow.focus();
        return;
    }
    const parentWindow = this.getUpdateWindowOwner();
    this.updateWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        width: 680,
        height: 720,
        minWidth: 620,
        minHeight: 560,
        resizable: false,
        minimizable: false,
        maximizable: false,
        fullscreenable: false,
        show: false,
        frame: false,
        titleBarStyle: 'hidden',
        backgroundColor: '#101318',
        autoHideMenuBar: true,
        skipTaskbar: true,
        alwaysOnTop: true,
        ...(parentWindow ? { parent: parentWindow } : {}),
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.updateWindow.setMenuBarVisibility(false);
    this.updateWindow.removeMenu();
    this.updateWindow.setAlwaysOnTop(true, 'screen-saver');
    this.updateWindow.on('closed', () => {
        this.updateWindow = null;
    });
    void this.loadWindowPage(this.updateWindow, 'update');
    this.updateWindow.once('ready-to-show', () => {
        this.updateWindow?.show();
        this.updateWindow?.focus();
    });
}
async function runInstallAutoUpdate() {
    const state = this.autoUpdateService.getState();
    if (state.status !== 'downloaded') {
        return false;
    }
    try {
        if (this.config.runTimer.status === 'running') {
            this.pauseRunTimerForQuit(Date.now());
        }
        this.isQuittingConfirmed = true;
        this.prepareForQuit();
        setTimeout(() => {
            this.autoUpdateService.quitAndInstall();
        }, 50);
        return true;
    }
    catch (error) {
        console.error('[AutoUpdate] Failed to install update.', error);
        return false;
    }
}
//# sourceMappingURL=app-update-controller.js.map