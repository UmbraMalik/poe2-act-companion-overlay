"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runSettleCloseConfirm = runSettleCloseConfirm;
exports.runShowCustomQuitConfirmation = runShowCustomQuitConfirmation;
exports.runShowNativeQuitConfirmation = runShowNativeQuitConfirmation;
exports.runBuildManualPausedRunTimer = runBuildManualPausedRunTimer;
exports.runPauseRunTimerForQuit = runPauseRunTimerForQuit;
exports.runConfirmQuitWhileRunTimerIsRunning = runConfirmQuitWhileRunTimerIsRunning;
exports.runRequestCloseOverlayWindow = runRequestCloseOverlayWindow;
exports.runQuitApplicationFromOverlayClose = runQuitApplicationFromOverlayClose;
exports.runCloseOverlayWindow = runCloseOverlayWindow;
const node_path_1 = require("node:path");
const electron_1 = require("electron");
function runSettleCloseConfirm(result) {
    const resolve = this.resolveCloseConfirmResult;
    const window = this.closeConfirmWindow;
    this.resolveCloseConfirmResult = null;
    this.pendingCloseConfirmResult = null;
    this.closeConfirmWindow = null;
    if (window && !window.isDestroyed()) {
        window.destroy();
    }
    resolve?.(result);
}
async function runShowCustomQuitConfirmation() {
    if (this.pendingCloseConfirmResult) {
        this.closeConfirmWindow?.show();
        this.closeConfirmWindow?.focus();
        return this.pendingCloseConfirmResult;
    }
    try {
        const parentWindow = this.getQuitDialogOwnerWindow();
        const closeConfirmWindow = new electron_1.BrowserWindow({
            width: 500,
            height: 252,
            minWidth: 460,
            minHeight: 220,
            maxWidth: 520,
            maxHeight: 320,
            resizable: false,
            minimizable: false,
            maximizable: false,
            fullscreenable: false,
            movable: true,
            show: false,
            frame: false,
            transparent: false,
            backgroundColor: '#101318',
            title: this.t('main.quitTitle'),
            skipTaskbar: true,
            alwaysOnTop: true,
            modal: Boolean(parentWindow),
            ...(parentWindow ? { parent: parentWindow } : {}),
            webPreferences: {
                preload: (0, node_path_1.join)(__dirname, 'preload.js'),
                contextIsolation: true,
                nodeIntegration: false,
                backgroundThrottling: false
            }
        });
        closeConfirmWindow.setMenuBarVisibility(false);
        closeConfirmWindow.removeMenu();
        closeConfirmWindow.setAlwaysOnTop(true, 'screen-saver');
        closeConfirmWindow.on('close', (event) => {
            if (!this.resolveCloseConfirmResult) {
                return;
            }
            event.preventDefault();
            this.settleCloseConfirm('stay');
        });
        closeConfirmWindow.on('closed', () => {
            this.closeConfirmWindow = null;
        });
        this.closeConfirmWindow = closeConfirmWindow;
        this.pendingCloseConfirmResult = new Promise((resolve) => {
            this.resolveCloseConfirmResult = resolve;
        });
        closeConfirmWindow.once('ready-to-show', () => {
            closeConfirmWindow.show();
            closeConfirmWindow.focus();
        });
        await this.loadWindowPage(closeConfirmWindow, 'close-confirm');
        return this.pendingCloseConfirmResult;
    }
    catch (error) {
        console.error('[Quit] Failed to open custom quit confirmation window.', error);
        if (this.closeConfirmWindow && !this.closeConfirmWindow.isDestroyed()) {
            this.closeConfirmWindow.destroy();
        }
        this.closeConfirmWindow = null;
        this.pendingCloseConfirmResult = null;
        this.resolveCloseConfirmResult = null;
        return null;
    }
}
async function runShowNativeQuitConfirmation() {
    const result = await this.showMessageBoxSafe({
        type: 'warning',
        title: this.t('main.quitTitle'),
        message: this.t('main.quitMessage'),
        detail: this.t('main.quitDetail'),
        buttons: [this.t('main.stay'), this.t('main.closeAndSave')],
        defaultId: 0,
        cancelId: 0,
        noLink: true
    });
    return result.response === 1;
}
function runBuildManualPausedRunTimer(now) {
    const runTimer = this.config.runTimer;
    return {
        ...runTimer,
        status: 'paused',
        elapsedMs: this.getRunTimerDisplayElapsedMs(now),
        resumedAt: null,
        pausedAt: now,
        lastZoneEnteredAt: null,
        currentZoneElapsedMs: this.getCurrentZoneElapsedMs(now),
        pauseReason: 'manual',
        pauseCount: runTimer.pauseCount + 1
    };
}
function runPauseRunTimerForQuit(now = Date.now()) {
    const runTimer = this.config.runTimer;
    if (runTimer.status !== 'running') {
        return;
    }
    this.persistRunTimer(this.buildManualPausedRunTimer(now), {
        event: 'timer-pause',
        source: 'main.quit',
        note: 'pause-for-quit'
    });
    this.refreshTrayMenu();
    this.broadcastState();
}
async function runConfirmQuitWhileRunTimerIsRunning() {
    if (this.isQuitConfirmationInFlight) {
        this.closeConfirmWindow?.show();
        this.closeConfirmWindow?.focus();
        return;
    }
    this.isQuitConfirmationInFlight = true;
    let shouldQuit = false;
    try {
        const customResult = await this.showCustomQuitConfirmation();
        if (customResult === 'close_and_save') {
            shouldQuit = true;
        }
        else if (customResult === null) {
            shouldQuit = await this.showNativeQuitConfirmation();
        }
        if (!shouldQuit) {
            return;
        }
        this.pauseRunTimerForQuit(Date.now());
    }
    catch (error) {
        console.error('[Quit] Failed to preserve running timer before exit.', error);
        await this.showMessageBoxSafe({
            type: 'error',
            title: this.t('main.saveTimerErrorTitle'),
            message: this.t('main.saveTimerErrorTitle'),
            detail: this.t('main.saveTimerErrorDetail'),
            buttons: [this.t('common.ok')],
            defaultId: 0,
            cancelId: 0,
            noLink: true
        });
    }
    finally {
        this.isQuitConfirmationInFlight = false;
    }
    if (!shouldQuit) {
        return;
    }
    this.isQuittingConfirmed = true;
    electron_1.app.quit();
}
async function runRequestCloseOverlayWindow() {
    const targetWindow = this.overlayWindow;
    if (!targetWindow || targetWindow.isDestroyed()) {
        return false;
    }
    // The overlay X is treated as a real app close action, not "hide to tray".
    // If the timer is running, ask first; if the user stays, keep the overlay visible.
    if (this.config.runTimer.status !== 'running') {
        return this.quitApplicationFromOverlayClose();
    }
    if (this.isOverlayCloseConfirmationInFlight) {
        this.closeConfirmWindow?.show();
        this.closeConfirmWindow?.focus();
        return false;
    }
    this.isOverlayCloseConfirmationInFlight = true;
    let shouldCloseApplication = false;
    try {
        const customResult = await this.showCustomQuitConfirmation();
        if (customResult === 'close_and_save') {
            shouldCloseApplication = true;
        }
        else if (customResult === null) {
            shouldCloseApplication = await this.showNativeQuitConfirmation();
        }
        if (!shouldCloseApplication) {
            this.showOverlayInactive();
            return false;
        }
        this.pauseRunTimerForQuit(Date.now());
        return this.quitApplicationFromOverlayClose();
    }
    catch (error) {
        console.error('[Overlay] Failed to confirm app close while timer is running.', error);
        this.showOverlayInactive();
        return false;
    }
    finally {
        this.isOverlayCloseConfirmationInFlight = false;
    }
}
function runQuitApplicationFromOverlayClose() {
    try {
        if (this.overlayWindow && !this.overlayWindow.isDestroyed()) {
            this.persistOverlayBoundsForCurrentState(this.overlayWindow.getBounds());
        }
    }
    catch {
        // Bounds persistence is best-effort; quitting must still work.
    }
    this.isQuittingConfirmed = true;
    this.prepareForQuit();
    electron_1.app.quit();
    return true;
}
function runCloseOverlayWindow() {
    const targetWindow = this.overlayWindow;
    if (!targetWindow || targetWindow.isDestroyed()) {
        return false;
    }
    this.isClosingOverlayWindow = true;
    try {
        this.persistOverlayBoundsForCurrentState(targetWindow.getBounds());
    }
    catch {
        // Bounds persistence is best-effort; closing must still work.
    }
    targetWindow.close();
    return true;
}
//# sourceMappingURL=app-close-confirmation.js.map