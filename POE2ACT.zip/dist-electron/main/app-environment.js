"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TIMER_DIAGNOSTICS_TICK_DELAY_THRESHOLD_MS = exports.TIMER_VISUAL_HEARTBEAT_MS = exports.UPDATE_CHECK_DELAY_MS = exports.BROADCAST_THROTTLE_MS = exports.DEFAULT_LOG_STATUS_MESSAGE = exports.DEV_SAMPLE_ZONE_LINE = exports.devServerUrl = exports.isDev = exports.forceProductionRenderer = void 0;
exports.inferActHintFromInternalAreaId = inferActHintFromInternalAreaId;
exports.clampOpacity = clampOpacity;
exports.isSafeExternalUrl = isSafeExternalUrl;
const electron_1 = require("electron");
const scene_classifier_1 = require("./scene-classifier");
const external_url_policy_1 = require("../shared/external-url-policy");
exports.forceProductionRenderer = process.env.ELECTRON_RENDERER_MODE === 'production' ||
    process.env.NODE_ENV === 'production';
exports.isDev = !electron_1.app.isPackaged && !exports.forceProductionRenderer;
exports.devServerUrl = process.env.VITE_DEV_SERVER_URL ?? 'http://localhost:5173';
exports.DEV_SAMPLE_ZONE_LINE = '2026/05/12 12:00:00 Вы вошли в область: Грельвуд';
exports.DEFAULT_LOG_STATUS_MESSAGE = 'Ожидание лог-файла';
exports.BROADCAST_THROTTLE_MS = 100;
exports.UPDATE_CHECK_DELAY_MS = 4000;
exports.TIMER_VISUAL_HEARTBEAT_MS = 1000;
exports.TIMER_DIAGNOSTICS_TICK_DELAY_THRESHOLD_MS = 500;
function inferActHintFromInternalAreaId(areaId) {
    return (0, scene_classifier_1.inferActHintFromInternalAreaId)(areaId);
}
function clampOpacity(value) {
    return Math.min(1, Math.max(0.35, value));
}
function isSafeExternalUrl(url) {
    return (0, external_url_policy_1.isAllowedExternalUrl)(url);
}
//# sourceMappingURL=app-environment.js.map