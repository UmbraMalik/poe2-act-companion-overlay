"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoUpdateService = void 0;
const electron_1 = require("electron");
const electron_updater_1 = require("electron-updater");
const update_service_1 = require("./update-service");
const GITHUB_UPDATE_FEED = {
    provider: 'github',
    owner: 'UmbraMalik',
    repo: 'poe2-campaign-codex-releases'
};
const GENERIC_AUTO_UPDATE_ERROR = 'Не удалось проверить обновления. Проверь интернет/VPN или попробуй позже.';
const LATEST_YML_AUTO_UPDATE_ERROR = 'Не удалось проверить автообновление: в последнем релизе не найден latest.yml. Проверь assets релиза.';
const INSTALLER_FALLBACK_ERROR = 'Новая версия найдена, но автоматическое обновление недоступно. Если приложение уже было открыто, а потом включался VPN, отключи VPN и нажми “Проверить обновления” ещё раз. Либо открой релиз и скачай установщик вручную.';
function getErrorMessage(error) {
    if (error instanceof Error && error.message) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    return '';
}
function getUserFacingUpdateError(error, fallback = GENERIC_AUTO_UPDATE_ERROR) {
    const message = getErrorMessage(error);
    const lowerMessage = message.toLowerCase();
    if (lowerMessage.includes('latest.yml')) {
        return LATEST_YML_AUTO_UPDATE_ERROR;
    }
    if (lowerMessage.includes('404')) {
        return 'Не удалось проверить обновления: GitHub вернул 404 для файла обновления.';
    }
    if (lowerMessage.includes('net::') || lowerMessage.includes('network') || lowerMessage.includes('timeout')) {
        return GENERIC_AUTO_UPDATE_ERROR;
    }
    return fallback;
}
function normalizeReleaseNotes(value) {
    if (typeof value === 'string') {
        return value.trim();
    }
    if (Array.isArray(value)) {
        return value
            .map((entry) => {
            if (typeof entry === 'string') {
                return entry;
            }
            if (entry && typeof entry === 'object') {
                const note = entry;
                return typeof note.note === 'string' ? note.note : '';
            }
            return '';
        })
            .filter(Boolean)
            .join('\n');
    }
    return '';
}
function toProgress(progress) {
    return {
        percent: Number.isFinite(progress.percent) ? Math.max(0, Math.min(100, progress.percent ?? 0)) : 0,
        transferred: Number.isFinite(progress.transferred) ? progress.transferred ?? 0 : 0,
        total: Number.isFinite(progress.total) ? progress.total ?? 0 : 0,
        bytesPerSecond: Number.isFinite(progress.bytesPerSecond) ? progress.bytesPerSecond ?? 0 : 0
    };
}
class AutoUpdateService {
    constructor() {
        this.listeners = new Set();
        this.isDownloading = false;
        this.state = {
            status: 'idle',
            currentVersion: electron_1.app.getVersion()
        };
        electron_updater_1.autoUpdater.autoDownload = false;
        electron_updater_1.autoUpdater.autoInstallOnAppQuit = false;
        electron_updater_1.autoUpdater.allowPrerelease = false;
        electron_updater_1.autoUpdater.allowDowngrade = false;
        // Be explicit: repo must be just the repository name, without /releases.
        electron_updater_1.autoUpdater.setFeedURL(GITHUB_UPDATE_FEED);
        electron_updater_1.autoUpdater.on('checking-for-update', () => {
            this.setState({
                status: 'checking',
                currentVersion: electron_1.app.getVersion(),
                errorMessage: undefined,
                downloadProgress: undefined
            });
        });
        electron_updater_1.autoUpdater.on('update-available', (info) => {
            this.isDownloading = false;
            this.setState({
                status: 'available',
                currentVersion: electron_1.app.getVersion(),
                latestVersion: info.version,
                releaseName: info.releaseName || `PoE2 Campaign Codex Overlay ${info.version}`,
                releaseNotes: normalizeReleaseNotes(info.releaseNotes),
                releaseDate: info.releaseDate,
                errorMessage: undefined,
                downloadProgress: undefined
            });
        });
        electron_updater_1.autoUpdater.on('update-not-available', (info) => {
            this.isDownloading = false;
            this.setState({
                status: 'not_available',
                currentVersion: electron_1.app.getVersion(),
                latestVersion: info.version,
                releaseName: info.releaseName || undefined,
                releaseNotes: normalizeReleaseNotes(info.releaseNotes),
                releaseDate: info.releaseDate,
                errorMessage: undefined,
                downloadProgress: undefined
            });
        });
        electron_updater_1.autoUpdater.on('download-progress', (progress) => {
            this.setState({
                ...this.state,
                status: 'downloading',
                currentVersion: electron_1.app.getVersion(),
                downloadProgress: toProgress(progress),
                errorMessage: undefined
            });
        });
        electron_updater_1.autoUpdater.on('update-downloaded', (info) => {
            this.isDownloading = false;
            this.setState({
                status: 'downloaded',
                currentVersion: electron_1.app.getVersion(),
                latestVersion: info.version,
                releaseName: info.releaseName || this.state.releaseName,
                releaseNotes: normalizeReleaseNotes(info.releaseNotes) || this.state.releaseNotes,
                releaseDate: info.releaseDate || this.state.releaseDate,
                downloadProgress: {
                    percent: 100,
                    transferred: this.state.downloadProgress?.total ?? 0,
                    total: this.state.downloadProgress?.total ?? 0,
                    bytesPerSecond: 0
                },
                errorMessage: undefined
            });
        });
        electron_updater_1.autoUpdater.on('error', (error) => {
            this.isDownloading = false;
            console.error('[AutoUpdate] electron-updater error.', error);
            this.setState({
                ...this.state,
                status: 'error',
                currentVersion: electron_1.app.getVersion(),
                errorMessage: getUserFacingUpdateError(error, 'Не удалось проверить или скачать обновление.')
            });
        });
    }
    getState() {
        return { ...this.state, downloadProgress: this.state.downloadProgress ? { ...this.state.downloadProgress } : undefined };
    }
    onStateChanged(callback) {
        this.listeners.add(callback);
        return () => {
            this.listeners.delete(callback);
        };
    }
    async checkForUpdates() {
        this.setState({
            status: 'checking',
            currentVersion: electron_1.app.getVersion(),
            errorMessage: undefined,
            downloadProgress: undefined
        });
        try {
            await electron_updater_1.autoUpdater.checkForUpdates();
        }
        catch (error) {
            console.error('[AutoUpdate] Failed to check auto updates.', error);
            await this.applyGitHubReleaseFallback(error);
        }
        return this.getState();
    }
    async downloadUpdate() {
        if (this.isDownloading || this.state.status === 'downloading') {
            return this.getState();
        }
        if (this.state.status !== 'available' && this.state.status !== 'error') {
            return this.getState();
        }
        this.isDownloading = true;
        this.setState({
            ...this.state,
            status: 'downloading',
            currentVersion: electron_1.app.getVersion(),
            downloadProgress: {
                percent: 0,
                transferred: 0,
                total: 0,
                bytesPerSecond: 0
            },
            errorMessage: undefined
        });
        try {
            await electron_updater_1.autoUpdater.downloadUpdate();
        }
        catch (error) {
            this.isDownloading = false;
            console.error('[AutoUpdate] Failed to download update.', error);
            this.setState({
                ...this.state,
                status: 'error',
                currentVersion: electron_1.app.getVersion(),
                errorMessage: getUserFacingUpdateError(error, 'Не удалось скачать обновление.')
            });
        }
        return this.getState();
    }
    async applyGitHubReleaseFallback(error) {
        const fallbackMessage = getUserFacingUpdateError(error);
        try {
            const fallbackResult = await (0, update_service_1.checkForUpdates)(electron_1.app.getVersion());
            if (fallbackResult.status === 'none') {
                this.isDownloading = false;
                this.setState({
                    status: 'not_available',
                    currentVersion: electron_1.app.getVersion(),
                    latestVersion: fallbackResult.latestVersion,
                    errorMessage: undefined,
                    downloadProgress: undefined
                });
                return;
            }
            if (fallbackResult.status === 'available' && fallbackResult.update) {
                this.isDownloading = false;
                this.setState({
                    status: 'error',
                    currentVersion: electron_1.app.getVersion(),
                    latestVersion: fallbackResult.latestVersion ?? fallbackResult.update.latestVersion,
                    releaseName: fallbackResult.update.releaseName,
                    releaseNotes: fallbackResult.update.body,
                    releaseDate: fallbackResult.update.publishedAt,
                    downloadProgress: undefined,
                    errorMessage: fallbackMessage === LATEST_YML_AUTO_UPDATE_ERROR
                        ? `${LATEST_YML_AUTO_UPDATE_ERROR} ${INSTALLER_FALLBACK_ERROR}`
                        : INSTALLER_FALLBACK_ERROR
                });
                return;
            }
        }
        catch (fallbackError) {
            console.error('[AutoUpdate] GitHub Releases fallback failed.', fallbackError);
        }
        this.isDownloading = false;
        this.setState({
            ...this.state,
            status: 'error',
            currentVersion: electron_1.app.getVersion(),
            errorMessage: fallbackMessage
        });
    }
    quitAndInstall() {
        electron_updater_1.autoUpdater.quitAndInstall(false, true);
    }
    setState(nextState) {
        this.state = {
            ...nextState,
            currentVersion: electron_1.app.getVersion()
        };
        const snapshot = this.getState();
        for (const listener of this.listeners) {
            listener(snapshot);
        }
    }
}
exports.AutoUpdateService = AutoUpdateService;
//# sourceMappingURL=auto-update-service.js.map