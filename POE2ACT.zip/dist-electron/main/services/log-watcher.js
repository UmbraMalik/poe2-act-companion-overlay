"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogWatcher = void 0;
const node_fs_1 = require("node:fs");
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const node_string_decoder_1 = require("node:string_decoder");
const log_parser_1 = require("./log-parser");
const scene_classifier_1 = require("../scene-classifier");
const TAIL_BYTES = 128 * 1024;
const POLL_INTERVAL_MS = 750;
function stripNulCharacters(input) {
    return String(input ?? '').replace(/\u0000/g, '');
}
class LogWatcher {
    constructor(guideService, callbacks) {
        this.guideService = guideService;
        this.callbacks = callbacks;
        this.filePath = null;
        this.watchedFileName = null;
        this.fileWatcher = null;
        this.directoryWatcher = null;
        this.pollTimer = null;
        this.scheduledRead = null;
        this.filePosition = 0;
        this.remainder = '';
        this.pendingAreaId = null;
        this.decoder = new node_string_decoder_1.StringDecoder('utf8');
        this.reading = false;
        this.needsResync = false;
        this.status = 'idle';
        this.statusMessage = 'Ожидание лог-файла';
        this.runtimeState = {
            watchedLogPath: null,
            currentOffset: 0,
            lastFileSize: null,
            lastAppendedLine: null,
            lastMatchedZone: null,
            lastUpdateTimestamp: null,
            lastReadAt: null,
            lastMatchedAt: null,
            lastMatcherReason: 'none',
            fileExists: false
        };
    }
    resetTextState() {
        this.remainder = '';
        this.pendingAreaId = null;
        this.decoder = new node_string_decoder_1.StringDecoder('utf8');
    }
    decodeBuffer(buffer) {
        return stripNulCharacters(this.decoder.write(buffer));
    }
    decodeBootstrapBuffer(buffer) {
        return stripNulCharacters(buffer.toString('utf8'));
    }
    shouldKeepPendingAreaId(zoneName) {
        return (0, scene_classifier_1.shouldKeepPendingZoneAreaId)(zoneName);
    }
    extractZoneMatch(line) {
        const trimmedLine = stripNulCharacters(String(line ?? '')).trim();
        if (!trimmedLine) {
            return null;
        }
        const extractedInternalAreaId = (0, log_parser_1.extractGeneratedAreaId)(trimmedLine)?.trim() ?? null;
        if (extractedInternalAreaId) {
            this.pendingAreaId = extractedInternalAreaId;
        }
        const extractedZoneName = (0, log_parser_1.extractNamedZoneFromLine)(trimmedLine)?.trim() ?? null;
        if (extractedZoneName) {
            const zoneMatch = this.guideService.resolveZoneMatch({
                rawLine: trimmedLine,
                extractedInternalAreaId: this.pendingAreaId,
                extractedZoneName
            });
            if (!this.shouldKeepPendingAreaId(extractedZoneName)) {
                this.pendingAreaId = null;
            }
            return zoneMatch;
        }
        return this.guideService.extractZoneMatchFromLine(trimmedLine);
    }
    async start(filePath, options) {
        this.stop();
        this.filePath = filePath;
        this.watchedFileName = (0, node_path_1.basename)(filePath).toLowerCase();
        this.filePosition = 0;
        this.resetTextState();
        this.needsResync = false;
        this.updateRuntimeState({
            watchedLogPath: filePath,
            currentOffset: 0,
            lastFileSize: null,
            lastAppendedLine: null,
            lastMatchedZone: null,
            lastReadAt: null,
            lastMatchedAt: null,
            lastMatcherReason: 'none',
            fileExists: false
        });
        this.bindDirectoryWatcher(filePath);
        await this.tryBindFileWatcher();
        this.startPolling();
        if (options?.skipBootstrap) {
            await this.seekToEnd();
        }
        else {
            await this.readNewContent({
                allowBootstrap: true
            });
        }
    }
    stop() {
        this.filePath = null;
        this.watchedFileName = null;
        this.filePosition = 0;
        this.resetTextState();
        this.needsResync = false;
        if (this.scheduledRead) {
            clearTimeout(this.scheduledRead);
            this.scheduledRead = null;
        }
        if (this.pollTimer) {
            clearInterval(this.pollTimer);
            this.pollTimer = null;
        }
        this.fileWatcher?.close();
        this.fileWatcher = null;
        this.directoryWatcher?.close();
        this.directoryWatcher = null;
        this.updateRuntimeState({
            watchedLogPath: null,
            currentOffset: 0,
            lastFileSize: null,
            lastAppendedLine: null,
            lastMatchedZone: null,
            lastReadAt: null,
            lastMatchedAt: null,
            lastMatcherReason: 'none',
            fileExists: false
        });
        this.emitStatus('idle', 'Ожидание лог-файла');
    }
    async checkNow() {
        await this.readNewContent();
    }
    async seekToEnd() {
        if (!this.filePath) {
            return;
        }
        const readAt = new Date().toISOString();
        try {
            const fileStat = await (0, promises_1.stat)(this.filePath);
            if (!fileStat.isFile()) {
                return;
            }
            this.filePosition = fileStat.size;
            this.resetTextState();
            this.needsResync = false;
            this.updateRuntimeState({
                fileExists: true,
                lastFileSize: fileStat.size,
                currentOffset: this.filePosition,
                lastReadAt: readAt,
                lastMatchedZone: null,
                lastMatchedAt: null,
                lastMatcherReason: 'none'
            });
            this.emitStatus('ready', 'Чтение лога активно');
        }
        catch {
            this.updateRuntimeState({
                fileExists: false,
                lastFileSize: null,
                currentOffset: this.filePosition,
                lastReadAt: readAt
            });
        }
    }
    bindDirectoryWatcher(filePath) {
        const watchedDirectory = (0, node_path_1.dirname)(filePath);
        try {
            this.directoryWatcher = (0, node_fs_1.watch)(watchedDirectory, (eventType, fileName) => {
                const nextName = fileName?.toString().toLowerCase() ?? null;
                if (!nextName || nextName === this.watchedFileName) {
                    if (eventType === 'rename') {
                        this.needsResync = true;
                    }
                    this.queueRead(25);
                }
            });
        }
        catch {
            this.directoryWatcher = null;
        }
    }
    async tryBindFileWatcher() {
        if (!this.filePath || this.fileWatcher) {
            return;
        }
        try {
            await (0, promises_1.access)(this.filePath, node_fs_1.constants.R_OK);
            this.fileWatcher = (0, node_fs_1.watch)(this.filePath, (eventType) => {
                if (eventType === 'rename') {
                    this.needsResync = true;
                    this.fileWatcher?.close();
                    this.fileWatcher = null;
                }
                this.queueRead(25);
            });
        }
        catch {
            this.fileWatcher = null;
        }
    }
    startPolling() {
        this.pollTimer = setInterval(() => {
            this.queueRead();
        }, POLL_INTERVAL_MS);
    }
    emitStatus(status, message) {
        if (this.status === status && this.statusMessage === message) {
            return;
        }
        this.status = status;
        this.statusMessage = message;
        this.callbacks.onStatusChange(status, message);
    }
    updateRuntimeState(patch) {
        this.runtimeState = {
            ...this.runtimeState,
            ...patch,
            lastUpdateTimestamp: patch.lastUpdateTimestamp ?? new Date().toISOString()
        };
        this.callbacks.onRuntimeStateChange({ ...this.runtimeState });
    }
    queueRead(delayMs = 125) {
        if (this.scheduledRead) {
            clearTimeout(this.scheduledRead);
        }
        this.scheduledRead = setTimeout(() => {
            this.scheduledRead = null;
            void this.readNewContent();
        }, delayMs);
    }
    shouldKeepPreviousMatchedZone(previousMatch, nextMatch) {
        void previousMatch;
        void nextMatch;
        return false;
    }
    shouldPreserveRuntimeMatchedZone(nextMatch, hadMatchedGuideBeforeLine) {
        void nextMatch;
        void hadMatchedGuideBeforeLine;
        return false;
    }
    async bootstrapFromTail(filePath, fileSize) {
        const start = Math.max(0, fileSize - TAIL_BYTES);
        const handle = await (0, promises_1.open)(filePath, 'r');
        try {
            const buffer = Buffer.alloc(fileSize - start);
            if (buffer.length === 0) {
                return;
            }
            await handle.read(buffer, 0, buffer.length, start);
            const content = this.decodeBootstrapBuffer(buffer);
            const lines = content.split(/\r?\n/).filter(Boolean);
            let lastZone = null;
            this.pendingAreaId = null;
            for (const line of lines) {
                this.callbacks.onLine(line, 'bootstrap');
                const zoneMatch = this.extractZoneMatch(line);
                if (zoneMatch && !this.shouldKeepPreviousMatchedZone(lastZone, zoneMatch)) {
                    lastZone = zoneMatch;
                }
            }
            if (lastZone) {
                this.updateRuntimeState({
                    lastMatchedZone: lastZone.guide?.zone_ru ?? lastZone.rawZoneName,
                    lastMatchedAt: new Date().toISOString(),
                    lastMatcherReason: lastZone.matcherReason
                });
                this.callbacks.onZoneDetected(lastZone);
            }
        }
        finally {
            await handle.close();
        }
    }
    async readNewContent(options) {
        if (!this.filePath || this.reading) {
            return;
        }
        this.reading = true;
        const readAt = new Date().toISOString();
        try {
            await this.tryBindFileWatcher();
            let fileStat;
            try {
                fileStat = await (0, promises_1.stat)(this.filePath);
            }
            catch (error) {
                const isMissingFile = error instanceof Error &&
                    'code' in error &&
                    error.code === 'ENOENT';
                if (isMissingFile) {
                    this.fileWatcher?.close();
                    this.fileWatcher = null;
                }
                this.updateRuntimeState({
                    fileExists: false,
                    lastFileSize: null,
                    currentOffset: this.filePosition,
                    lastReadAt: readAt
                });
                this.emitStatus(isMissingFile ? 'missing' : 'error', error instanceof Error ? error.message : 'Ошибка чтения лог-файла');
                return;
            }
            if (!fileStat.isFile()) {
                this.updateRuntimeState({
                    fileExists: false,
                    lastFileSize: null,
                    currentOffset: this.filePosition,
                    lastReadAt: readAt
                });
                this.emitStatus('missing', 'Лог-файл не найден');
                return;
            }
            await this.tryBindFileWatcher();
            const wasMissing = !this.runtimeState.fileExists;
            if (options?.allowBootstrap && wasMissing) {
                await this.bootstrapFromTail(this.filePath, fileStat.size);
                this.filePosition = fileStat.size;
                this.resetTextState();
                this.needsResync = false;
                this.updateRuntimeState({
                    fileExists: true,
                    lastFileSize: fileStat.size,
                    currentOffset: this.filePosition,
                    lastReadAt: readAt
                });
                this.emitStatus('ready', 'Чтение лога активно');
                return;
            }
            if (wasMissing) {
                await this.bootstrapFromTail(this.filePath, fileStat.size);
                this.filePosition = fileStat.size;
                this.resetTextState();
                this.needsResync = false;
                this.updateRuntimeState({
                    fileExists: true,
                    lastFileSize: fileStat.size,
                    currentOffset: this.filePosition,
                    lastReadAt: readAt
                });
                this.emitStatus('ready', 'Чтение лога активно');
                return;
            }
            if (this.needsResync || fileStat.size < this.filePosition) {
                this.filePosition = 0;
                this.resetTextState();
                this.needsResync = false;
            }
            this.updateRuntimeState({
                fileExists: true,
                lastFileSize: fileStat.size,
                currentOffset: this.filePosition,
                lastReadAt: readAt
            });
            const readSize = fileStat.size - this.filePosition;
            if (readSize <= 0) {
                this.emitStatus('ready', 'Чтение лога активно');
                return;
            }
            const handle = await (0, promises_1.open)(this.filePath, 'r');
            try {
                const buffer = Buffer.alloc(readSize);
                await handle.read(buffer, 0, buffer.length, this.filePosition);
                this.filePosition = fileStat.size;
                this.consumeChunk(this.decodeBuffer(buffer));
                this.updateRuntimeState({
                    fileExists: true,
                    lastFileSize: fileStat.size,
                    currentOffset: this.filePosition,
                    lastReadAt: new Date().toISOString()
                });
                this.emitStatus('ready', 'Чтение лога активно');
            }
            finally {
                await handle.close();
            }
        }
        finally {
            this.reading = false;
        }
    }
    consumeChunk(chunk) {
        const merged = stripNulCharacters(`${this.remainder}${chunk}`);
        const lines = merged.split(/\r?\n/);
        this.remainder = lines.pop() ?? '';
        for (const line of lines) {
            const cleanedLine = stripNulCharacters(line);
            if (!cleanedLine.trim()) {
                continue;
            }
            const hadMatchedGuideBeforeLine = Boolean(this.runtimeState.lastMatchedZone &&
                this.runtimeState.lastMatcherReason !== 'none');
            this.callbacks.onLine(cleanedLine, 'append');
            this.updateRuntimeState({
                lastAppendedLine: cleanedLine,
                currentOffset: this.filePosition,
                lastReadAt: new Date().toISOString(),
                lastMatcherReason: 'none'
            });
            const zoneMatch = this.extractZoneMatch(cleanedLine);
            if (zoneMatch) {
                if (!this.shouldPreserveRuntimeMatchedZone(zoneMatch, hadMatchedGuideBeforeLine)) {
                    this.updateRuntimeState({
                        lastMatchedZone: zoneMatch.guide?.zone_ru ?? zoneMatch.rawZoneName,
                        lastMatchedAt: new Date().toISOString(),
                        lastMatcherReason: zoneMatch.matcherReason
                    });
                }
                this.callbacks.onZoneDetected(zoneMatch);
            }
            this.callbacks.onAppendLine(cleanedLine);
        }
    }
}
exports.LogWatcher = LogWatcher;
//# sourceMappingURL=log-watcher.js.map