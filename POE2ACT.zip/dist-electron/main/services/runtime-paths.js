"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveRuntimePath = resolveRuntimePath;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const electron_1 = require("electron");
function resolveRuntimePath(...segments) {
    const candidates = [];
    if (electron_1.app.isPackaged) {
        candidates.push((0, node_path_1.join)(process.resourcesPath, ...segments));
    }
    candidates.push((0, node_path_1.join)(electron_1.app.getAppPath(), ...segments), (0, node_path_1.join)(process.cwd(), ...segments), (0, node_path_1.join)(__dirname, '..', '..', ...segments));
    return candidates.find((candidate) => (0, node_fs_1.existsSync)(candidate)) ?? (0, node_path_1.join)(electron_1.app.getAppPath(), ...segments);
}
//# sourceMappingURL=runtime-paths.js.map