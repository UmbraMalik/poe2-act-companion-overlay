"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GuideService = void 0;
const node_fs_1 = require("node:fs");
const log_parser_1 = require("./log-parser");
const runtime_paths_1 = require("./runtime-paths");
const diagnostic_logger_1 = require("../diagnostic-logger");
function normalizeText(input) {
    return String(input ?? '')
        .toLowerCase()
        .replace(/\u0451/g, '\u0435')
        .replace(/['".,:;!?()[\]{}\u2014\u2013-]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}
function normalizeInternalAreaId(input) {
    return String(input ?? '')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, '');
}
function stripZoneEventPrefixes(input) {
    return String(input ?? '')
        .trim()
        .replace(/^(?:you have entered|entering area)\s*:?\s*/i, '')
        .replace(/^(?:вы вошли в область|вы вошли|вход в область)\s*:?\s*/i, '')
        .trim();
}
function buildZoneLookupCandidates(zoneName) {
    const normalizedBase = normalizeText(stripZoneEventPrefixes(String(zoneName ?? '')));
    if (!normalizedBase) {
        return [];
    }
    return [normalizedBase];
}
function normalizeStringArray(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    return [...new Set(value.map((entry) => String(entry ?? '').trim()).filter(Boolean))];
}
function getEntryAreaIds(entry) {
    return normalizeStringArray(entry.area_ids ?? entry.areaIds ?? []);
}
function entryAcceptsAreaId(entry, areaId) {
    if (!entry) {
        return false;
    }
    const normalizedAreaId = normalizeInternalAreaId(areaId);
    const entryAreaIds = getEntryAreaIds(entry).map((value) => normalizeInternalAreaId(value));
    return entryAreaIds.length === 0 || entryAreaIds.includes(normalizedAreaId);
}
function asArray(value) {
    if (Array.isArray(value)) {
        return value;
    }
    if (value && typeof value === 'object') {
        const obj = value;
        const candidates = [obj.zones, obj.entries, obj.guide, obj.acts];
        for (const candidate of candidates) {
            if (Array.isArray(candidate)) {
                return candidate;
            }
        }
    }
    return [];
}
function asGuideDataFile(value) {
    if (Array.isArray(value)) {
        return {
            zones: value,
            global_reminders: {
                vendor_checkpoints: []
            }
        };
    }
    if (value && typeof value === 'object') {
        const obj = value;
        return {
            zones: asArray(value),
            global_reminders: {
                vendor_checkpoints: Array.isArray(obj.global_reminders)
                    ? []
                    : Array.isArray(obj.global_reminders
                        ?.vendor_checkpoints)
                        ? (obj.global_reminders.vendor_checkpoints ??
                            [])
                        : []
            }
        };
    }
    return {
        zones: [],
        global_reminders: {
            vendor_checkpoints: []
        }
    };
}
function normalizeEntry(entry, index) {
    const zoneRu = entry.zone_ru ?? entry.zone_en ?? `Зона ${index + 1}`;
    const zoneEn = entry.zone_en ?? entry.zone_ru ?? `zone_${index + 1}`;
    return {
        ...entry,
        id: entry.id ?? normalizeText(zoneEn || zoneRu).replace(/\s+/g, '_'),
        zone_ru: zoneRu,
        zone_en: zoneEn,
        recommended_level: entry.recommended_level ?? null,
        recommended_level_label: entry.recommended_level_label ??
            (entry.recommended_level == null ? '?' : String(entry.recommended_level)),
        is_good_xp_zone: Boolean(entry.is_good_xp_zone),
        priority: Array.isArray(entry.priority) ? entry.priority : [],
        rewards: Array.isArray(entry.rewards) ? entry.rewards : [],
        skip: Array.isArray(entry.skip) ? entry.skip : [],
        important: Array.isArray(entry.important) ? entry.important : [],
        after: Array.isArray(entry.after) ? entry.after : [],
        boss_tips: Array.isArray(entry.boss_tips) ? entry.boss_tips : [],
        xp_notes: Array.isArray(entry.xp_notes) ? entry.xp_notes : [],
        crafting_tips: Array.isArray(entry.crafting_tips) ? entry.crafting_tips : [],
        details: entry.details ?? [],
        next_zone_ru: entry.next_zone_ru ?? '',
        keywords_done: Array.isArray(entry.keywords_done) ? entry.keywords_done : [],
        checklist: Array.isArray(entry.checklist) ? entry.checklist : [],
        aliases: normalizeStringArray(entry.aliases),
        aliases_en: normalizeStringArray(entry.aliases_en),
        zone_aliases: normalizeStringArray(entry.zone_aliases),
        area_ids: getEntryAreaIds(entry)
    };
}
class GuideService {
    constructor() {
        this.entries = [];
        this.powerSpikes = [];
        this.source = {
            zones: [],
            global_reminders: {
                vendor_checkpoints: []
            }
        };
        this.loadedAt = null;
        this.idMap = new Map();
        this.zoneRuMap = new Map();
        this.zoneEnMap = new Map();
        this.aliasMap = new Map();
        this.internalAreaMap = new Map();
        this.internalAreaTargetMap = new Map();
        this.knownTownAreaIds = new Set();
        this.vendorCheckpointMap = new Map();
        this.vendorCheckpointByLevel = new Map();
    }
    load() {
        const guidePath = (0, runtime_paths_1.resolveRuntimePath)('src', 'data', 'guide.json');
        const powerSpikesPath = (0, runtime_paths_1.resolveRuntimePath)('src', 'data', 'power-spikes.json');
        const internalAreaAliasesPath = (0, runtime_paths_1.resolveRuntimePath)('src', 'data', 'internal-area-aliases.en.json');
        if (!(0, node_fs_1.existsSync)(guidePath)) {
            throw new Error(`Guide not found at ${guidePath}`);
        }
        const raw = (0, node_fs_1.readFileSync)(guidePath, 'utf8');
        const parsed = JSON.parse(raw);
        const source = asGuideDataFile(parsed);
        const entries = source.zones.map((entry, index) => normalizeEntry(entry, index));
        const vendorCheckpoints = (source.global_reminders?.vendor_checkpoints ?? [])
            .filter((entry) => Boolean(entry?.id))
            .map((entry) => ({
            id: entry.id,
            level: Number(entry.level) || 0,
            type: entry.type ?? 'vendor',
            title: entry.title ?? `Проверь торговцев на ${entry.level} уровне`,
            items: Array.isArray(entry.items) ? entry.items.filter(Boolean) : []
        }));
        this.source = {
            zones: entries,
            global_reminders: {
                vendor_checkpoints: vendorCheckpoints
            }
        };
        this.entries = entries;
        this.loadedAt = new Date().toISOString();
        this.idMap = new Map(entries.map((entry) => [entry.id, entry]));
        this.zoneRuMap = new Map(entries.map((entry) => [normalizeText(entry.zone_ru), entry]));
        this.zoneEnMap = new Map(entries.map((entry) => [normalizeText(entry.zone_en), entry]));
        this.aliasMap = new Map();
        this.internalAreaMap = new Map();
        this.internalAreaTargetMap = new Map();
        this.knownTownAreaIds = new Set();
        for (const entry of entries) {
            for (const alias of [
                ...(entry.aliases ?? []),
                ...(entry.aliases_en ?? []),
                ...(entry.zone_aliases ?? [])
            ]) {
                const normalizedAlias = normalizeText(alias);
                if (normalizedAlias) {
                    this.aliasMap.set(normalizedAlias, entry);
                }
            }
            for (const areaId of getEntryAreaIds(entry)) {
                const normalizedAreaId = normalizeInternalAreaId(areaId);
                if (!normalizedAreaId) {
                    continue;
                }
                const previousGuideId = this.internalAreaTargetMap.get(normalizedAreaId);
                if (previousGuideId && previousGuideId !== entry.id) {
                    (0, diagnostic_logger_1.diagnosticWarn)('GuideService', 'Duplicate area_id mapping in guide.json', {
                        areaId,
                        normalizedAreaId,
                        previousGuideId,
                        nextGuideId: entry.id
                    });
                }
                this.internalAreaTargetMap.set(normalizedAreaId, entry.id);
                this.internalAreaMap.set(normalizedAreaId, entry);
            }
        }
        if ((0, node_fs_1.existsSync)(internalAreaAliasesPath)) {
            const aliases = JSON.parse((0, node_fs_1.readFileSync)(internalAreaAliasesPath, 'utf8'));
            for (const townAreaId of aliases.knownTownAreaIds ?? []) {
                const normalizedTownAreaId = normalizeInternalAreaId(townAreaId);
                if (normalizedTownAreaId) {
                    this.knownTownAreaIds.add(normalizedTownAreaId);
                }
            }
        }
        this.vendorCheckpointMap = new Map(vendorCheckpoints.map((entry) => [entry.id, entry]));
        this.vendorCheckpointByLevel = new Map(vendorCheckpoints.map((entry) => [entry.level, entry]));
        this.powerSpikes = (0, node_fs_1.existsSync)(powerSpikesPath)
            ? (JSON.parse((0, node_fs_1.readFileSync)(powerSpikesPath, 'utf8')) ?? [])
                .filter((entry) => Boolean(entry?.id))
                .map((entry) => ({
                id: entry.id,
                level: Number(entry.level) || 0,
                title: entry.title ?? `Скачок силы на ${entry.level} уровне`,
                items: Array.isArray(entry.items) ? entry.items.filter(Boolean) : [],
                profiles: Array.isArray(entry.profiles) ? entry.profiles.filter(Boolean) : undefined
            }))
            : [];
        return this.getAll();
    }
    getAll() {
        return [...this.entries];
    }
    getLoadedAt() {
        return this.loadedAt;
    }
    getSource() {
        return {
            zones: this.getAll(),
            global_reminders: {
                vendor_checkpoints: this.getVendorCheckpoints()
            }
        };
    }
    getVendorCheckpoints() {
        return [...this.vendorCheckpointMap.values()];
    }
    getPowerSpikes() {
        return [...this.powerSpikes];
    }
    findVendorCheckpointById(id) {
        if (!id) {
            return null;
        }
        return this.vendorCheckpointMap.get(id) ?? null;
    }
    findVendorCheckpointByLevel(level) {
        if (typeof level !== 'number' || !Number.isFinite(level)) {
            return null;
        }
        return this.vendorCheckpointByLevel.get(level) ?? null;
    }
    findById(id) {
        if (!id) {
            return null;
        }
        return this.idMap.get(id) ?? null;
    }
    findByZoneName(zoneName) {
        return this.matchByZoneName(zoneName).guide;
    }
    resolveGuideReference(reference) {
        const trimmedReference = String(reference ?? '').trim();
        if (!trimmedReference) {
            return null;
        }
        const directIdMatch = this.idMap.get(trimmedReference) ?? this.idMap.get(trimmedReference.toLowerCase());
        if (directIdMatch) {
            return directIdMatch;
        }
        const normalizedReference = normalizeText(trimmedReference);
        return (this.zoneRuMap.get(normalizedReference) ??
            this.zoneEnMap.get(normalizedReference) ??
            this.aliasMap.get(normalizedReference) ??
            null);
    }
    resolveInternalAreaGuide(areaId) {
        const normalizedInternalAreaId = normalizeInternalAreaId(areaId);
        if (!normalizedInternalAreaId) {
            return {
                normalizedInternalAreaId: null,
                mappedValue: null,
                guide: null,
                mappingHit: false
            };
        }
        const guide = this.internalAreaMap.get(normalizedInternalAreaId) ?? null;
        const mappedValue = this.internalAreaTargetMap.get(normalizedInternalAreaId) ?? guide?.id ?? null;
        return {
            normalizedInternalAreaId,
            mappedValue,
            guide,
            mappingHit: mappedValue !== null
        };
    }
    logInternalAreaLookup(extractedInternalAreaId, result) {
        (0, diagnostic_logger_1.diagnosticInfo)('GuideService', 'Internal area lookup', {
            extractedInternalAreaId,
            normalizedInternalAreaId: result.normalizedInternalAreaId,
            mappingHit: result.mappingHit,
            mappingMiss: !result.mappingHit,
            mappedValue: result.mappedValue,
            matchedGuideZoneId: result.guide?.id ?? null,
            matchedGuideZoneRu: result.guide?.zone_ru ?? null
        });
    }
    matchByZoneNameDetailed(zoneName) {
        if (!zoneName) {
            return {
                guide: null,
                matcherReason: 'none',
                normalizedZoneName: null
            };
        }
        const internalAreaMatch = this.resolveInternalAreaGuide(zoneName);
        if (internalAreaMatch.guide) {
            return {
                guide: internalAreaMatch.guide,
                matcherReason: 'internal_area',
                normalizedZoneName: internalAreaMatch.normalizedInternalAreaId
            };
        }
        const normalizedCandidates = buildZoneLookupCandidates(zoneName);
        const normalizedZoneName = normalizedCandidates[0] ?? null;
        for (const candidate of normalizedCandidates) {
            const zoneRuMatch = this.zoneRuMap.get(candidate);
            if (zoneRuMatch) {
                return {
                    guide: zoneRuMatch,
                    matcherReason: 'zone_ru',
                    normalizedZoneName
                };
            }
        }
        for (const candidate of normalizedCandidates) {
            const zoneEnMatch = this.zoneEnMap.get(candidate);
            if (zoneEnMatch) {
                return {
                    guide: zoneEnMatch,
                    matcherReason: 'zone_en',
                    normalizedZoneName
                };
            }
        }
        for (const candidate of normalizedCandidates) {
            const aliasMatch = this.aliasMap.get(candidate);
            if (aliasMatch) {
                return {
                    guide: aliasMatch,
                    matcherReason: 'alias',
                    normalizedZoneName
                };
            }
        }
        return {
            guide: null,
            matcherReason: 'none',
            normalizedZoneName
        };
    }
    matchByZoneName(zoneName) {
        const result = this.matchByZoneNameDetailed(zoneName);
        return {
            guide: result.guide,
            matcherReason: result.matcherReason
        };
    }
    resolveZoneMatch(input) {
        const rawLine = String(input.rawLine ?? '').trim();
        const extractedInternalAreaId = String(input.extractedInternalAreaId ?? '').trim() || null;
        const extractedZoneName = String(input.extractedZoneName ?? '').trim() || null;
        const rawZoneName = extractedZoneName ?? extractedInternalAreaId;
        if (!rawZoneName) {
            return null;
        }
        const normalizedRawZoneName = normalizeText(rawZoneName);
        const ignoredSceneSources = new Set([
            '(null)',
            '(unknown)',
            'null',
            'unknown',
            '',
            '\u0430\u043a\u0442 1',
            '\u0430\u043a\u0442 2',
            '\u0430\u043a\u0442 3',
            '\u0430\u043a\u0442 4',
            '\u0430\u043a\u0442 5',
            'акт 1',
            'акт 2',
            'акт 3',
            'акт 4',
            'акт 5',
            'act 1',
            'act 2',
            'act 3',
            'act 4',
            'act 5',
            'interlude',
            '\u0438\u043d\u0442\u0435\u0440\u043b\u044e\u0434\u0438\u044f'
        ]);
        if (ignoredSceneSources.has(normalizedRawZoneName)) {
            return null;
        }
        const zoneMatch = extractedInternalAreaId
            ? (() => {
                const internalAreaLookup = this.resolveInternalAreaGuide(extractedInternalAreaId);
                this.logInternalAreaLookup(extractedInternalAreaId, internalAreaLookup);
                if (internalAreaLookup.guide) {
                    return {
                        guide: internalAreaLookup.guide,
                        matcherReason: 'internal_area',
                        normalizedZoneName: internalAreaLookup.normalizedInternalAreaId
                    };
                }
                const textMatch = this.matchByZoneNameDetailed(rawZoneName);
                if (textMatch.guide &&
                    entryAcceptsAreaId(textMatch.guide, extractedInternalAreaId)) {
                    return textMatch;
                }
                return {
                    guide: null,
                    matcherReason: 'none',
                    normalizedZoneName: textMatch.normalizedZoneName
                };
            })()
            : this.matchByZoneNameDetailed(rawZoneName);
        return {
            rawLine,
            rawZoneName,
            extractedInternalAreaId,
            extractedZoneName,
            normalizedZoneName: zoneMatch.normalizedZoneName,
            source: extractedInternalAreaId ? 'internal-area-id' : 'entered-zone-name',
            guide: zoneMatch.guide,
            matcherReason: zoneMatch.matcherReason
        };
    }
    extractZoneMatchFromLine(line) {
        const rawLine = String(line ?? '').trim();
        const extractedInternalAreaId = (0, log_parser_1.extractGeneratedAreaId)(rawLine)?.trim() ?? null;
        const extractedZoneName = (0, log_parser_1.extractNamedZoneFromLine)(rawLine)?.trim() ?? null;
        if (extractedInternalAreaId && !extractedZoneName) {
            return null;
        }
        if (extractedInternalAreaId || extractedZoneName) {
            return this.resolveZoneMatch({
                rawLine,
                extractedInternalAreaId,
                extractedZoneName
            });
        }
        const directZoneMatch = this.matchByZoneNameDetailed(rawLine);
        if (!directZoneMatch.guide) {
            return null;
        }
        return {
            rawLine,
            rawZoneName: rawLine,
            extractedInternalAreaId: null,
            extractedZoneName: rawLine,
            normalizedZoneName: directZoneMatch.normalizedZoneName,
            source: 'entered-zone-name',
            guide: directZoneMatch.guide,
            matcherReason: directZoneMatch.matcherReason
        };
    }
}
exports.GuideService = GuideService;
//# sourceMappingURL=guide-service.js.map