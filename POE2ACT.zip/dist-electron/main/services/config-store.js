"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigStore = void 0;
exports.normalizeAppConfig = normalizeAppConfig;
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const defaults_1 = require("../../shared/defaults");
const hotkey_utils_1 = require("../hotkey-utils");
const OVERLAY_SCALES = [70, 80, 90, 100, 110, 120];
const OVERLAY_DENSITIES = ['compact', 'normal', 'detailed'];
const RUN_TIMER_STATUSES = ['not_started', 'armed', 'running', 'paused', 'finished'];
const HOTKEY_KEYS = [
    'markChecklistDone',
    'undoChecklistMark',
    'toggleTimerPause',
    'openCompanion',
    'toggleOverlayMode'
];
const OVERLAY_BOUNDS_LIMITS = {
    minWidth: 160,
    minHeight: 90,
    maxWidth: 2400,
    maxHeight: 1800,
    minPosition: -10000,
    maxPosition: 10000
};
const COMPANION_BOUNDS_LIMITS = {
    minWidth: 420,
    minHeight: 320,
    maxWidth: 3200,
    maxHeight: 2200,
    minPosition: -10000,
    maxPosition: 10000
};
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function finiteNumber(value) {
    if (typeof value !== 'number' || !Number.isFinite(value)) {
        return null;
    }
    return value;
}
function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
}
function finiteInteger(value, min, max) {
    const numberValue = finiteNumber(value);
    if (numberValue === null) {
        return null;
    }
    return Math.round(clamp(numberValue, min, max));
}
function finiteTimestamp(value) {
    const numberValue = finiteNumber(value);
    if (numberValue === null || numberValue < 0) {
        return null;
    }
    // Keep timestamps sane enough to prevent broken configs from exploding timer math,
    // but do not reject future league-start values.
    return Math.round(clamp(numberValue, 0, 4_102_444_800_000));
}
function nonNegativeMs(value) {
    const numberValue = finiteNumber(value);
    if (numberValue === null || numberValue < 0) {
        return 0;
    }
    return Math.round(clamp(numberValue, 0, 315_360_000_000));
}
function safeString(value, fallback = null) {
    return typeof value === 'string' ? value : fallback;
}
function safeBoolean(value, fallback) {
    return typeof value === 'boolean' ? value : fallback;
}
function normalizeEnum(value, allowed, fallback) {
    return typeof value === 'string' && allowed.includes(value) ? value : fallback;
}
function normalizeOverlayScale(value) {
    const numberValue = finiteNumber(value);
    if (numberValue === null) {
        return defaults_1.DEFAULT_CONFIG.overlayScale;
    }
    const clamped = clamp(numberValue, OVERLAY_SCALES[0], OVERLAY_SCALES[OVERLAY_SCALES.length - 1]);
    return OVERLAY_SCALES.reduce((closest, candidate) => Math.abs(candidate - clamped) < Math.abs(closest - clamped) ? candidate : closest);
}
function normalizeOverlayDensity(value) {
    return normalizeEnum(value, OVERLAY_DENSITIES, defaults_1.DEFAULT_CONFIG.overlayDensity);
}
function normalizeOverlayOpacity(value) {
    const numberValue = finiteNumber(value);
    if (numberValue === null) {
        return defaults_1.DEFAULT_CONFIG.overlayOpacity;
    }
    return Math.round(clamp(numberValue, 0.35, 1) * 100) / 100;
}
function normalizeCurrentLevel(value) {
    if (value === null || value === undefined) {
        return defaults_1.DEFAULT_CONFIG.currentLevel;
    }
    const numberValue = finiteNumber(value);
    if (numberValue === null || numberValue < 1 || numberValue > 100) {
        return defaults_1.DEFAULT_CONFIG.currentLevel;
    }
    return Math.round(numberValue);
}
function normalizeBounds(value, limits = OVERLAY_BOUNDS_LIMITS) {
    if (!isRecord(value)) {
        return null;
    }
    const x = finiteNumber(value.x);
    const y = finiteNumber(value.y);
    const width = finiteNumber(value.width);
    const height = finiteNumber(value.height);
    if (x === null || y === null || width === null || height === null) {
        return null;
    }
    return {
        x: Math.round(clamp(x, limits.minPosition, limits.maxPosition)),
        y: Math.round(clamp(y, limits.minPosition, limits.maxPosition)),
        width: Math.round(clamp(width, limits.minWidth, limits.maxWidth)),
        height: Math.round(clamp(height, limits.minHeight, limits.maxHeight))
    };
}
function normalizeOverlayVisibleSections(value) {
    const source = isRecord(value) ? value : {};
    return Object.fromEntries(Object.entries(defaults_1.DEFAULT_CONFIG.overlayVisibleSections).map(([key, fallback]) => [
        key,
        safeBoolean(source[key], fallback)
    ]));
}
function normalizeMainOverlaySettings(value) {
    const source = isRecord(value) ? value : {};
    return {
        showOverlaySkip: safeBoolean(source.showOverlaySkip, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.showOverlaySkip),
        showOverlayCriticalImportant: safeBoolean(source.showOverlayCriticalImportant, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.showOverlayCriticalImportant),
        showOverlayBossTip: safeBoolean(source.showOverlayBossTip, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.showOverlayBossTip),
        showOverlayVendorReminder: safeBoolean(source.showOverlayVendorReminder, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.showOverlayVendorReminder),
        showOverlayXpStatus: safeBoolean(source.showOverlayXpStatus, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.showOverlayXpStatus),
        showOverlayPowerSpike: safeBoolean(source.showOverlayPowerSpike, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.showOverlayPowerSpike),
        overlayMode: source.overlayMode === 'timer_only' ? 'timer_only' : defaults_1.DEFAULT_CONFIG.mainOverlaySettings.overlayMode,
        overlayTimerOnlyMode: safeBoolean(source.overlayTimerOnlyMode, defaults_1.DEFAULT_CONFIG.mainOverlaySettings.overlayTimerOnlyMode)
    };
}
function normalizeHotkeys(value) {
    const source = isRecord(value) ? value : {};
    return Object.fromEntries(HOTKEY_KEYS.map((key) => {
        const raw = source[key];
        const trimmed = typeof raw === 'string' ? raw.trim() : '';
        return [key, trimmed && (0, hotkey_utils_1.normalizeHotkeyAccelerator)(trimmed) ? trimmed : defaults_1.DEFAULT_HOTKEYS[key]];
    }));
}
function normalizeTrainingTargetActTimes(value) {
    const source = isRecord(value) ? value : {};
    return Object.fromEntries(Object.keys(defaults_1.DEFAULT_CONFIG.trainingTargetActTimes).map((key) => {
        const raw = source[key];
        const numberValue = finiteNumber(raw);
        return [key, numberValue === null || numberValue < 0 ? null : Math.round(clamp(numberValue, 0, 24 * 60 * 60 * 1000))];
    }));
}
function normalizeStringArray(value) {
    return Array.isArray(value) ? value.filter((entry) => typeof entry === 'string') : [];
}
function normalizeLevelRemindersState(value) {
    const source = isRecord(value) ? value : {};
    return {
        shown: normalizeStringArray(source.shown),
        dismissed: normalizeStringArray(source.dismissed),
        activeLevelReminderId: safeString(source.activeLevelReminderId, defaults_1.DEFAULT_CONFIG.levelRemindersState.activeLevelReminderId)
    };
}
function normalizeRunTimerActSplit(value) {
    if (!isRecord(value)) {
        return null;
    }
    const act = finiteInteger(value.act, 1, 10);
    const timestamp = finiteTimestamp(value.timestamp);
    if (act === null || timestamp === null) {
        return null;
    }
    return {
        act,
        elapsedMs: nonNegativeMs(value.elapsedMs),
        timestamp
    };
}
function normalizeRunTimer(value) {
    const source = isRecord(value) ? value : {};
    return {
        ...defaults_1.DEFAULT_RUN_TIMER,
        status: normalizeEnum(source.status, RUN_TIMER_STATUSES, defaults_1.DEFAULT_RUN_TIMER.status),
        elapsedMs: nonNegativeMs(source.elapsedMs),
        startedAt: finiteTimestamp(source.startedAt),
        resumedAt: finiteTimestamp(source.resumedAt),
        pausedAt: finiteTimestamp(source.pausedAt),
        finishedAt: finiteTimestamp(source.finishedAt),
        lastZoneEnteredAt: finiteTimestamp(source.lastZoneEnteredAt),
        currentZoneElapsedMs: nonNegativeMs(source.currentZoneElapsedMs),
        currentZoneStartedAt: finiteTimestamp(source.currentZoneStartedAt),
        pauseReason: source.pauseReason === 'manual' ? 'manual' : null,
        pauseCount: finiteInteger(source.pauseCount, 0, 100000) ?? defaults_1.DEFAULT_RUN_TIMER.pauseCount,
        actSplits: Array.isArray(source.actSplits)
            ? source.actSplits.map(normalizeRunTimerActSplit).filter((split) => split !== null)
            : [...defaults_1.DEFAULT_RUN_TIMER.actSplits]
    };
}
function normalizeTownVisit(value) {
    if (!isRecord(value) || typeof value.townName !== 'string') {
        return null;
    }
    const enteredAt = finiteTimestamp(value.enteredAt);
    if (enteredAt === null) {
        return null;
    }
    return {
        townName: value.townName,
        enteredAt,
        leftAt: finiteTimestamp(value.leftAt),
        elapsedMs: nonNegativeMs(value.elapsedMs)
    };
}
function normalizeTownTimer(value) {
    const source = isRecord(value) ? value : {};
    return {
        ...defaults_1.DEFAULT_TOWN_TIMER,
        isInTown: safeBoolean(source.isInTown, defaults_1.DEFAULT_TOWN_TIMER.isInTown),
        currentTownName: safeString(source.currentTownName, defaults_1.DEFAULT_TOWN_TIMER.currentTownName),
        townEnteredAt: finiteTimestamp(source.townEnteredAt),
        currentTownElapsedMs: nonNegativeMs(source.currentTownElapsedMs),
        totalTownElapsedMs: nonNegativeMs(source.totalTownElapsedMs),
        townVisits: Array.isArray(source.townVisits)
            ? source.townVisits.map(normalizeTownVisit).filter((visit) => visit !== null)
            : [...defaults_1.DEFAULT_TOWN_TIMER.townVisits]
    };
}
function normalizeRunTimerSettings(value) {
    const source = isRecord(value) ? value : {};
    return {
        ...defaults_1.DEFAULT_RUN_TIMER_SETTINGS,
        autoStartMode: source.autoStartMode === 'manual' ? 'manual' : 'scheduled_time',
        leagueStartAt: finiteTimestamp(source.leagueStartAt),
        leagueStartTimeLabel: safeString(source.leagueStartTimeLabel, defaults_1.DEFAULT_RUN_TIMER_SETTINGS.leagueStartTimeLabel),
        autoStart: safeBoolean(source.autoStart, defaults_1.DEFAULT_RUN_TIMER_SETTINGS.autoStart),
        showCountdownBeforeStart: safeBoolean(source.showCountdownBeforeStart, defaults_1.DEFAULT_RUN_TIMER_SETTINGS.showCountdownBeforeStart),
        showZoneTimer: safeBoolean(source.showZoneTimer, defaults_1.DEFAULT_RUN_TIMER_SETTINGS.showZoneTimer),
        showActTimer: safeBoolean(source.showActTimer, defaults_1.DEFAULT_RUN_TIMER_SETTINGS.showActTimer)
    };
}
function normalizeVisitedZones(value) {
    if (!Array.isArray(value)) {
        return [...defaults_1.DEFAULT_CONFIG.visitedZones];
    }
    return value.flatMap((entry) => {
        if (!isRecord(entry) || typeof entry.zoneId !== 'string' || typeof entry.zone_ru !== 'string') {
            return [];
        }
        const firstEnteredAt = finiteTimestamp(entry.firstEnteredAt);
        const lastEnteredAt = finiteTimestamp(entry.lastEnteredAt);
        const visitCount = finiteInteger(entry.visitCount, 1, 100000);
        if (firstEnteredAt === null || lastEnteredAt === null || visitCount === null) {
            return [];
        }
        const act = typeof entry.act === 'number' || entry.act === 'interlude' ? entry.act : 'interlude';
        return [{
                zoneId: entry.zoneId,
                zone_ru: entry.zone_ru,
                act,
                firstEnteredAt,
                lastEnteredAt,
                visitCount
            }];
    });
}
function normalizeZoneTimeHistory(value) {
    if (!Array.isArray(value)) {
        return [...defaults_1.DEFAULT_CONFIG.zoneTimeHistory];
    }
    return value.flatMap((entry) => {
        if (!isRecord(entry) || typeof entry.zoneId !== 'string' || typeof entry.zone_ru !== 'string') {
            return [];
        }
        const enteredAt = finiteTimestamp(entry.enteredAt);
        const leftAt = finiteTimestamp(entry.leftAt);
        if (enteredAt === null || leftAt === null) {
            return [];
        }
        const act = typeof entry.act === 'number' || entry.act === 'interlude' ? entry.act : 'interlude';
        return [{
                zoneId: entry.zoneId,
                zone_ru: entry.zone_ru,
                act,
                elapsedMs: nonNegativeMs(entry.elapsedMs),
                enteredAt,
                leftAt
            }];
    });
}
function normalizeAppConfig(config = {}) {
    const rawConfig = isRecord(config) ? config : {};
    const rawZoneProgress = isRecord(rawConfig.zoneProgress) ? rawConfig.zoneProgress : defaults_1.DEFAULT_CONFIG.zoneProgress;
    const mergedZoneProgress = Object.fromEntries(Object.entries(rawZoneProgress).flatMap(([zoneId, zoneProgress]) => {
        if (!isRecord(zoneProgress)) {
            return [];
        }
        return [[
                zoneId,
                {
                    itemStates: isRecord(zoneProgress.itemStates) ? zoneProgress.itemStates : {},
                    likelyDoneKeywords: normalizeStringArray(zoneProgress.likelyDoneKeywords),
                    lastVisitedAt: safeString(zoneProgress.lastVisitedAt, null)
                }
            ]];
    }));
    const bestRun = isRecord(rawConfig.bestRun)
        ? {
            totalElapsedMs: nonNegativeMs(rawConfig.bestRun.totalElapsedMs),
            finishedAt: finiteTimestamp(rawConfig.bestRun.finishedAt) ?? 0,
            actSplits: Array.isArray(rawConfig.bestRun.actSplits)
                ? rawConfig.bestRun.actSplits.map(normalizeRunTimerActSplit).filter((split) => split !== null)
                : []
        }
        : defaults_1.DEFAULT_CONFIG.bestRun;
    const lastRunSummary = isRecord(rawConfig.lastRunSummary)
        ? {
            totalElapsedMs: nonNegativeMs(rawConfig.lastRunSummary.totalElapsedMs),
            finishedAt: finiteTimestamp(rawConfig.lastRunSummary.finishedAt) ?? 0,
            actSplits: Array.isArray(rawConfig.lastRunSummary.actSplits)
                ? rawConfig.lastRunSummary.actSplits.map(normalizeRunTimerActSplit).filter((split) => split !== null)
                : [],
            missedRequiredRewards: normalizeStringArray(rawConfig.lastRunSummary.missedRequiredRewards),
            skippedRequiredItems: normalizeStringArray(rawConfig.lastRunSummary.skippedRequiredItems),
            unfinishedChecklistItems: normalizeStringArray(rawConfig.lastRunSummary.unfinishedChecklistItems),
            pauseCount: finiteInteger(rawConfig.lastRunSummary.pauseCount, 0, 100000) ?? 0,
            longestZones: normalizeZoneTimeHistory(rawConfig.lastRunSummary.longestZones),
            townTimeTotalMs: nonNegativeMs(rawConfig.lastRunSummary.townTimeTotalMs),
            isNewPb: safeBoolean(rawConfig.lastRunSummary.isNewPb, false)
        }
        : defaults_1.DEFAULT_CONFIG.lastRunSummary;
    return {
        ...defaults_1.DEFAULT_CONFIG,
        appLanguage: rawConfig.appLanguage === 'en' ? 'en' : defaults_1.DEFAULT_CONFIG.appLanguage,
        logFilePath: safeString(rawConfig.logFilePath, defaults_1.DEFAULT_CONFIG.logFilePath),
        logFileSelectionMode: rawConfig.logFileSelectionMode === 'auto' || rawConfig.logFileSelectionMode === 'manual'
            ? rawConfig.logFileSelectionMode
            : defaults_1.DEFAULT_CONFIG.logFileSelectionMode,
        lastZoneName: safeString(rawConfig.lastZoneName, defaults_1.DEFAULT_CONFIG.lastZoneName),
        ignoreExistingLogOnNextStart: safeBoolean(rawConfig.ignoreExistingLogOnNextStart, defaults_1.DEFAULT_CONFIG.ignoreExistingLogOnNextStart),
        currentLevel: normalizeCurrentLevel(rawConfig.currentLevel),
        overlayBounds: normalizeBounds(rawConfig.overlayBounds),
        overlayCompactBounds: normalizeBounds(rawConfig.overlayCompactBounds),
        overlayTimerOnlyBounds: normalizeBounds(rawConfig.overlayTimerOnlyBounds),
        overlayOpacity: normalizeOverlayOpacity(rawConfig.overlayOpacity),
        overlayMovementLocked: safeBoolean(rawConfig.overlayMovementLocked, defaults_1.DEFAULT_CONFIG.overlayMovementLocked),
        overlayScale: normalizeOverlayScale(rawConfig.overlayScale),
        overlayDensity: normalizeOverlayDensity(rawConfig.overlayDensity),
        overlayVisibleSections: normalizeOverlayVisibleSections(rawConfig.overlayVisibleSections),
        mainOverlaySettings: normalizeMainOverlaySettings(rawConfig.mainOverlaySettings),
        devPanelEnabled: safeBoolean(rawConfig.devPanelEnabled, defaults_1.DEFAULT_CONFIG.devPanelEnabled),
        manualHotkeysEnabled: safeBoolean(rawConfig.manualHotkeysEnabled, defaults_1.DEFAULT_CONFIG.manualHotkeysEnabled),
        hotkeys: normalizeHotkeys(rawConfig.hotkeys),
        companionBounds: normalizeBounds(rawConfig.companionBounds, COMPANION_BOUNDS_LIMITS),
        companionAlwaysOnTop: safeBoolean(rawConfig.companionAlwaysOnTop, defaults_1.DEFAULT_CONFIG.companionAlwaysOnTop),
        guideProfile: defaults_1.DEFAULT_CONFIG.guideProfile,
        trainingModeEnabled: safeBoolean(rawConfig.trainingModeEnabled, defaults_1.DEFAULT_CONFIG.trainingModeEnabled),
        trainingTargetActTimes: normalizeTrainingTargetActTimes(rawConfig.trainingTargetActTimes),
        zoneProgress: mergedZoneProgress,
        visitedZones: normalizeVisitedZones(rawConfig.visitedZones),
        zoneTimeHistory: normalizeZoneTimeHistory(rawConfig.zoneTimeHistory),
        bestRun,
        lastRunSummary,
        levelRemindersState: normalizeLevelRemindersState(rawConfig.levelRemindersState),
        runTimer: normalizeRunTimer(rawConfig.runTimer),
        townTimer: normalizeTownTimer(rawConfig.townTimer),
        runTimerSettings: normalizeRunTimerSettings(rawConfig.runTimerSettings),
        campaignBonusProgress: isRecord(rawConfig.campaignBonusProgress)
            ? rawConfig.campaignBonusProgress
            : defaults_1.DEFAULT_CONFIG.campaignBonusProgress
    };
}
class ConfigStore {
    constructor(configPath) {
        this.config = { ...defaults_1.DEFAULT_CONFIG };
        this.configPath = configPath;
    }
    load() {
        try {
            const raw = (0, node_fs_1.readFileSync)(this.configPath, 'utf8');
            const parsed = JSON.parse(raw);
            this.config = normalizeAppConfig(parsed);
        }
        catch {
            this.config = { ...defaults_1.DEFAULT_CONFIG };
            this.save();
        }
        return this.get();
    }
    get() {
        return JSON.parse(JSON.stringify(this.config));
    }
    update(patch) {
        this.config = normalizeAppConfig({
            ...this.config,
            ...patch
        });
        this.save();
        return this.get();
    }
    updateSettings(patch) {
        return this.update({
            ...(patch.appLanguage !== undefined
                ? { appLanguage: patch.appLanguage === 'en' ? 'en' : 'ru' }
                : {}),
            ...(patch.overlayOpacity !== undefined
                ? { overlayOpacity: patch.overlayOpacity }
                : {}),
            ...(patch.overlayMovementLocked !== undefined
                ? { overlayMovementLocked: patch.overlayMovementLocked }
                : {}),
            ...(patch.overlayScale !== undefined
                ? { overlayScale: patch.overlayScale }
                : {}),
            ...(patch.overlayDensity !== undefined
                ? { overlayDensity: patch.overlayDensity }
                : {}),
            ...(patch.overlayVisibleSections !== undefined
                ? {
                    overlayVisibleSections: {
                        ...this.config.overlayVisibleSections,
                        ...patch.overlayVisibleSections
                    }
                }
                : {}),
            ...(patch.mainOverlaySettings !== undefined
                ? {
                    mainOverlaySettings: {
                        ...this.config.mainOverlaySettings,
                        ...patch.mainOverlaySettings
                    }
                }
                : {}),
            ...(patch.devPanelEnabled !== undefined
                ? { devPanelEnabled: patch.devPanelEnabled }
                : {}),
            ...(patch.manualHotkeysEnabled !== undefined
                ? { manualHotkeysEnabled: patch.manualHotkeysEnabled }
                : {}),
            ...(patch.hotkeys !== undefined
                ? {
                    hotkeys: {
                        ...this.config.hotkeys,
                        ...patch.hotkeys
                    }
                }
                : {}),
            ...(patch.companionAlwaysOnTop !== undefined
                ? { companionAlwaysOnTop: patch.companionAlwaysOnTop }
                : {}),
            ...(patch.guideProfile !== undefined
                ? { guideProfile: patch.guideProfile }
                : {}),
            ...(patch.trainingModeEnabled !== undefined
                ? { trainingModeEnabled: patch.trainingModeEnabled }
                : {}),
            ...(patch.trainingTargetActTimes !== undefined
                ? {
                    trainingTargetActTimes: {
                        ...this.config.trainingTargetActTimes,
                        ...patch.trainingTargetActTimes
                    }
                }
                : {}),
            ...(patch.runTimerSettings !== undefined
                ? {
                    runTimerSettings: {
                        ...this.config.runTimerSettings,
                        ...patch.runTimerSettings
                    }
                }
                : {})
        });
    }
    setOverlayBounds(bounds) {
        return this.update({
            overlayBounds: bounds
        });
    }
    setOverlayCompactBounds(bounds) {
        return this.update({
            overlayCompactBounds: bounds
        });
    }
    setOverlayTimerOnlyBounds(bounds) {
        return this.update({
            overlayTimerOnlyBounds: bounds
        });
    }
    setCompanionBounds(bounds) {
        return this.update({
            companionBounds: bounds
        });
    }
    resetProgress() {
        const shouldClearPastLeagueStart = typeof this.config.runTimerSettings.leagueStartAt === 'number' &&
            this.config.runTimerSettings.leagueStartAt <= Date.now();
        return this.update({
            ignoreExistingLogOnNextStart: true,
            currentLevel: null,
            lastZoneName: null,
            zoneProgress: {},
            visitedZones: [],
            zoneTimeHistory: [],
            bestRun: null,
            lastRunSummary: null,
            campaignBonusProgress: {},
            levelRemindersState: {
                shown: [],
                dismissed: [],
                activeLevelReminderId: null
            },
            runTimer: {
                ...defaults_1.DEFAULT_RUN_TIMER
            },
            townTimer: {
                ...defaults_1.DEFAULT_TOWN_TIMER
            },
            runTimerSettings: {
                ...this.config.runTimerSettings,
                // Reset means "do not resurrect the old run on next launch".
                // The user can arm/start the timer again manually from Settings.
                autoStart: false,
                leagueStartAt: shouldClearPastLeagueStart
                    ? null
                    : this.config.runTimerSettings.leagueStartAt,
                leagueStartTimeLabel: shouldClearPastLeagueStart
                    ? null
                    : this.config.runTimerSettings.leagueStartTimeLabel
            }
        });
    }
    save() {
        (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.configPath), { recursive: true });
        (0, node_fs_1.writeFileSync)(this.configPath, JSON.stringify(this.config, null, 2), 'utf8');
    }
}
exports.ConfigStore = ConfigStore;
//# sourceMappingURL=config-store.js.map