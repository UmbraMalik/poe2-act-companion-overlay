"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const timerDiagnosticsEnabled = process.env.POE2_TIMER_DIAGNOSTICS === '1';
const api = {
    getSnapshot: () => electron_1.ipcRenderer.invoke('app:get-snapshot'),
    getAppVersion: () => electron_1.ipcRenderer.invoke('app:get-version'),
    getCachedUpdateCheckResult: () => electron_1.ipcRenderer.invoke('app:get-cached-update-check-result'),
    getStartupUpdateInfo: () => electron_1.ipcRenderer.invoke('app:get-startup-update-info'),
    checkForUpdates: () => electron_1.ipcRenderer.invoke('app:check-for-updates'),
    getAutoUpdateState: () => electron_1.ipcRenderer.invoke('app:auto-update-get-state'),
    checkAutoUpdate: () => electron_1.ipcRenderer.invoke('app:auto-update-check'),
    downloadAutoUpdate: () => electron_1.ipcRenderer.invoke('app:auto-update-download'),
    installAutoUpdate: () => electron_1.ipcRenderer.invoke('app:auto-update-install'),
    chooseLogFile: () => electron_1.ipcRenderer.invoke('app:choose-log-file'),
    updateSettings: (patch) => electron_1.ipcRenderer.invoke('app:update-settings', patch),
    simulateZone: (zoneSelector) => electron_1.ipcRenderer.invoke('app:simulate-zone', zoneSelector),
    reloadGuide: () => electron_1.ipcRenderer.invoke('app:reload-guide'),
    resetProgress: () => electron_1.ipcRenderer.invoke('app:reset-progress'),
    resetLevelReminders: () => electron_1.ipcRenderer.invoke('app:reset-level-reminders'),
    setCampaignBonusDone: (bonusId, done) => electron_1.ipcRenderer.invoke('app:set-campaign-bonus-done', bonusId, done),
    resetCampaignBonuses: () => electron_1.ipcRenderer.invoke('app:reset-campaign-bonuses'),
    dismissActiveLevelReminder: () => electron_1.ipcRenderer.invoke('app:dismiss-active-level-reminder'),
    appendDevLogLine: (line) => electron_1.ipcRenderer.invoke('app:append-dev-log-line', line),
    markCurrentChecklistItemDone: () => electron_1.ipcRenderer.invoke('app:mark-current-checklist-item-done'),
    undoLastChecklistMark: () => electron_1.ipcRenderer.invoke('app:undo-last-checklist-mark'),
    armRunTimer: () => electron_1.ipcRenderer.invoke('app:arm-run-timer'),
    startRunTimer: () => electron_1.ipcRenderer.invoke('app:start-run-timer'),
    pauseRunTimer: () => electron_1.ipcRenderer.invoke('app:pause-run-timer'),
    resumeRunTimer: () => electron_1.ipcRenderer.invoke('app:resume-run-timer'),
    resetRunTimer: () => electron_1.ipcRenderer.invoke('app:reset-run-timer'),
    finishRunTimer: () => electron_1.ipcRenderer.invoke('app:finish-run-timer'),
    getRunTimerState: () => electron_1.ipcRenderer.invoke('timer:get-state'),
    isTimerDiagnosticsEnabled: () => Promise.resolve(timerDiagnosticsEnabled),
    sendTimerDiagnostics: (payload) => electron_1.ipcRenderer.invoke('app:timer-diagnostics', payload),
    getOverlayBounds: () => electron_1.ipcRenderer.invoke('app:get-overlay-bounds'),
    resizeOverlay: (width, height) => electron_1.ipcRenderer.invoke('app:resize-overlay', width, height),
    resizeOverlayHeight: (height) => electron_1.ipcRenderer.invoke('app:resize-overlay-height', height),
    setOverlayAutoResizeSuspended: (suspended) => electron_1.ipcRenderer.invoke('app:set-overlay-auto-resize-suspended', suspended),
    setOverlayDragActive: (active) => electron_1.ipcRenderer.invoke('app:set-overlay-drag-active', active),
    setOverlayPosition: (x, y) => electron_1.ipcRenderer.invoke('app:set-overlay-position', x, y),
    setOverlayMode: (mode) => electron_1.ipcRenderer.invoke('app:set-overlay-mode', mode),
    toggleOverlayMode: () => electron_1.ipcRenderer.invoke('app:toggle-overlay-mode'),
    closeOverlay: () => electron_1.ipcRenderer.invoke('app:close-overlay'),
    openCompanionPanel: () => electron_1.ipcRenderer.invoke('app:open-companion-panel'),
    toggleCompanionPanel: () => electron_1.ipcRenderer.invoke('app:toggle-companion-panel'),
    openSettings: () => electron_1.ipcRenderer.invoke('app:open-settings'),
    toggleSettings: () => electron_1.ipcRenderer.invoke('app:toggle-settings'),
    openInfo: () => electron_1.ipcRenderer.invoke('app:open-info'),
    openCommunity: () => electron_1.ipcRenderer.invoke('app:open-community'),
    openSupport: () => electron_1.ipcRenderer.invoke('app:open-support'),
    openReportIssue: () => electron_1.ipcRenderer.invoke('app:open-report-issue'),
    openUpdateDownload: (url) => electron_1.ipcRenderer.invoke('app:open-update-download', url),
    openReleasePage: (url) => electron_1.ipcRenderer.invoke('app:open-release-page', url),
    openExternal: (url) => electron_1.ipcRenderer.invoke('app:open-external', url),
    cancelCloseConfirm: () => electron_1.ipcRenderer.invoke('close-confirm:stay'),
    confirmCloseAndSave: () => electron_1.ipcRenderer.invoke('close-confirm:close-and-save'),
    onAutoUpdateChanged: (callback) => {
        const listener = (_event, state) => {
            callback(state);
        };
        electron_1.ipcRenderer.on('app:auto-update-changed', listener);
        return () => {
            electron_1.ipcRenderer.removeListener('app:auto-update-changed', listener);
        };
    },
    onRunTimerChanged: (callback) => {
        const listener = (_event, runTimer) => {
            callback(runTimer);
        };
        electron_1.ipcRenderer.on('timer:state-changed', listener);
        return () => {
            electron_1.ipcRenderer.removeListener('timer:state-changed', listener);
        };
    },
    onTimerVisualTick: (callback) => {
        const listener = (_event, payload) => {
            callback(payload);
        };
        electron_1.ipcRenderer.on('timer:visual-tick', listener);
        return () => {
            electron_1.ipcRenderer.removeListener('timer:visual-tick', listener);
        };
    },
    onStateChanged: (callback) => {
        const listener = (_event, snapshot) => {
            callback(snapshot);
        };
        electron_1.ipcRenderer.on('app:state-changed', listener);
        return () => {
            electron_1.ipcRenderer.removeListener('app:state-changed', listener);
        };
    }
};
electron_1.contextBridge.exposeInMainWorld('poe2Overlay', api);
//# sourceMappingURL=preload.js.map