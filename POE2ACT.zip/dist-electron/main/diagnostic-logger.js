"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEBUG_LOG_ENV_FLAG = exports.DIAGNOSTIC_LOG_ENV_FLAG = void 0;
exports.isDiagnosticLoggingEnabled = isDiagnosticLoggingEnabled;
exports.diagnosticDebug = diagnosticDebug;
exports.diagnosticInfo = diagnosticInfo;
exports.diagnosticWarn = diagnosticWarn;
exports.diagnosticError = diagnosticError;
exports.DIAGNOSTIC_LOG_ENV_FLAG = 'POE2_DIAGNOSTIC_LOGS';
exports.DEBUG_LOG_ENV_FLAG = 'POE2_DEBUG_LOGS';
function isTruthyEnvValue(value) {
    return /^(1|true|yes|on|debug)$/i.test(String(value ?? '').trim());
}
function isDiagnosticLoggingEnabled() {
    return (isTruthyEnvValue(process.env[exports.DIAGNOSTIC_LOG_ENV_FLAG]) ||
        isTruthyEnvValue(process.env[exports.DEBUG_LOG_ENV_FLAG]));
}
function writeConsole(method, scope, message, payload) {
    const prefix = `[${scope}] ${message}`;
    if (payload === undefined) {
        console[method](prefix);
        return;
    }
    console[method](prefix, payload);
}
function diagnosticDebug(scope, message, payload) {
    if (!isDiagnosticLoggingEnabled()) {
        return;
    }
    writeConsole('debug', scope, message, payload);
}
function diagnosticInfo(scope, message, payload) {
    if (!isDiagnosticLoggingEnabled()) {
        return;
    }
    writeConsole('info', scope, message, payload);
}
function diagnosticWarn(scope, message, payload) {
    writeConsole('warn', scope, message, payload);
}
function diagnosticError(scope, message, payload) {
    writeConsole('error', scope, message, payload);
}
//# sourceMappingURL=diagnostic-logger.js.map