"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runNormalizeCampaignBonusSceneName = runNormalizeCampaignBonusSceneName;
exports.runGetCampaignBonusContextGuideIds = runGetCampaignBonusContextGuideIds;
exports.runCampaignBonusRuleMatches = runCampaignBonusRuleMatches;
exports.runSetCampaignBonusDone = runSetCampaignBonusDone;
exports.runCampaignBonusMatchesChecklistItem = runCampaignBonusMatchesChecklistItem;
exports.runSyncCampaignBonusWithChecklist = runSyncCampaignBonusWithChecklist;
exports.runCampaignBonusTextIncludesAny = runCampaignBonusTextIncludesAny;
exports.runCampaignBonusTextIncludesAll = runCampaignBonusTextIncludesAll;
exports.runCampaignBonusRewardMatchesParsedReward = runCampaignBonusRewardMatchesParsedReward;
exports.runGetCampaignBonusRewardFallbackScore = runGetCampaignBonusRewardFallbackScore;
exports.runGetCampaignBonusRewardFallbackMinScore = runGetCampaignBonusRewardFallbackMinScore;
exports.runFindCampaignBonusFromParsedReward = runFindCampaignBonusFromParsedReward;
exports.runGetCampaignBonusLogLineDedupeKey = runGetCampaignBonusLogLineDedupeKey;
exports.runRememberCampaignBonusLogLineKey = runRememberCampaignBonusLogLineKey;
exports.runApplyCampaignBonusMatchesFromLogLine = runApplyCampaignBonusMatchesFromLogLine;
const log_parser_1 = require("./services/log-parser");
const checklist_1 = require("../shared/checklist");
function runNormalizeCampaignBonusSceneName(value) {
    return (0, log_parser_1.normalizeText)(value ?? '');
}
function runGetCampaignBonusContextGuideIds() {
    const ids = new Set();
    const currentGuideId = this.currentZone.guide?.id ?? null;
    const lastGameplayGuideId = this.runtime.lastGameplayGuideId ?? null;
    if (this.currentZone.sceneKind === 'town') {
        if (lastGameplayGuideId) {
            ids.add(lastGameplayGuideId);
        }
    }
    else if (currentGuideId) {
        ids.add(currentGuideId);
    }
    if (ids.size === 0 && this.currentZone.sceneKind !== 'town' && lastGameplayGuideId) {
        ids.add(lastGameplayGuideId);
    }
    return ids;
}
function runCampaignBonusRuleMatches(rule, line) {
    const normalizedLine = (0, log_parser_1.normalizeText)(line);
    if (rule.all.some((phrase) => !normalizedLine.includes((0, log_parser_1.normalizeText)(phrase)))) {
        return false;
    }
    if (rule.any && rule.any.length > 0) {
        const hasAny = rule.any.some((phrase) => normalizedLine.includes((0, log_parser_1.normalizeText)(phrase)));
        if (!hasAny) {
            return false;
        }
    }
    if (rule.none && rule.none.some((phrase) => normalizedLine.includes((0, log_parser_1.normalizeText)(phrase)))) {
        return false;
    }
    const contextGuideIds = this.getCampaignBonusContextGuideIds();
    if (rule.zoneIds && rule.zoneIds.length > 0) {
        const hasAllowedZone = rule.zoneIds.some((zoneId) => contextGuideIds.has(zoneId));
        if (!hasAllowedZone) {
            return false;
        }
    }
    if (rule.sceneNames && rule.sceneNames.length > 0) {
        const currentScene = this.normalizeCampaignBonusSceneName(this.currentZone.rawZoneName);
        const currentGuideName = this.normalizeCampaignBonusSceneName(this.currentZone.guide?.zone_ru);
        const allowedScenes = rule.sceneNames.map((scene) => this.normalizeCampaignBonusSceneName(scene));
        if (!allowedScenes.includes(currentScene) && !allowedScenes.includes(currentGuideName)) {
            return false;
        }
    }
    return true;
}
function runSetCampaignBonusDone(bonusId, detectedBy, line = null) {
    const existing = this.config.campaignBonusProgress[bonusId];
    const nextProgress = { ...this.config.campaignBonusProgress };
    if (detectedBy === null) {
        if (!existing) {
            return false;
        }
        delete nextProgress[bonusId];
    }
    else {
        nextProgress[bonusId] = {
            state: 'done',
            timestamp: new Date().toISOString(),
            detectedBy,
            ...(line ? { logLine: line } : {})
        };
    }
    const matchedBonus = this.campaignBonuses.find((bonus) => bonus.id === bonusId) ?? null;
    this.config = this.configStore.update({
        campaignBonusProgress: nextProgress
    });
    if (matchedBonus) {
        this.syncCampaignBonusWithChecklist(matchedBonus, detectedBy, line);
    }
    this.broadcastState();
    return true;
}
function runCampaignBonusMatchesChecklistItem(bonus, item, normalizedLine) {
    const normalizedTitle = (0, log_parser_1.normalizeText)(bonus.title);
    const normalizedItemText = (0, log_parser_1.normalizeText)(item.text);
    const normalizedSource = (0, log_parser_1.normalizeText)(bonus.source);
    const keywordTexts = item.autoCompleteKeywords.map((keyword) => (0, log_parser_1.normalizeText)(keyword));
    if (normalizedTitle && (normalizedItemText.includes(normalizedTitle) ||
        normalizedTitle.includes(normalizedItemText))) {
        return true;
    }
    if (keywordTexts.some((keyword) => keyword && (normalizedLine.includes(keyword) ||
        normalizedTitle.includes(keyword) ||
        normalizedItemText.includes(keyword) ||
        normalizedSource.includes(keyword)))) {
        return true;
    }
    if (bonus.category === 'resistance' && item.type === 'resistance') {
        const elementWords = ['холод', 'огн', 'молни'];
        return elementWords.some((word) => normalizedTitle.includes(word) && normalizedItemText.includes(word));
    }
    if (bonus.category === 'spirit') {
        return item.type === 'spirit' || normalizedItemText.includes('дух');
    }
    if (bonus.category === 'life') {
        return item.type === 'life' || normalizedItemText.includes('здоров');
    }
    if (bonus.category === 'mana') {
        return item.type === 'mana' || normalizedItemText.includes('ман');
    }
    if (bonus.category === 'weapon_set_passive') {
        return normalizedItemText.includes('пассив') || normalizedItemText.includes('очк');
    }
    return false;
}
function runSyncCampaignBonusWithChecklist(bonus, detectedBy, line) {
    if (!bonus.zoneId) {
        return;
    }
    const guide = this.guideService.findById(bonus.zoneId);
    if (!guide?.checklist?.length) {
        return;
    }
    const checklist = (0, checklist_1.buildChecklistDefinition)(guide);
    const normalizedLine = (0, log_parser_1.normalizeText)(line ?? '');
    const directItemIds = new Set();
    for (const item of checklist) {
        if (this.campaignBonusMatchesChecklistItem(bonus, item, normalizedLine)) {
            directItemIds.add(item.id);
        }
    }
    if (directItemIds.size === 0) {
        return;
    }
    const allItemIds = new Set(directItemIds);
    for (const item of checklist) {
        if (item.linkedChecklistItemIds?.some((linkedId) => directItemIds.has(linkedId))) {
            allItemIds.add(item.id);
        }
    }
    const currentProgress = this.config.zoneProgress[guide.id] ?? {
        itemStates: {},
        likelyDoneKeywords: [],
        lastVisitedAt: null
    };
    const nextItemStates = { ...currentProgress.itemStates };
    if (detectedBy === null) {
        for (const itemId of allItemIds) {
            const existing = nextItemStates[itemId];
            if (existing?.detectedBy === 'log' || existing?.detectedBy === 'manual' || existing?.detectedBy === 'linked_reward') {
                delete nextItemStates[itemId];
            }
        }
    }
    else {
        const timestamp = new Date().toISOString();
        for (const itemId of allItemIds) {
            const item = checklist.find((entry) => entry.id === itemId);
            if (!item) {
                continue;
            }
            const isLinked = !directItemIds.has(itemId);
            nextItemStates[itemId] = {
                state: 'done',
                timestamp,
                detectedBy: isLinked ? 'linked_reward' : detectedBy,
                originalText: item.text
            };
        }
    }
    this.config = this.configStore.update({
        zoneProgress: {
            ...this.config.zoneProgress,
            [guide.id]: {
                ...currentProgress,
                itemStates: nextItemStates,
                lastVisitedAt: currentProgress.lastVisitedAt ?? new Date().toISOString()
            }
        }
    });
}
function runCampaignBonusTextIncludesAny(bonus, keywords) {
    const searchText = (0, log_parser_1.normalizeText)([bonus.title, bonus.source, ...(bonus.details ?? [])].join(' '));
    return keywords.some((keyword) => {
        const normalizedKeyword = (0, log_parser_1.normalizeText)(keyword);
        return normalizedKeyword ? searchText.includes(normalizedKeyword) : false;
    });
}
function runCampaignBonusTextIncludesAll(bonus, keywords) {
    const searchText = (0, log_parser_1.normalizeText)([bonus.title, bonus.source, ...(bonus.details ?? [])].join(' '));
    return keywords.every((keyword) => {
        const normalizedKeyword = (0, log_parser_1.normalizeText)(keyword);
        return normalizedKeyword ? searchText.includes(normalizedKeyword) : false;
    });
}
function runCampaignBonusRewardMatchesParsedReward(bonus, reward) {
    if (!reward) {
        return false;
    }
    const value = Number(bonus.reward.value) || 0;
    const amount = reward.amount ?? value;
    const element = (0, log_parser_1.normalizeText)(reward.element ?? reward.matchedKeywords.join(' '));
    switch (reward.rewardKey) {
        case 'passivePoints':
            return false;
        case 'weaponSetPassivePoints':
            return bonus.reward.type === 'weapon_set_passive_points' && value === amount;
        case 'coldResistance10':
            return bonus.reward.type === 'cold_resistance' && value === amount;
        case 'lightningResistance10':
            return bonus.reward.type === 'lightning_resistance' && value === amount;
        case 'fireResistance10':
            return bonus.reward.type === 'fire_resistance' && value === amount;
        case 'resistance5':
            if (element.includes('всем') || element.includes('стих')) {
                return bonus.reward.type === 'all_elemental_resistance' && value === amount;
            }
            if (element.includes('холод') || element.includes('cold')) {
                return bonus.reward.type === 'cold_resistance' && value === amount;
            }
            if (element.includes('молн') || element.includes('lightning')) {
                return bonus.reward.type === 'lightning_resistance' && value === amount;
            }
            if (element.includes('огн') || element.includes('fire')) {
                return bonus.reward.type === 'fire_resistance' && value === amount;
            }
            return bonus.reward.type === 'all_elemental_resistance' && value === amount;
        case 'spirit30':
        case 'spirit40':
            return bonus.reward.type === 'spirit' && value === amount;
        case 'life20':
            return bonus.reward.type === 'flat_life' && value === amount;
        case 'life5':
            return bonus.reward.type === 'increased_life' && value === amount;
        case 'mana5':
            return bonus.reward.type === 'increased_mana' && value === amount;
        case 'flatMana':
            return bonus.category === 'mana' && value === amount;
        case 'charmSlot':
            return (this.campaignBonusTextIncludesAll(bonus, ['charm', 'slot']) ||
                this.campaignBonusTextIncludesAll(bonus, ['\u043e\u0431\u0435\u0440\u0435\u0433', '\u044f\u0447\u0435\u0439']));
        case 'charmChargeGain':
            return (this.campaignBonusTextIncludesAny(bonus, ['charm', '\u043e\u0431\u0435\u0440\u0435\u0433']) &&
                this.campaignBonusTextIncludesAny(bonus, ['charge', 'duration', '\u0437\u0430\u0440\u044f\u0434', '\u0434\u043b\u0438\u0442\u0435\u043b']));
        case 'flaskLifeRecovery':
            return (this.campaignBonusTextIncludesAny(bonus, ['flask', '\u0444\u043b\u0430\u043a\u043e\u043d']) &&
                this.campaignBonusTextIncludesAny(bonus, ['life recovery', '\u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b', '\u0437\u0434\u043e\u0440\u043e\u0432']));
        case 'stunThreshold':
            return this.campaignBonusTextIncludesAny(bonus, ['stun', '\u043e\u0433\u043b\u0443\u0448']);
        case 'elementalAilmentThreshold':
            return this.campaignBonusTextIncludesAny(bonus, ['elemental ailment', 'ailment', '\u0441\u0442\u0438\u0445\u0438\u0439\u043d', '\u0441\u043e\u0441\u0442\u043e\u044f\u043d']);
        default:
            return false;
    }
}
function runGetCampaignBonusRewardFallbackScore(bonus) {
    let score = 0;
    const contextGuideIds = this.getCampaignBonusContextGuideIds();
    const currentAct = this.currentZone.sceneKind === 'town'
        ? (this.runtime.lastGameplayAct ?? this.currentZone.actHint ?? null)
        : (this.currentZone.guide?.act ?? this.currentZone.actHint ?? null);
    const currentScene = this.normalizeCampaignBonusSceneName(this.currentZone.rawZoneName);
    const currentGuideName = this.currentZone.sceneKind === 'town'
        ? ''
        : this.normalizeCampaignBonusSceneName(this.currentZone.guide?.zone_ru);
    const bonusScene = this.normalizeCampaignBonusSceneName(bonus.zone_ru);
    if (contextGuideIds.has(bonus.zoneId)) {
        score += 100;
    }
    if (bonusScene && (bonusScene === currentScene || bonusScene === currentGuideName)) {
        score += 60;
    }
    if (currentAct && bonus.act === currentAct) {
        score += 20;
    }
    if (bonus.needsVerification) {
        score -= 2;
    }
    return score;
}
function runGetCampaignBonusRewardFallbackMinScore(parsedReward) {
    switch (parsedReward?.rewardKey) {
        case 'weaponSetPassivePoints':
            // There are several identical +2 weapon-set rewards inside the same act.
            // Mark them only when the current/last gameplay zone points to the exact reward zone.
            return 80;
        case 'spirit30':
        case 'spirit40':
        case 'resistance5':
        case 'coldResistance10':
        case 'lightningResistance10':
        case 'fireResistance10':
        case 'life20':
        case 'life5':
        case 'mana5':
        case 'flatMana':
        case 'charmSlot':
        case 'charmChargeGain':
        case 'flaskLifeRecovery':
        case 'stunThreshold':
        case 'elementalAilmentThreshold':
            // For non-weapon permanent rewards the act context is enough, but a zero-score
            // fallback is too risky: a repeated +30 Spirit line could otherwise tick the next
            // uncompleted +30 Spirit bonus in another act.
            return 20;
        default:
            return 1;
    }
}
function runFindCampaignBonusFromParsedReward(line, parsedReward) {
    const reward = parsedReward ?? (0, log_parser_1.parsePermanentReward)(line);
    if (!reward) {
        return null;
    }
    const candidates = this.campaignBonuses
        .map((bonus, index) => ({ bonus, index, score: this.getCampaignBonusRewardFallbackScore(bonus) }))
        .filter(({ bonus }) => !this.config.campaignBonusProgress[bonus.id])
        .filter(({ bonus }) => this.campaignBonusRewardMatchesParsedReward(bonus, reward))
        .sort((left, right) => right.score - left.score || left.index - right.index);
    const best = candidates[0] ?? null;
    if (!best) {
        return null;
    }
    if (best.score < this.getCampaignBonusRewardFallbackMinScore(reward)) {
        return null;
    }
    return best.bonus;
}
function runGetCampaignBonusLogLineDedupeKey(line, parsedReward) {
    const normalizedLine = (0, log_parser_1.normalizeText)(line);
    const rewardPart = parsedReward
        ? [parsedReward.rewardKey, parsedReward.amount ?? '', parsedReward.element ?? '', parsedReward.sourceText ?? ''].join('|')
        : normalizedLine;
    return `${rewardPart}|${normalizedLine}`;
}
function runRememberCampaignBonusLogLineKey(key) {
    if (!key) {
        return;
    }
    this.processedCampaignRewardLogLineKeys.add(key);
    this.processedCampaignRewardLogLineOrder.push(key);
    const maxSize = 250;
    while (this.processedCampaignRewardLogLineOrder.length > maxSize) {
        const oldest = this.processedCampaignRewardLogLineOrder.shift();
        if (oldest) {
            this.processedCampaignRewardLogLineKeys.delete(oldest);
        }
    }
}
function runApplyCampaignBonusMatchesFromLogLine(line, source) {
    // Old log tail must not resurrect progress after reset. Only live appended
    // lines are allowed to softly tick campaign bonuses.
    if (source !== 'append') {
        return;
    }
    const parsedReward = (0, log_parser_1.parsePermanentReward)(line);
    const dedupeKey = this.getCampaignBonusLogLineDedupeKey(line, parsedReward);
    if (this.processedCampaignRewardLogLineKeys.has(dedupeKey)) {
        return;
    }
    // PoE2 can write two neighbouring lines for one weapon-set reward:
    // 1) generic passive points, 2) weapon-set passive points.
    // The generic line must not complete the next/nearby weapon-set bonus.
    if (parsedReward?.rewardKey === 'passivePoints') {
        this.rememberCampaignBonusLogLineKey(dedupeKey);
        return;
    }
    const matchedByExplicitRule = this.campaignBonuses.find((bonus) => {
        if (this.config.campaignBonusProgress[bonus.id]) {
            return false;
        }
        return bonus.eventRules.some((rule) => this.campaignBonusRuleMatches(rule, line));
    });
    const matchedBonus = matchedByExplicitRule ?? this.findCampaignBonusFromParsedReward(line, parsedReward);
    if (!matchedBonus) {
        return;
    }
    const changed = this.setCampaignBonusDone(matchedBonus.id, 'log', line);
    if (changed) {
        this.rememberCampaignBonusLogLineKey(dedupeKey);
    }
}
//# sourceMappingURL=app-campaign-bonus-controller.js.map