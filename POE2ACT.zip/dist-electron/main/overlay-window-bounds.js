"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cloneOverlayBounds = cloneOverlayBounds;
exports.areOverlayBoundsEqual = areOverlayBoundsEqual;
exports.areOverlayBoundsSizeEqual = areOverlayBoundsSizeEqual;
exports.canSourceChangeOverlaySize = canSourceChangeOverlaySize;
exports.planOverlayBoundsChange = planOverlayBoundsChange;
exports.shouldIgnoreOverlayAutoHeight = shouldIgnoreOverlayAutoHeight;
const SIZE_CHANGE_ALLOWED_SOURCES = new Set([
    'manualResize',
    'autoHeight',
    'modeSwitch',
    'restoreBounds'
]);
function roundBounds(bounds, fallback) {
    return {
        x: Math.round(Number(bounds.x) || fallback.x),
        y: Math.round(Number(bounds.y) || fallback.y),
        width: Math.round(Number(bounds.width) || fallback.width),
        height: Math.round(Number(bounds.height) || fallback.height)
    };
}
function cloneOverlayBounds(bounds) {
    return {
        x: bounds.x,
        y: bounds.y,
        width: bounds.width,
        height: bounds.height
    };
}
function areOverlayBoundsEqual(left, right) {
    return (left.x === right.x &&
        left.y === right.y &&
        left.width === right.width &&
        left.height === right.height);
}
function areOverlayBoundsSizeEqual(left, right) {
    return left.width === right.width && left.height === right.height;
}
function canSourceChangeOverlaySize(source) {
    return SIZE_CHANGE_ALLOWED_SOURCES.has(source);
}
function planOverlayBoundsChange(input) {
    const currentBounds = roundBounds(input.currentBounds, input.currentBounds);
    const requestedBounds = roundBounds(input.requestedBounds, currentBounds);
    if (input.source === 'dragMove') {
        const nextBounds = {
            x: requestedBounds.x,
            y: requestedBounds.y,
            width: currentBounds.width,
            height: currentBounds.height
        };
        return {
            source: input.source,
            currentBounds,
            requestedBounds,
            nextBounds,
            applyMode: nextBounds.x === currentBounds.x && nextBounds.y === currentBounds.y
                ? 'none'
                : 'setPosition',
            changed: !areOverlayBoundsEqual(currentBounds, nextBounds),
            suspiciousSizeChange: requestedBounds.width !== currentBounds.width ||
                requestedBounds.height !== currentBounds.height
        };
    }
    const nextBounds = requestedBounds;
    const sizeChanged = !areOverlayBoundsSizeEqual(currentBounds, nextBounds);
    return {
        source: input.source,
        currentBounds,
        requestedBounds,
        nextBounds,
        applyMode: areOverlayBoundsEqual(currentBounds, nextBounds) ? 'none' : 'setBounds',
        changed: !areOverlayBoundsEqual(currentBounds, nextBounds),
        suspiciousSizeChange: sizeChanged && !canSourceChangeOverlaySize(input.source)
    };
}
function shouldIgnoreOverlayAutoHeight(input) {
    const now = input.now ?? Date.now();
    return input.dragInProgress || now < input.suspendedUntil;
}
//# sourceMappingURL=overlay-window-bounds.js.map