"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DIRECT_COMPOSITION_COMPAT_ENABLED = void 0;
exports.configureElectronStartup = configureElectronStartup;
const electron_1 = require("electron");
exports.DIRECT_COMPOSITION_COMPAT_ENABLED = process.platform === 'win32';
function configureElectronStartup() {
    electron_1.app.commandLine.appendSwitch('disable-renderer-backgrounding');
    electron_1.app.commandLine.appendSwitch('disable-background-timer-throttling');
    electron_1.app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
    electron_1.app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion,IntensiveWakeUpThrottling');
    if (exports.DIRECT_COMPOSITION_COMPAT_ENABLED) {
        // Compatibility mode for smoother inactive always-on-top overlay rendering over games on Windows.
        electron_1.app.commandLine.appendSwitch('disable-direct-composition');
        electron_1.app.commandLine.appendSwitch('disable-direct-composition-video-overlays');
    }
    if (process.platform === 'linux') {
        const requestedOzonePlatform = String(process.env.POE2_OVERLAY_OZONE_PLATFORM ?? '').trim().toLowerCase();
        // Transparent Electron overlays are still compositor-sensitive on Linux.
        // Wayland sessions are forced through XWayland by default because the overlay relies on alpha.
        // Advanced users can opt back into native Wayland with POE2_OVERLAY_OZONE_PLATFORM=wayland.
        if (requestedOzonePlatform === 'x11' || requestedOzonePlatform === 'wayland') {
            electron_1.app.commandLine.appendSwitch('ozone-platform', requestedOzonePlatform);
        }
        else if (process.env.WAYLAND_DISPLAY) {
            electron_1.app.commandLine.appendSwitch('ozone-platform', 'x11');
        }
        electron_1.app.commandLine.appendSwitch('enable-transparent-visuals');
    }
    if (process.platform === 'win32') {
        electron_1.app.setAppUserModelId('com.codex.poe2-campaign-overlay');
    }
}
//# sourceMappingURL=electron-startup.js.map