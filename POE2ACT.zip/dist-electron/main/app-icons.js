"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTrayIcon = createTrayIcon;
exports.createAppIcon = createAppIcon;
const electron_1 = require("electron");
const runtime_paths_1 = require("./services/runtime-paths");
function createTrayIcon() {
    const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">
      <rect width="32" height="32" rx="8" fill="#11161e"/>
      <path d="M9 8h14v3H12v4h9v3h-9v6H9z" fill="#ffd27a"/>
      <circle cx="23" cy="23" r="3" fill="#ff6c6c"/>
    </svg>
  `;
    return electron_1.nativeImage.createFromDataURL(`data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`);
}
function createAppIcon() {
    const iconPath = process.platform === 'win32'
        ? (0, runtime_paths_1.resolveRuntimePath)('assets', 'app-icon.ico')
        : (0, runtime_paths_1.resolveRuntimePath)('assets', 'app-icon.png');
    const icon = electron_1.nativeImage.createFromPath(iconPath);
    return icon.isEmpty() ? createTrayIcon() : icon;
}
//# sourceMappingURL=app-icons.js.map