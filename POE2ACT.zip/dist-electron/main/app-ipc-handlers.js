"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runRegisterIpc = runRegisterIpc;
const promises_1 = require("node:fs/promises");
const electron_1 = require("electron");
const overlay_window_bounds_1 = require("./overlay-window-bounds");
const timer_diagnostics_log_1 = require("./timer-diagnostics-log");
const app_environment_1 = require("./app-environment");
function runRegisterIpc() {
    electron_1.ipcMain.handle('app:get-snapshot', async () => this.getSnapshot());
    electron_1.ipcMain.handle('app:get-version', async () => electron_1.app.getVersion());
    electron_1.ipcMain.handle('app:get-cached-update-check-result', async () => this.cachedUpdateCheckResult);
    electron_1.ipcMain.handle('app:get-startup-update-info', async () => this.startupUpdateInfo);
    electron_1.ipcMain.handle('app:check-for-updates', async () => this.checkForUpdates(true));
    electron_1.ipcMain.handle('app:auto-update-get-state', async () => this.autoUpdateService.getState());
    electron_1.ipcMain.handle('app:auto-update-check', async () => this.autoUpdateService.checkForUpdates());
    electron_1.ipcMain.handle('app:auto-update-download', async () => this.autoUpdateService.downloadUpdate());
    electron_1.ipcMain.handle('app:auto-update-install', async () => this.installAutoUpdate());
    electron_1.ipcMain.handle('timer:get-state', async () => this.config.runTimer);
    electron_1.ipcMain.handle('app:get-overlay-bounds', async () => {
        const targetWindow = this.overlayWindow;
        if (!targetWindow || targetWindow.isDestroyed()) {
            return null;
        }
        return targetWindow.getBounds();
    });
    electron_1.ipcMain.handle('close-confirm:stay', async () => {
        this.settleCloseConfirm('stay');
        return true;
    });
    electron_1.ipcMain.handle('close-confirm:close-and-save', async () => {
        this.settleCloseConfirm('close_and_save');
        return true;
    });
    electron_1.ipcMain.handle('app:choose-log-file', async () => {
        const owner = this.settingsWindow ?? this.overlayWindow;
        const dialogOptions = {
            title: this.t('main.chooseLogFileTitle'),
            properties: ['openFile'],
            filters: [
                { name: this.t('main.logFileFilter'), extensions: ['txt'] },
                { name: this.t('main.allFilesFilter'), extensions: ['*'] }
            ]
        };
        const result = owner
            ? await electron_1.dialog.showOpenDialog(owner, dialogOptions)
            : await electron_1.dialog.showOpenDialog(dialogOptions);
        if (result.canceled || result.filePaths.length === 0) {
            return null;
        }
        const selectedPath = result.filePaths[0] ?? null;
        if (selectedPath) {
            this.config = this.configStore.update({
                logFilePath: selectedPath,
                logFileSelectionMode: 'manual'
            });
            await this.startLogWatcher(selectedPath);
            this.broadcastState();
        }
        return selectedPath;
    });
    electron_1.ipcMain.handle('app:update-settings', async (_event, patch) => {
        const previousOverlayMode = this.overlayMode;
        const previousOverlayDensity = this.config.overlayDensity;
        const previousOverlayScale = this.config.overlayScale;
        const nextOverlayMode = patch.mainOverlaySettings?.overlayMode ?? previousOverlayMode;
        const nextOverlayDensity = patch.overlayDensity ?? previousOverlayDensity;
        const nextOverlayScale = patch.overlayScale ?? previousOverlayScale;
        const overlayLayoutChanged = nextOverlayMode !== previousOverlayMode || nextOverlayDensity !== previousOverlayDensity;
        const overlayConstraintsChanged = overlayLayoutChanged || nextOverlayScale !== previousOverlayScale;
        const previousOverlayBounds = overlayConstraintsChanged && this.overlayWindow && !this.overlayWindow.isDestroyed()
            ? this.overlayWindow.getBounds()
            : null;
        if (overlayLayoutChanged && previousOverlayBounds) {
            if (this.overlayBoundsTimer) {
                clearTimeout(this.overlayBoundsTimer);
                this.overlayBoundsTimer = null;
            }
            this.persistOverlayBoundsForState(previousOverlayMode, previousOverlayDensity, previousOverlayBounds);
        }
        this.config = this.configStore.updateSettings({
            ...patch,
            ...(patch.overlayOpacity !== undefined
                ? { overlayOpacity: (0, app_environment_1.clampOpacity)(patch.overlayOpacity) }
                : {})
        });
        if (patch.overlayOpacity !== undefined) {
            this.overlayWindow?.setOpacity(this.config.overlayOpacity);
        }
        if (patch.companionAlwaysOnTop !== undefined) {
            this.companionWindow?.setAlwaysOnTop(this.config.companionAlwaysOnTop);
        }
        if (patch.runTimerSettings !== undefined) {
            this.reconcileRunTimerState();
        }
        if (patch.hotkeys !== undefined || patch.manualHotkeysEnabled !== undefined) {
            this.registerGlobalHotkeys();
        }
        if (patch.mainOverlaySettings?.overlayMode) {
            this.overlayMode = patch.mainOverlaySettings.overlayMode;
            this.runtime.overlayMode = this.overlayMode;
        }
        if (overlayConstraintsChanged && this.overlayWindow && !this.overlayWindow.isDestroyed()) {
            const minimumSize = this.getOverlayMinimumSize(this.overlayMode, this.config.overlayDensity, this.config.overlayScale);
            const nextBounds = overlayLayoutChanged
                ? this.getOverlayBoundsForMode(this.overlayMode, this.config.overlayDensity)
                : this.normalizeOverlayBoundsForMode(previousOverlayBounds ?? this.overlayWindow.getBounds(), this.overlayMode, this.config.overlayDensity);
            this.applyOverlayWindowBounds('modeSwitch', nextBounds, { minimumSize });
        }
        this.refreshTrayMenu();
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:simulate-zone', async (_event, zoneSelector) => {
        const guide = this.guideService.findById(zoneSelector) ??
            this.guideService.findByZoneName(zoneSelector);
        if (guide) {
            this.setCurrentZone(guide.zone_ru, 'simulation', guide);
        }
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:reload-guide', async () => {
        this.loadGuide();
        this.rebindCurrentZoneAfterGuideReload();
        await this.logWatcher.seekToEnd();
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:reset-progress', async () => {
        this.clearRunTimerStartTimer();
        this.config = this.configStore.resetProgress();
        this.checklistHistory.length = 0;
        this.currentZone = {
            rawZoneName: null,
            guide: null,
            sceneKind: 'unknown',
            actHint: null
        };
        this.runtime.lastRawZoneName = null;
        this.runtime.lastMatchedZoneEn = null;
        this.runtime.lastMatchedZoneRu = null;
        this.runtime.lastMatchedGuideId = null;
        this.runtime.lastGameplayGuideId = null;
        this.runtime.lastGameplayZoneRu = null;
        this.runtime.lastGameplayAct = null;
        this.runtime.lastZoneSource = null;
        this.runtime.lastLevelUpDetectedAt = null;
        this.runtime.missedWarningZoneRu = null;
        this.runtime.missedWarningItems = [];
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:reset-level-reminders', async () => {
        this.config = this.configStore.update({
            levelRemindersState: {
                shown: [],
                dismissed: [],
                activeLevelReminderId: null
            }
        });
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:set-campaign-bonus-done', async (_event, bonusId, done) => {
        this.setCampaignBonusDone(bonusId, done ? 'manual' : null, null);
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:reset-campaign-bonuses', async () => {
        this.config = this.configStore.update({
            campaignBonusProgress: {}
        });
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:dismiss-active-level-reminder', async () => {
        const state = this.config.levelRemindersState ?? {
            shown: [],
            dismissed: [],
            activeLevelReminderId: null
        };
        const activeId = state.activeLevelReminderId;
        this.config = this.configStore.update({
            levelRemindersState: {
                shown: state.shown ?? [],
                dismissed: activeId
                    ? Array.from(new Set([...(state.dismissed ?? []), activeId]))
                    : state.dismissed ?? [],
                activeLevelReminderId: null
            }
        });
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:append-dev-log-line', async (_event, rawLine) => {
        const targetPath = this.config.logFilePath ?? this.runtime.watchedLogPath;
        if (!targetPath) {
            return this.getSnapshot();
        }
        const line = rawLine.trim() || app_environment_1.DEV_SAMPLE_ZONE_LINE;
        const payload = line.endsWith('\n') ? line : `${line}\r\n`;
        await (0, promises_1.appendFile)(targetPath, payload, 'utf8');
        await this.refreshLogFileInfo(targetPath);
        await this.logWatcher.checkNow();
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:mark-current-checklist-item-done', async () => {
        this.markCurrentChecklistItemDone();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:undo-last-checklist-mark', async () => {
        this.undoLastChecklistMark();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:arm-run-timer', async () => {
        this.armRunTimer();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:start-run-timer', async () => {
        this.startRunTimerNow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:pause-run-timer', async () => {
        this.pauseRunTimer();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:resume-run-timer', async () => {
        this.resumeRunTimer();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:reset-run-timer', async () => {
        this.resetRunTimer();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:finish-run-timer', async () => {
        this.finishRunTimer();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:timer-diagnostics', async (_event, payload) => {
        if (!(0, timer_diagnostics_log_1.isTimerDiagnosticsEnabled)()) {
            return false;
        }
        if (!payload || typeof payload.event !== 'string' || typeof payload.source !== 'string') {
            return false;
        }
        return await this.timerDiagnosticsLog.write(this.buildTimerDiagnosticsRecord(payload));
    });
    electron_1.ipcMain.handle('app:resize-overlay', async (_event, width, height) => {
        const targetWindow = this.overlayWindow;
        if (!targetWindow || targetWindow.isDestroyed()) {
            return this.getSnapshot();
        }
        const currentBounds = targetWindow.getBounds();
        const nextBounds = this.normalizeOverlayBoundsForMode({
            x: currentBounds.x,
            y: currentBounds.y,
            width: Math.round(Number(width) || currentBounds.width),
            height: Math.round(Number(height) || currentBounds.height)
        }, this.overlayMode, this.config.overlayDensity);
        this.applyOverlayWindowBounds('manualResize', nextBounds);
        this.persistOverlayBoundsForCurrentState(targetWindow.getBounds());
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:set-overlay-auto-resize-suspended', async (_event, suspended) => {
        this.overlayAutoResizeSuspendedUntil = suspended
            ? Date.now() + 2500
            : Math.max(this.overlayAutoResizeSuspendedUntil, Date.now() + 500);
        return true;
    });
    electron_1.ipcMain.handle('app:set-overlay-drag-active', async (_event, active) => {
        const dragActive = Boolean(active);
        this.overlayDragInProgress = dragActive;
        if (dragActive && this.overlayWindow && !this.overlayWindow.isDestroyed()) {
            this.overlayDragBounds = this.overlayWindow.getBounds();
            this.lastOverlayKnownBounds = this.overlayDragBounds;
            this.overlayAutoResizeSuspendedUntil = Math.max(this.overlayAutoResizeSuspendedUntil, Date.now() + 1500);
            this.logOverlayBoundsEvent('info', {
                phase: 'drag-state',
                source: 'dragMove',
                active: true,
                bounds: this.overlayDragBounds
            });
            return true;
        }
        const finalBounds = this.overlayWindow && !this.overlayWindow.isDestroyed()
            ? this.overlayWindow.getBounds()
            : this.overlayDragBounds;
        this.overlayDragBounds = null;
        this.overlayAutoResizeSuspendedUntil = Math.max(this.overlayAutoResizeSuspendedUntil, Date.now() + 500);
        this.logOverlayBoundsEvent('info', {
            phase: 'drag-state',
            source: 'dragMove',
            active: false,
            bounds: finalBounds ?? null
        });
        if (finalBounds) {
            this.lastOverlayKnownBounds = finalBounds;
        }
        return true;
    });
    electron_1.ipcMain.handle('app:resize-overlay-height', async (_event, height) => {
        const targetWindow = this.overlayWindow;
        if (!targetWindow || targetWindow.isDestroyed()) {
            return this.getSnapshot();
        }
        if ((0, overlay_window_bounds_1.shouldIgnoreOverlayAutoHeight)({
            dragInProgress: this.overlayDragInProgress,
            suspendedUntil: this.overlayAutoResizeSuspendedUntil
        })) {
            this.logOverlayBoundsEvent('info', {
                phase: 'auto-height-ignored',
                source: 'autoHeight',
                reason: this.overlayDragInProgress ? 'dragActive' : 'suspended',
                requestedHeight: Math.round(Number(height) || targetWindow.getBounds().height),
                bounds: targetWindow.getBounds()
            });
            return this.getSnapshot();
        }
        const currentBounds = targetWindow.getBounds();
        const nextBounds = this.normalizeOverlayBoundsForMode({
            ...currentBounds,
            height: Math.round(Number(height) || currentBounds.height)
        }, this.overlayMode, this.config.overlayDensity);
        this.applyOverlayWindowBounds('autoHeight', nextBounds);
        this.persistOverlayBoundsForCurrentState(targetWindow.getBounds());
        this.broadcastState();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:set-overlay-position', async (_event, x, y) => {
        this.overlayAutoResizeSuspendedUntil = Math.max(this.overlayAutoResizeSuspendedUntil, Date.now() + 800);
        const targetWindow = this.overlayWindow;
        if (!targetWindow || targetWindow.isDestroyed()) {
            return false;
        }
        const currentBounds = targetWindow.getBounds();
        const nextX = Math.round(Number(x) || currentBounds.x);
        const nextY = Math.round(Number(y) || currentBounds.y);
        if (nextX === currentBounds.x && nextY === currentBounds.y) {
            return true;
        }
        this.applyOverlayWindowBounds('dragMove', {
            ...currentBounds,
            x: nextX,
            y: nextY
        });
        return true;
    });
    electron_1.ipcMain.handle('app:set-overlay-mode', async (_event, mode) => {
        this.setOverlayMode(mode);
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:toggle-overlay-mode', async () => {
        this.toggleOverlayMode();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:close-overlay', async () => this.requestCloseOverlayWindow());
    electron_1.ipcMain.handle('app:open-companion-panel', async () => {
        this.openCompanionWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:toggle-companion-panel', async () => {
        this.toggleCompanionWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:open-settings', async () => {
        this.openSettingsWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:toggle-settings', async () => {
        this.toggleSettingsWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:open-info', async () => {
        this.openInfoWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:open-community', async () => {
        this.openCommunityWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:open-support', async () => {
        this.openSupportWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:open-report-issue', async () => {
        this.openReportIssueWindow();
        return this.getSnapshot();
    });
    electron_1.ipcMain.handle('app:open-update-download', async (_event, url) => {
        if (!(0, app_environment_1.isSafeExternalUrl)(url)) {
            return false;
        }
        await electron_1.shell.openExternal(url);
        return true;
    });
    electron_1.ipcMain.handle('app:open-release-page', async (_event, url) => {
        if (!(0, app_environment_1.isSafeExternalUrl)(url)) {
            return false;
        }
        await electron_1.shell.openExternal(url);
        return true;
    });
    electron_1.ipcMain.handle('app:open-external', async (_event, url) => {
        if (!(0, app_environment_1.isSafeExternalUrl)(url)) {
            return false;
        }
        await electron_1.shell.openExternal(url);
        return true;
    });
}
//# sourceMappingURL=app-ipc-handlers.js.map