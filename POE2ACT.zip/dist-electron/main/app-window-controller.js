"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runCreateOverlayWindow = runCreateOverlayWindow;
exports.runGetConfiguredHotkeys = runGetConfiguredHotkeys;
exports.runRegisterGlobalHotkeys = runRegisterGlobalHotkeys;
exports.runGetLocalInputAccelerator = runGetLocalInputAccelerator;
exports.runAttachManualHotkeys = runAttachManualHotkeys;
exports.runToggleSettingsWindow = runToggleSettingsWindow;
exports.runOpenSettingsWindow = runOpenSettingsWindow;
exports.runToggleCompanionWindow = runToggleCompanionWindow;
exports.runOpenCompanionWindow = runOpenCompanionWindow;
exports.runOpenInfoWindow = runOpenInfoWindow;
exports.runOpenCommunityWindow = runOpenCommunityWindow;
exports.runOpenSupportWindow = runOpenSupportWindow;
exports.runOpenReportIssueWindow = runOpenReportIssueWindow;
exports.runCreateTray = runCreateTray;
exports.runGetHotkeyTrayLabel = runGetHotkeyTrayLabel;
exports.runRefreshTrayMenu = runRefreshTrayMenu;
exports.runAppendDevSampleLine = runAppendDevSampleLine;
exports.runShowOverlayInactive = runShowOverlayInactive;
exports.runShowOverlay = runShowOverlay;
exports.runSetOverlayMode = runSetOverlayMode;
exports.runToggleOverlayMode = runToggleOverlayMode;
exports.runLoadWindowPage = runLoadWindowPage;
exports.runGetStartupOverlayMode = runGetStartupOverlayMode;
const promises_1 = require("node:fs/promises");
const node_path_1 = require("node:path");
const electron_1 = require("electron");
const runtime_paths_1 = require("./services/runtime-paths");
const defaults_1 = require("../shared/defaults");
const app_icons_1 = require("./app-icons");
const hotkey_utils_1 = require("./hotkey-utils");
const app_environment_1 = require("./app-environment");
function runCreateOverlayWindow() {
    const bounds = this.getOverlayBoundsForMode(this.overlayMode);
    const minimumSize = this.getOverlayMinimumSize(this.overlayMode);
    this.lastOverlayKnownBounds = bounds;
    this.logOverlayBoundsEvent('info', {
        phase: 'window-create',
        source: 'restoreBounds',
        from: null,
        to: bounds
    });
    this.overlayWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        ...bounds,
        frame: false,
        transparent: true,
        // Native resize is unstable with transparent frameless Electron windows on high-DPI
        // and Linux compositors. The app uses its own resize grip via setBounds instead.
        resizable: false,
        minWidth: minimumSize.width,
        minHeight: minimumSize.height,
        show: false,
        alwaysOnTop: true,
        skipTaskbar: false,
        // Keep the overlay focusable so local buttons and fallback hotkeys still work.
        // Showing is done through showInactive(), so the game should not lose focus on expand/show.
        focusable: true,
        hasShadow: false,
        backgroundColor: '#00000000',
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.overlayWindow);
    this.overlayWindow.setAlwaysOnTop(true, 'screen-saver');
    this.overlayWindow.setVisibleOnAllWorkspaces(true, {
        visibleOnFullScreen: true
    });
    this.overlayWindow.setOpacity(this.config.overlayOpacity);
    this.overlayWindow.setMenuBarVisibility(false);
    this.overlayWindow.setFocusable(true);
    this.overlayWindow.on('close', (event) => {
        if (this.isClosingOverlayWindow) {
            return;
        }
        if (!this.isQuitting) {
            event.preventDefault();
            this.overlayWindow?.hide();
        }
    });
    this.overlayWindow.on('closed', () => {
        this.overlayWindow = null;
        this.isClosingOverlayWindow = false;
        this.overlayDragInProgress = false;
        this.overlayDragBounds = null;
        this.lastOverlayKnownBounds = null;
        this.overlayBoundsSourceHint = null;
    });
    this.overlayWindow.on('move', () => {
        this.handleOverlayWindowBoundsEvent('move');
        this.persistOverlayBounds();
    });
    this.overlayWindow.on('resize', () => {
        this.handleOverlayWindowBoundsEvent('resize');
        this.persistOverlayBounds();
    });
    const overlayWindow = this.overlayWindow;
    let overlayShown = false;
    let overlayStartupFallback = null;
    const showOverlayAfterRendererBoot = () => {
        if (overlayShown || !overlayWindow || overlayWindow.isDestroyed()) {
            return;
        }
        overlayShown = true;
        if (overlayStartupFallback !== null) {
            clearTimeout(overlayStartupFallback);
            overlayStartupFallback = null;
        }
        this.showOverlayInactive();
    };
    void this.loadWindowPage(overlayWindow, 'overlay');
    overlayWindow.once('ready-to-show', showOverlayAfterRendererBoot);
    overlayWindow.webContents.once('did-finish-load', () => {
        setTimeout(showOverlayAfterRendererBoot, 50);
    });
    overlayStartupFallback = setTimeout(showOverlayAfterRendererBoot, 1500);
}
function runGetConfiguredHotkeys() {
    return {
        markChecklistDone: (0, hotkey_utils_1.formatConfiguredHotkey)(this.config.hotkeys.markChecklistDone, defaults_1.DEFAULT_HOTKEYS.markChecklistDone),
        undoChecklistMark: (0, hotkey_utils_1.formatConfiguredHotkey)(this.config.hotkeys.undoChecklistMark, defaults_1.DEFAULT_HOTKEYS.undoChecklistMark),
        toggleTimerPause: (0, hotkey_utils_1.formatConfiguredHotkey)(this.config.hotkeys.toggleTimerPause, defaults_1.DEFAULT_HOTKEYS.toggleTimerPause),
        openCompanion: (0, hotkey_utils_1.formatConfiguredHotkey)(this.config.hotkeys.openCompanion, defaults_1.DEFAULT_HOTKEYS.openCompanion),
        toggleOverlayMode: (0, hotkey_utils_1.formatConfiguredHotkey)(this.config.hotkeys.toggleOverlayMode, defaults_1.DEFAULT_HOTKEYS.toggleOverlayMode)
    };
}
function runRegisterGlobalHotkeys() {
    electron_1.globalShortcut.unregisterAll();
    this.registeredGlobalHotkeys.clear();
    this.globalHotkeysRegistered = false;
    const hotkeys = this.getConfiguredHotkeys();
    const shortcuts = [
        [
            'toggleTimerPause',
            hotkeys.toggleTimerPause,
            () => {
                if (this.config.runTimer.status === 'running') {
                    this.pauseRunTimer();
                }
                else if (this.config.runTimer.status === 'paused') {
                    this.resumeRunTimer();
                }
            }
        ],
        ['openCompanion', hotkeys.openCompanion, () => this.toggleCompanionWindow()],
        ['toggleOverlayMode', hotkeys.toggleOverlayMode, () => this.toggleOverlayMode()]
    ];
    if (this.config.manualHotkeysEnabled) {
        shortcuts.push(['markChecklistDone', hotkeys.markChecklistDone, () => this.markCurrentChecklistItemDone()], ['undoChecklistMark', hotkeys.undoChecklistMark, () => this.undoLastChecklistMark()]);
    }
    const usedAccelerators = new Map();
    for (const [action, accelerator, handler] of shortcuts) {
        const normalized = (0, hotkey_utils_1.normalizeHotkeyAccelerator)(accelerator);
        if (!normalized) {
            console.warn(`[Hotkeys] Invalid shortcut for ${action}: ${accelerator}`);
            continue;
        }
        const duplicateAction = usedAccelerators.get(normalized);
        if (duplicateAction) {
            console.warn(`[Hotkeys] Duplicate shortcut ${normalized} for ${action} and ${duplicateAction}. Skipping ${action}.`);
            continue;
        }
        usedAccelerators.set(normalized, action);
        const registered = electron_1.globalShortcut.register(normalized, () => {
            if (this.isQuitting) {
                return;
            }
            handler();
        });
        if (!registered) {
            console.warn(`[Hotkeys] Failed to register global shortcut ${normalized} (${hotkey_utils_1.HOTKEY_ACTION_LABELS[action]}). Local fallback will work when overlay is focused.`);
            continue;
        }
        this.registeredGlobalHotkeys.add(normalized);
    }
    this.globalHotkeysRegistered = this.registeredGlobalHotkeys.size > 0;
    this.refreshTrayMenu();
}
function runGetLocalInputAccelerator(input) {
    const key = String(input.key ?? '').trim();
    if (!key) {
        return null;
    }
    const parts = [];
    if (input.control || input.meta) {
        parts.push('Ctrl');
    }
    if (input.alt) {
        parts.push('Alt');
    }
    if (input.shift) {
        parts.push('Shift');
    }
    const upperKey = key.length === 1 ? key.toUpperCase() : key.toUpperCase();
    parts.push(upperKey === ' ' ? 'Space' : upperKey);
    return (0, hotkey_utils_1.normalizeHotkeyAccelerator)(parts.join('+'));
}
function runAttachManualHotkeys(window) {
    window.webContents.on('before-input-event', (event, input) => {
        if (input.type !== 'keyDown') {
            return;
        }
        const inputAccelerator = this.getLocalInputAccelerator(input);
        if (!inputAccelerator || this.registeredGlobalHotkeys.has(inputAccelerator)) {
            return;
        }
        const hotkeys = this.getConfiguredHotkeys();
        const matches = (value) => (0, hotkey_utils_1.normalizeHotkeyAccelerator)(value) === inputAccelerator;
        if (matches(hotkeys.openCompanion)) {
            event.preventDefault();
            this.toggleCompanionWindow();
            return;
        }
        if (matches(hotkeys.toggleOverlayMode)) {
            event.preventDefault();
            this.toggleOverlayMode();
            return;
        }
        if (matches(hotkeys.toggleTimerPause)) {
            event.preventDefault();
            if (this.config.runTimer.status === 'running') {
                this.pauseRunTimer();
            }
            else if (this.config.runTimer.status === 'paused') {
                this.resumeRunTimer();
            }
            return;
        }
        if (!this.config.manualHotkeysEnabled) {
            return;
        }
        if (matches(hotkeys.markChecklistDone)) {
            event.preventDefault();
            this.markCurrentChecklistItemDone();
            return;
        }
        if (matches(hotkeys.undoChecklistMark)) {
            event.preventDefault();
            this.undoLastChecklistMark();
            return;
        }
    });
}
function runToggleSettingsWindow() {
    if (this.settingsWindow && !this.settingsWindow.isDestroyed()) {
        if (this.settingsWindow.isVisible()) {
            this.settingsWindow.hide();
            return;
        }
        if (this.settingsWindow.isMinimized()) {
            this.settingsWindow.restore();
        }
        this.settingsWindow.show();
        this.settingsWindow.focus();
        return;
    }
    this.openSettingsWindow();
}
function runOpenSettingsWindow() {
    if (this.settingsWindow) {
        this.settingsWindow.show();
        this.settingsWindow.focus();
        return;
    }
    this.settingsWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        width: 760,
        height: 860,
        minWidth: 680,
        minHeight: 720,
        frame: false,
        titleBarStyle: 'hidden',
        backgroundColor: '#10161f',
        show: false,
        autoHideMenuBar: true,
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.settingsWindow);
    this.settingsWindow.on('close', (event) => {
        if (!this.isQuitting) {
            event.preventDefault();
            this.settingsWindow?.hide();
        }
    });
    this.settingsWindow.on('closed', () => {
        this.settingsWindow = null;
    });
    void this.loadWindowPage(this.settingsWindow, 'settings');
    this.settingsWindow.once('ready-to-show', () => {
        this.settingsWindow?.show();
    });
}
function runToggleCompanionWindow() {
    if (this.companionWindow && !this.companionWindow.isDestroyed()) {
        if (this.companionWindow.isVisible()) {
            this.companionWindow.hide();
            return;
        }
        if (this.companionWindow.isMinimized()) {
            this.companionWindow.restore();
        }
        this.companionWindow.show();
        this.companionWindow.focus();
        return;
    }
    this.openCompanionWindow();
}
function runOpenCompanionWindow() {
    if (this.companionWindow) {
        this.companionWindow.show();
        this.companionWindow.focus();
        return;
    }
    const bounds = this.getCompanionBounds();
    this.companionWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        ...bounds,
        minWidth: 720,
        minHeight: 520,
        resizable: true,
        show: false,
        autoHideMenuBar: true,
        backgroundColor: '#0f151d',
        alwaysOnTop: this.config.companionAlwaysOnTop,
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.companionWindow);
    this.companionWindow.on('close', (event) => {
        if (!this.isQuitting) {
            event.preventDefault();
            this.companionWindow?.hide();
        }
    });
    this.companionWindow.on('closed', () => {
        this.companionWindow = null;
    });
    this.companionWindow.on('move', () => {
        this.persistCompanionBounds();
    });
    this.companionWindow.on('resize', () => {
        this.persistCompanionBounds();
    });
    void this.loadWindowPage(this.companionWindow, 'companion');
    this.companionWindow.once('ready-to-show', () => {
        this.companionWindow?.show();
    });
}
function runOpenInfoWindow() {
    if (this.infoWindow) {
        this.infoWindow.show();
        this.infoWindow.focus();
        return;
    }
    this.infoWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        width: 760,
        height: 760,
        minWidth: 680,
        minHeight: 620,
        frame: false,
        titleBarStyle: 'hidden',
        backgroundColor: '#10161f',
        show: false,
        autoHideMenuBar: true,
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.infoWindow);
    this.infoWindow.on('close', (event) => {
        if (!this.isQuitting) {
            event.preventDefault();
            this.infoWindow?.hide();
        }
    });
    this.infoWindow.on('closed', () => {
        this.infoWindow = null;
    });
    void this.loadWindowPage(this.infoWindow, 'info');
    this.infoWindow.once('ready-to-show', () => {
        this.infoWindow?.show();
    });
}
function runOpenCommunityWindow() {
    if (this.communityWindow) {
        this.communityWindow.show();
        this.communityWindow.focus();
        return;
    }
    this.communityWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        width: 760,
        height: 680,
        minWidth: 680,
        minHeight: 560,
        frame: false,
        titleBarStyle: 'hidden',
        backgroundColor: '#10161f',
        show: false,
        autoHideMenuBar: true,
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.communityWindow);
    this.communityWindow.on('close', (event) => {
        if (!this.isQuitting) {
            event.preventDefault();
            this.communityWindow?.hide();
        }
    });
    this.communityWindow.on('closed', () => {
        this.communityWindow = null;
    });
    void this.loadWindowPage(this.communityWindow, 'community');
    this.communityWindow.once('ready-to-show', () => {
        this.communityWindow?.show();
        this.communityWindow?.focus();
    });
}
function runOpenSupportWindow() {
    if (this.supportWindow) {
        this.supportWindow.show();
        this.supportWindow.focus();
        return;
    }
    this.supportWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        width: 760,
        height: 700,
        minWidth: 680,
        minHeight: 560,
        frame: false,
        titleBarStyle: 'hidden',
        backgroundColor: '#10161f',
        show: false,
        autoHideMenuBar: true,
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.supportWindow);
    this.supportWindow.on('close', (event) => {
        if (!this.isQuitting) {
            event.preventDefault();
            this.supportWindow?.hide();
        }
    });
    this.supportWindow.on('closed', () => {
        this.supportWindow = null;
    });
    void this.loadWindowPage(this.supportWindow, 'support');
    this.supportWindow.once('ready-to-show', () => {
        this.supportWindow?.show();
        this.supportWindow?.focus();
    });
}
function runOpenReportIssueWindow() {
    if (this.reportWindow) {
        this.reportWindow.show();
        this.reportWindow.focus();
        return;
    }
    this.reportWindow = new electron_1.BrowserWindow({
        icon: (0, app_icons_1.createAppIcon)(),
        width: 820,
        height: 780,
        minWidth: 720,
        minHeight: 620,
        frame: false,
        titleBarStyle: 'hidden',
        backgroundColor: '#10161f',
        show: false,
        autoHideMenuBar: true,
        webPreferences: {
            preload: (0, node_path_1.join)(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            backgroundThrottling: false
        }
    });
    this.attachManualHotkeys(this.reportWindow);
    this.reportWindow.on('close', (event) => {
        if (!this.isQuitting) {
            event.preventDefault();
            this.reportWindow?.hide();
        }
    });
    this.reportWindow.on('closed', () => {
        this.reportWindow = null;
    });
    void this.loadWindowPage(this.reportWindow, 'report');
    this.reportWindow.once('ready-to-show', () => {
        this.reportWindow?.show();
        this.reportWindow?.focus();
    });
}
function runCreateTray() {
    this.tray = new electron_1.Tray((0, app_icons_1.createAppIcon)());
    this.tray.setToolTip(this.t('main.trayTooltip'));
    this.refreshTrayMenu();
    this.tray.on('double-click', () => {
        this.showOverlay();
    });
}
function runGetHotkeyTrayLabel() {
    const hotkeys = this.getConfiguredHotkeys();
    const segments = [];
    if (this.config.manualHotkeysEnabled) {
        segments.push(`${hotkeys.markChecklistDone} — ${this.t('main.hotkeysMark')}`);
        segments.push(`${hotkeys.undoChecklistMark} — ${this.t('main.hotkeysUndo')}`);
    }
    segments.push(`${hotkeys.toggleTimerPause} — ${this.t('main.hotkeysPause')}`);
    segments.push(`${hotkeys.openCompanion} — ${this.t('main.hotkeysCompanion')}`);
    segments.push(`${hotkeys.toggleOverlayMode} — ${this.t('main.hotkeysOverlayMode')}`);
    return `${this.t('main.hotkeysLabel')}: ${segments.join(', ')}`;
}
function runRefreshTrayMenu() {
    if (!this.tray) {
        return;
    }
    this.tray.setToolTip(this.t('main.trayTooltip'));
    const menu = electron_1.Menu.buildFromTemplate([
        {
            label: this.t('main.trayShowOverlay'),
            click: () => this.showOverlay()
        },
        {
            label: this.t('main.trayHideOverlay'),
            click: () => this.overlayWindow?.hide()
        },
        {
            label: this.t('main.trayOpenCompanion'),
            click: () => this.openCompanionWindow()
        },
        {
            label: this.t('main.traySettings'),
            click: () => this.openSettingsWindow()
        },
        { type: 'separator' },
        {
            label: this.getHotkeyTrayLabel(),
            enabled: false
        },
        {
            label: this.t('main.trayQuit'),
            click: () => {
                electron_1.app.quit();
            }
        }
    ]);
    this.tray.setContextMenu(menu);
}
async function runAppendDevSampleLine() {
    const targetPath = this.config.logFilePath ?? this.runtime.watchedLogPath;
    if (!targetPath) {
        return;
    }
    await (0, promises_1.appendFile)(targetPath, `${app_environment_1.DEV_SAMPLE_ZONE_LINE}\r\n`, 'utf8');
    await this.refreshLogFileInfo(targetPath);
    await this.logWatcher.checkNow();
    this.broadcastState();
}
function runShowOverlayInactive() {
    if (!this.overlayWindow || this.overlayWindow.isDestroyed()) {
        return;
    }
    // Show without activating the window. The overlay remains focusable for mouse buttons
    // and fallback local hotkeys, but showInactive() keeps the game focused on show/expand.
    this.overlayWindow.setFocusable(true);
    this.overlayWindow.setAlwaysOnTop(true, 'screen-saver');
    this.overlayWindow.showInactive();
}
function runShowOverlay() {
    if (!this.overlayWindow || this.overlayWindow.isDestroyed()) {
        this.createOverlayWindow();
        return;
    }
    this.showOverlayInactive();
}
function runSetOverlayMode(mode) {
    if (this.overlayMode === mode && this.runtime.overlayMode === mode) {
        return;
    }
    const previousOverlayMode = this.overlayMode;
    const previousOverlayDensity = this.config.overlayDensity;
    const previousOverlayBounds = this.overlayWindow && !this.overlayWindow.isDestroyed()
        ? this.overlayWindow.getBounds()
        : null;
    if (previousOverlayBounds) {
        if (this.overlayBoundsTimer) {
            clearTimeout(this.overlayBoundsTimer);
            this.overlayBoundsTimer = null;
        }
        this.persistOverlayBoundsForState(previousOverlayMode, previousOverlayDensity, previousOverlayBounds);
    }
    this.overlayMode = mode;
    this.runtime.overlayMode = mode;
    this.config = this.configStore.updateSettings({
        mainOverlaySettings: {
            overlayMode: mode
        }
    });
    if (this.overlayWindow && !this.overlayWindow.isDestroyed()) {
        const minimumSize = this.getOverlayMinimumSize(mode);
        const nextBounds = this.getOverlayBoundsForMode(mode);
        this.applyOverlayWindowBounds('modeSwitch', nextBounds, { minimumSize });
        this.overlayWindow.setFocusable(true);
        this.overlayWindow.setAlwaysOnTop(true, 'screen-saver');
        if (this.overlayWindow.isVisible()) {
            this.overlayWindow.showInactive();
        }
    }
    this.broadcastState();
}
function runToggleOverlayMode() {
    if (this.overlayMode === 'timer_only') {
        if (this.config.overlayDensity === 'compact') {
            this.config = this.configStore.updateSettings({
                overlayDensity: 'normal'
            });
        }
        this.setOverlayMode('full');
        return;
    }
    this.setOverlayMode('timer_only');
}
async function runLoadWindowPage(window, page) {
    if (app_environment_1.isDev) {
        try {
            await window.loadURL(`${app_environment_1.devServerUrl}/${page}.html`);
            return;
        }
        catch {
            // If Vite is not running, fall back to built files.
        }
    }
    await window.loadFile((0, runtime_paths_1.resolveRuntimePath)('dist', `${page}.html`));
}
function runGetStartupOverlayMode() {
    return this.config.mainOverlaySettings.overlayTimerOnlyMode
        ? 'timer_only'
        : this.config.mainOverlaySettings.overlayMode;
}
//# sourceMappingURL=app-window-controller.js.map