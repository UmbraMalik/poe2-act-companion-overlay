"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runGetRunTimerDisplayElapsedMs = runGetRunTimerDisplayElapsedMs;
exports.runGetCurrentZoneElapsedMs = runGetCurrentZoneElapsedMs;
exports.runGetCurrentTownElapsedMs = runGetCurrentTownElapsedMs;
exports.runGetTotalTownElapsedMs = runGetTotalTownElapsedMs;
exports.runGetCurrentTimerAct = runGetCurrentTimerAct;
exports.runGetCurrentActElapsedForDiagnostics = runGetCurrentActElapsedForDiagnostics;
exports.runBuildTimerDiagnosticsRecord = runBuildTimerDiagnosticsRecord;
exports.runLogTimerDiagnostics = runLogTimerDiagnostics;
exports.runProcessRunTimerActivityFromLogLine = runProcessRunTimerActivityFromLogLine;
exports.runClearRunTimerStartTimer = runClearRunTimerStartTimer;
exports.runPersistRunTimer = runPersistRunTimer;
exports.runScheduleRunTimerAutoStart = runScheduleRunTimerAutoStart;
exports.runReconcileRunTimerState = runReconcileRunTimerState;
exports.runArmRunTimer = runArmRunTimer;
exports.runStartRunTimerFromAnchor = runStartRunTimerFromAnchor;
exports.runStartRunTimerNow = runStartRunTimerNow;
exports.runPauseRunTimer = runPauseRunTimer;
exports.runResumeRunTimer = runResumeRunTimer;
exports.runResetRunTimer = runResetRunTimer;
exports.runFinishRunTimer = runFinishRunTimer;
exports.runFinalizeCurrentActSplit = runFinalizeCurrentActSplit;
exports.runTryRecordActSplitByAct = runTryRecordActSplitByAct;
exports.runRecordActTransitionByHint = runRecordActTransitionByHint;
exports.runTryRecordActSplit = runTryRecordActSplit;
exports.runHandleRunTimerAfterZoneEntered = runHandleRunTimerAfterZoneEntered;
exports.runProcessLevelUpFromLogLine = runProcessLevelUpFromLogLine;
exports.runStartTimerVisualHeartbeat = runStartTimerVisualHeartbeat;
exports.runStopTimerVisualHeartbeat = runStopTimerVisualHeartbeat;
exports.runEmitRunTimerState = runEmitRunTimerState;
const log_parser_1 = require("./services/log-parser");
const defaults_1 = require("../shared/defaults");
const timers_1 = require("../shared/timers");
const app_environment_1 = require("./app-environment");
function runGetRunTimerDisplayElapsedMs(now = Date.now()) {
    return (0, timers_1.getRunTimerDisplayElapsed)(this.config.runTimer, now);
}
function runGetCurrentZoneElapsedMs(now = Date.now()) {
    return (0, timers_1.getZoneTimerDisplayElapsed)(this.config.runTimer, now);
}
function runGetCurrentTownElapsedMs(_now = Date.now()) {
    return 0;
}
function runGetTotalTownElapsedMs(_now = Date.now()) {
    return 0;
}
function runGetCurrentTimerAct() {
    return this.currentZone.guide?.act ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null;
}
function runGetCurrentActElapsedForDiagnostics(now = Date.now(), currentAct = this.getCurrentTimerAct()) {
    if (typeof currentAct !== 'number') {
        return null;
    }
    const runTimer = this.config.runTimer;
    const sortedSplits = [...runTimer.actSplits]
        .filter((split) => Number.isFinite(split.act) &&
        Number.isFinite(split.elapsedMs) &&
        Number.isFinite(split.timestamp))
        .sort((left, right) => left.act - right.act || left.timestamp - right.timestamp);
    let previousTotalElapsedMs = 0;
    for (const split of sortedSplits) {
        const safeTotalElapsedMs = Math.max(previousTotalElapsedMs, split.elapsedMs);
        if (split.act === currentAct) {
            return Math.max(0, safeTotalElapsedMs - previousTotalElapsedMs);
        }
        previousTotalElapsedMs = safeTotalElapsedMs;
    }
    const highestRecordedAct = sortedSplits[sortedSplits.length - 1]?.act ?? 0;
    if ((runTimer.status === 'running' || runTimer.status === 'paused' || runTimer.status === 'finished') &&
        currentAct > highestRecordedAct &&
        !sortedSplits.some((split) => split.act === currentAct)) {
        const safeTotalElapsedMs = Math.max(previousTotalElapsedMs, this.getRunTimerDisplayElapsedMs(now));
        return Math.max(0, safeTotalElapsedMs - previousTotalElapsedMs);
    }
    return null;
}
function runBuildTimerDiagnosticsRecord(payload) {
    const now = Date.now();
    const runTimer = this.config.runTimer;
    const currentAct = payload.act ?? this.getCurrentTimerAct();
    return {
        timestamp: new Date(now).toISOString(),
        event: payload.event,
        source: payload.source,
        overlayMode: payload.overlayMode ?? this.runtime.overlayMode ?? this.overlayMode ?? null,
        zoneName: payload.zoneName ?? this.currentZone.guide?.zone_ru ?? this.currentZone.rawZoneName ?? this.runtime.lastGameplayZoneRu ?? null,
        act: currentAct,
        isRunning: payload.isRunning ?? runTimer.status === 'running',
        isPaused: payload.isPaused ?? runTimer.status === 'paused',
        totalElapsedMs: payload.totalElapsedMs ?? this.getRunTimerDisplayElapsedMs(now),
        actElapsedMs: payload.actElapsedMs ?? this.getCurrentActElapsedForDiagnostics(now, currentAct),
        expectedTickMs: payload.expectedTickMs ?? null,
        actualTickMs: payload.actualTickMs ?? null,
        tickDelayMs: payload.tickDelayMs ?? null,
        lastRenderedElapsedMs: payload.lastRenderedElapsedMs ?? null,
        currentElapsedMs: payload.currentElapsedMs ?? null,
        displayDeltaMs: payload.displayDeltaMs ?? null,
        wallClockDeltaMs: payload.wallClockDeltaMs ?? null,
        previousDisplayedText: payload.previousDisplayedText ?? null,
        nextDisplayedText: payload.nextDisplayedText ?? null,
        previousDisplayedElapsedMs: payload.previousDisplayedElapsedMs ?? null,
        nextDisplayedElapsedMs: payload.nextDisplayedElapsedMs ?? null,
        timerStatus: payload.timerStatus ?? runTimer.status,
        previousStatus: payload.previousStatus ?? null,
        nextStatus: payload.nextStatus ?? null,
        note: payload.note ?? null,
        component: payload.component ?? null,
        documentHidden: payload.documentHidden ?? null,
        visibilityState: payload.visibilityState ?? null
    };
}
function runLogTimerDiagnostics(event, payload = {}) {
    if (!this.timerDiagnosticsLog.isEnabled()) {
        return;
    }
    void this.timerDiagnosticsLog.write(this.buildTimerDiagnosticsRecord({
        ...payload,
        event
    }));
}
function runProcessRunTimerActivityFromLogLine(line, source) {
    const nowIso = new Date().toISOString();
    const zoneMatch = this.extractZoneMatchFromLogLine(line);
    if (!zoneMatch) {
        return;
    }
    const rawSceneSource = zoneMatch.rawZoneName;
    this.runtime.lastSceneSource = rawSceneSource;
    this.runtime.lastSceneSourceAt = nowIso;
    const matchedGuide = zoneMatch.guide;
    this.runtime.lastMatcherReason = zoneMatch.matcherReason;
    const ignoredReason = this.getIgnoredZoneEventReason(zoneMatch);
    if (source === 'bootstrap') {
        if (this.isTownSceneWithGuide(rawSceneSource, matchedGuide)) {
            const matchedTownGuide = rawSceneSource ? this.guideService.findByZoneName(rawSceneSource) : null;
            const nextTownGuide = matchedTownGuide ??
                (this.normalizeSceneSource(rawSceneSource) === 'clearfell encampment'
                    ? null
                    : this.currentZone.guide);
            this.currentZone = {
                rawZoneName: rawSceneSource,
                guide: nextTownGuide,
                sceneKind: 'town',
                actHint: nextTownGuide?.act ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null
            };
            this.syncRuntimeZoneFields(rawSceneSource, this.currentZone.guide);
            this.logZoneEventDecision(zoneMatch, 'updated');
        }
        else if (this.isValidGameplaySceneSource(rawSceneSource, matchedGuide)) {
            if (ignoredReason) {
                this.logZoneEventDecision(zoneMatch, 'ignored', ignoredReason);
                return;
            }
            this.currentZone = {
                rawZoneName: rawSceneSource,
                guide: matchedGuide,
                sceneKind: matchedGuide ? 'gameplay' : 'unknown',
                actHint: matchedGuide?.act ?? this.getZoneMatchActHint(zoneMatch) ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null
            };
            if (matchedGuide) {
                this.runtime.lastGameplayGuideId = matchedGuide.id;
                this.runtime.lastGameplayZoneRu = matchedGuide.zone_ru;
                this.runtime.lastGameplayAct = typeof matchedGuide.act === 'number' ? matchedGuide.act : null;
                this.runtime.lastValidGameplayZoneAt = nowIso;
            }
            this.syncRuntimeZoneFields(rawSceneSource, matchedGuide);
            this.logZoneEventDecision(zoneMatch, 'updated');
        }
        else if (this.isLoginLikeScene(rawSceneSource)) {
            this.setSceneWithoutGuide(rawSceneSource, 'log', 'login');
            this.logZoneEventDecision(zoneMatch, 'updated');
        }
        else if (this.isUnknownOrNullScene(rawSceneSource) || this.isActLabelScene(rawSceneSource)) {
            this.setSceneWithoutGuide(rawSceneSource, 'log', 'inactive');
            this.logZoneEventDecision(zoneMatch, 'updated');
        }
        else {
            this.setSceneWithoutGuide(rawSceneSource, 'log', 'unknown', this.getZoneMatchActHint(zoneMatch));
            this.logZoneEventDecision(zoneMatch, 'updated');
        }
        return;
    }
    if (this.isTownSceneWithGuide(rawSceneSource, matchedGuide)) {
        this.setTownScene(rawSceneSource ?? 'Город', 'log');
        this.logZoneEventDecision(zoneMatch, 'updated');
        return;
    }
    if (this.isValidGameplaySceneSource(rawSceneSource, matchedGuide)) {
        if (ignoredReason) {
            this.logZoneEventDecision(zoneMatch, 'ignored', ignoredReason);
            return;
        }
        this.runtime.lastValidGameplayZoneAt = nowIso;
        this.setCurrentZone(rawSceneSource ?? '', 'log', matchedGuide, this.getZoneMatchActHint(zoneMatch));
        this.logZoneEventDecision(zoneMatch, 'updated');
        return;
    }
    if (this.isLoginLikeScene(rawSceneSource)) {
        this.setSceneWithoutGuide(rawSceneSource, 'log', 'login');
        this.logZoneEventDecision(zoneMatch, 'updated');
        return;
    }
    if (this.isUnknownOrNullScene(rawSceneSource)) {
        this.setSceneWithoutGuide(rawSceneSource, 'log', 'inactive');
        this.logZoneEventDecision(zoneMatch, 'updated');
        return;
    }
    if (this.isActLabelScene(rawSceneSource)) {
        this.setSceneWithoutGuide(rawSceneSource, 'log', 'inactive');
        this.logZoneEventDecision(zoneMatch, 'updated');
        return;
    }
    this.setSceneWithoutGuide(rawSceneSource, 'log', 'unknown', this.getZoneMatchActHint(zoneMatch));
    this.logZoneEventDecision(zoneMatch, 'updated');
}
function runClearRunTimerStartTimer() {
    if (this.runTimerStartTimer) {
        clearTimeout(this.runTimerStartTimer);
        this.runTimerStartTimer = null;
    }
}
function runPersistRunTimer(nextRunTimer, diagnosticsPayload = null) {
    const previousRunTimer = this.config.runTimer;
    this.config = this.configStore.update({
        runTimer: nextRunTimer
    });
    if (diagnosticsPayload?.event) {
        this.logTimerDiagnostics(diagnosticsPayload.event, {
            ...diagnosticsPayload,
            previousStatus: diagnosticsPayload.previousStatus ?? previousRunTimer.status,
            nextStatus: diagnosticsPayload.nextStatus ?? nextRunTimer.status
        });
    }
    else if (previousRunTimer.status !== nextRunTimer.status) {
        this.logTimerDiagnostics('timer-unexpected-state', {
            source: diagnosticsPayload?.source ?? 'main.persist',
            previousStatus: previousRunTimer.status,
            nextStatus: nextRunTimer.status,
            note: diagnosticsPayload?.note ?? 'status-changed-without-explicit-diagnostics-event'
        });
    }
    this.emitRunTimerState();
}
function runScheduleRunTimerAutoStart() {
    this.clearRunTimerStartTimer();
    const { runTimer, runTimerSettings: settings } = this.config;
    if (runTimer.status !== 'armed' ||
        settings.autoStartMode !== 'scheduled_time' ||
        !settings.autoStart ||
        !settings.leagueStartAt) {
        return;
    }
    const delayMs = settings.leagueStartAt - Date.now();
    if (delayMs <= 0) {
        this.startRunTimerFromAnchor(settings.leagueStartAt, 'main.scheduled-start-immediate');
        return;
    }
    this.runTimerStartTimer = setTimeout(() => {
        this.runTimerStartTimer = null;
        this.startRunTimerFromAnchor(settings.leagueStartAt ?? Date.now(), 'main.scheduled-start-timeout');
    }, Math.min(delayMs, 2_147_483_647));
}
function runReconcileRunTimerState() {
    this.clearRunTimerStartTimer();
    const { runTimer, runTimerSettings: settings } = this.config;
    if (runTimer.status === 'running' ||
        runTimer.status === 'paused' ||
        runTimer.status === 'finished') {
        return;
    }
    if (!settings.autoStart ||
        settings.autoStartMode !== 'scheduled_time' ||
        !settings.leagueStartAt) {
        if (runTimer.status === 'armed') {
            this.persistRunTimer({
                ...defaults_1.DEFAULT_RUN_TIMER
            }, {
                source: 'main.reconcile',
                note: 'cleared-stale-armed-state'
            });
        }
        return;
    }
    const now = Date.now();
    if (runTimer.status === 'armed' && now >= settings.leagueStartAt) {
        this.startRunTimerFromAnchor(settings.leagueStartAt, 'main.reconcile-auto-start');
        return;
    }
    if (settings.leagueStartAt > now) {
        this.armRunTimer(false);
    }
}
function runArmRunTimer(shouldBroadcast = true) {
    const settings = this.config.runTimerSettings;
    if (settings.autoStartMode !== 'scheduled_time' ||
        !settings.leagueStartAt) {
        return;
    }
    const now = Date.now();
    if (settings.leagueStartAt <= now) {
        this.startRunTimerFromAnchor(settings.leagueStartAt, 'main.arm-immediate-start');
        return;
    }
    this.persistRunTimer({
        ...defaults_1.DEFAULT_RUN_TIMER,
        status: 'armed'
    }, {
        event: 'timer-arm',
        source: 'main.arm-run-timer',
        note: `league-start-at:${settings.leagueStartAt}`
    });
    this.scheduleRunTimerAutoStart();
    this.refreshTrayMenu();
    if (shouldBroadcast) {
        this.broadcastState();
    }
}
function runStartRunTimerFromAnchor(startedAt, source = 'main.start-run-timer') {
    const now = Date.now();
    const previousStatus = this.config.runTimer.status;
    this.clearRunTimerStartTimer();
    const nextTownTimer = { ...defaults_1.DEFAULT_TOWN_TIMER };
    this.config = this.configStore.update({
        zoneTimeHistory: [],
        lastRunSummary: null,
        townTimer: nextTownTimer,
        runTimer: {
            status: 'running',
            elapsedMs: Math.max(0, now - startedAt),
            startedAt,
            resumedAt: now,
            pausedAt: null,
            finishedAt: null,
            lastZoneEnteredAt: this.currentZone.sceneKind === 'gameplay' && this.currentZone.guide
                ? startedAt
                : null,
            currentZoneElapsedMs: 0,
            currentZoneStartedAt: this.currentZone.sceneKind === 'gameplay' && this.currentZone.guide
                ? startedAt
                : null,
            pauseReason: null,
            pauseCount: 0,
            actSplits: []
        }
    });
    this.emitRunTimerState();
    this.logTimerDiagnostics('timer-start', {
        source,
        previousStatus,
        nextStatus: 'running',
        note: `started-at:${startedAt}`
    });
    this.refreshTrayMenu();
    this.broadcastState();
}
function runStartRunTimerNow() {
    this.startRunTimerFromAnchor(Date.now(), 'main.manual-start');
}
function runPauseRunTimer() {
    const runTimer = this.config.runTimer;
    if (runTimer.status !== 'running' || runTimer.resumedAt === null) {
        return;
    }
    const now = Date.now();
    this.persistRunTimer(this.buildManualPausedRunTimer(now), {
        event: 'timer-pause',
        source: 'main.manual-pause'
    });
    this.refreshTrayMenu();
    this.broadcastState();
}
function runResumeRunTimer() {
    const runTimer = this.config.runTimer;
    if (runTimer.status !== 'paused') {
        return;
    }
    const now = Date.now();
    this.persistRunTimer({
        ...runTimer,
        status: 'running',
        resumedAt: now,
        pausedAt: null,
        lastZoneEnteredAt: this.currentZone.sceneKind === 'gameplay' && this.currentZone.guide
            ? now
            : null,
        pauseReason: null
    }, {
        event: 'timer-resume',
        source: 'main.manual-resume'
    });
    this.refreshTrayMenu();
    this.broadcastState();
}
function runResetRunTimer() {
    this.clearRunTimerStartTimer();
    const previousStatus = this.config.runTimer.status;
    const shouldClearPastLeagueStart = typeof this.config.runTimerSettings.leagueStartAt === 'number' &&
        this.config.runTimerSettings.leagueStartAt <= Date.now();
    this.config = this.configStore.update({
        ignoreExistingLogOnNextStart: true,
        runTimer: {
            ...defaults_1.DEFAULT_RUN_TIMER
        },
        townTimer: {
            ...defaults_1.DEFAULT_TOWN_TIMER
        },
        runTimerSettings: {
            ...this.config.runTimerSettings,
            autoStart: false,
            leagueStartAt: shouldClearPastLeagueStart
                ? null
                : this.config.runTimerSettings.leagueStartAt,
            leagueStartTimeLabel: shouldClearPastLeagueStart
                ? null
                : this.config.runTimerSettings.leagueStartTimeLabel
        },
        zoneTimeHistory: [],
        lastRunSummary: null
    });
    this.emitRunTimerState();
    this.logTimerDiagnostics('timer-reset', {
        source: 'main.reset-run-timer',
        previousStatus,
        nextStatus: 'not_started'
    });
    this.refreshTrayMenu();
    this.broadcastState();
}
function runFinishRunTimer() {
    const runTimer = this.config.runTimer;
    if (runTimer.status !== 'running' &&
        runTimer.status !== 'paused') {
        return;
    }
    const now = Date.now();
    this.clearRunTimerStartTimer();
    if (this.config.townTimer.isInTown) {
        this.closeTownVisit(now);
    }
    this.recordZoneTimeEntry(this.currentZone.guide, now);
    const elapsedMs = this.getRunTimerDisplayElapsedMs(now);
    const finalizedActSplits = this.finalizeCurrentActSplit(runTimer, now);
    const nextRunTimer = {
        ...runTimer,
        status: 'finished',
        elapsedMs,
        resumedAt: null,
        pausedAt: runTimer.status === 'paused' ? runTimer.pausedAt : now,
        finishedAt: now,
        lastZoneEnteredAt: null,
        currentZoneElapsedMs: this.getCurrentZoneElapsedMs(now),
        pauseReason: null,
        actSplits: finalizedActSplits
    };
    const previousPb = this.config.bestRun;
    const isNewPb = previousPb === null || elapsedMs < previousPb.totalElapsedMs;
    const nextBestRun = isNewPb
        ? {
            totalElapsedMs: elapsedMs,
            finishedAt: now,
            actSplits: [...nextRunTimer.actSplits]
        }
        : previousPb;
    this.config = this.configStore.update({
        runTimer: nextRunTimer,
        bestRun: nextBestRun,
        lastRunSummary: {
            ...this.buildRunSummary(nextRunTimer, elapsedMs, now),
            isNewPb
        }
    });
    this.emitRunTimerState();
    this.logTimerDiagnostics('timer-finish', {
        source: 'main.finish-run-timer',
        previousStatus: runTimer.status,
        nextStatus: 'finished',
        totalElapsedMs: elapsedMs,
        note: isNewPb ? 'new-pb' : 'finished'
    });
    this.refreshTrayMenu();
    this.broadcastState();
}
function runFinalizeCurrentActSplit(runTimer, now) {
    const currentAct = this.currentZone.guide?.act ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null;
    if (typeof currentAct !== 'number') {
        return [...runTimer.actSplits];
    }
    if (runTimer.actSplits.some((split) => split.act === currentAct)) {
        return [...runTimer.actSplits];
    }
    const highestRecordedAct = [...runTimer.actSplits]
        .sort((left, right) => right.act - left.act)[0]?.act ?? 0;
    if (currentAct < highestRecordedAct) {
        return [...runTimer.actSplits];
    }
    return [
        ...runTimer.actSplits,
        {
            act: currentAct,
            elapsedMs: this.getRunTimerDisplayElapsedMs(now),
            timestamp: now
        }
    ];
}
function runTryRecordActSplitByAct(previousAct, nextAct, now) {
    const runTimer = this.config.runTimer;
    if (runTimer.status !== 'running' ||
        typeof previousAct !== 'number' ||
        typeof nextAct !== 'number' ||
        nextAct === previousAct ||
        nextAct < previousAct ||
        runTimer.actSplits.some((split) => split.act === previousAct)) {
        return null;
    }
    return [
        ...runTimer.actSplits,
        {
            act: previousAct,
            elapsedMs: this.getRunTimerDisplayElapsedMs(now),
            timestamp: now
        }
    ];
}
function runRecordActTransitionByHint(previousAct, nextAct, now) {
    const nextSplits = this.tryRecordActSplitByAct(previousAct, nextAct, now);
    if (!nextSplits) {
        return;
    }
    this.persistRunTimer({
        ...this.config.runTimer,
        actSplits: nextSplits
    }, {
        event: 'timer-act-change',
        source: 'main.act-hint-transition',
        act: nextAct,
        note: `from:${previousAct ?? 'unknown'} to:${nextAct ?? 'unknown'}`
    });
}
function runTryRecordActSplit(previousGuide, nextGuide, now) {
    const runTimer = this.config.runTimer;
    if (runTimer.status !== 'running' ||
        !previousGuide ||
        !nextGuide ||
        typeof previousGuide.act !== 'number' ||
        typeof nextGuide.act !== 'number' ||
        nextGuide.act === previousGuide.act ||
        nextGuide.act < previousGuide.act ||
        runTimer.actSplits.some((split) => split.act === previousGuide.act)) {
        return null;
    }
    return [
        ...runTimer.actSplits,
        {
            act: previousGuide.act,
            elapsedMs: this.getRunTimerDisplayElapsedMs(now),
            timestamp: now
        }
    ];
}
function runHandleRunTimerAfterZoneEntered(previousGuide, nextGuide, now) {
    const runTimer = this.config.runTimer;
    this.recordZoneTimeEntry(previousGuide, now);
    const nextSplits = this.tryRecordActSplit(previousGuide, nextGuide, now);
    let shouldPersist = false;
    let nextRunTimer = runTimer;
    if (nextSplits) {
        nextRunTimer = {
            ...nextRunTimer,
            actSplits: nextSplits
        };
        shouldPersist = true;
    }
    if (runTimer.status === 'running') {
        nextRunTimer = {
            ...nextRunTimer,
            lastZoneEnteredAt: now,
            currentZoneElapsedMs: 0
        };
        shouldPersist = true;
    }
    else if (runTimer.currentZoneElapsedMs !== 0 || runTimer.lastZoneEnteredAt !== null) {
        nextRunTimer = {
            ...nextRunTimer,
            currentZoneElapsedMs: 0,
            lastZoneEnteredAt: null
        };
        shouldPersist = true;
    }
    if (shouldPersist) {
        this.persistRunTimer(nextRunTimer, nextSplits
            ? {
                event: 'timer-act-change',
                source: 'main.zone-act-transition',
                act: nextGuide?.act ?? null,
                note: previousGuide && nextGuide
                    ? `from:${previousGuide.act}:${previousGuide.zone_ru} to:${nextGuide.act}:${nextGuide.zone_ru}`
                    : 'act-transition'
            }
            : {
                event: 'timer-zone-change',
                source: 'main.zone-timer-reset',
                act: nextGuide?.act ?? null,
                zoneName: nextGuide?.zone_ru ?? this.currentZone.rawZoneName ?? null,
                note: previousGuide && nextGuide
                    ? `from:${previousGuide.zone_ru} to:${nextGuide.zone_ru}`
                    : 'zone-timer-reset'
            });
    }
}
function runProcessLevelUpFromLogLine(line, source) {
    const parsedLevelUp = (0, log_parser_1.parseLevelUp)(line);
    if (parsedLevelUp === null) {
        return;
    }
    const level = parsedLevelUp.level;
    const previousLevel = this.config.currentLevel;
    const changed = previousLevel !== level;
    if (!changed) {
        return;
    }
    this.config = this.configStore.update({
        currentLevel: level
    });
    this.runtime.lastLevelUpDetectedAt = new Date().toISOString();
    if (source !== 'append') {
        this.broadcastState();
        return;
    }
    const state = this.config.levelRemindersState;
    const reminder = this.guideService.findVendorCheckpointByLevel(level);
    if (!reminder) {
        this.broadcastState();
        return;
    }
    if (state.shown.includes(reminder.id) ||
        state.dismissed.includes(reminder.id)) {
        this.broadcastState();
        return;
    }
    this.config = this.configStore.update({
        levelRemindersState: {
            shown: [...state.shown, reminder.id],
            dismissed: state.dismissed,
            activeLevelReminderId: reminder.id
        }
    });
    this.broadcastState();
}
function runStartTimerVisualHeartbeat() {
    this.stopTimerVisualHeartbeat();
    this.timerVisualHeartbeat = setInterval(() => {
        const overlayWindow = this.overlayWindow;
        if (!overlayWindow || overlayWindow.isDestroyed()) {
            return;
        }
        if (overlayWindow.webContents.isDestroyed()) {
            return;
        }
        const now = Date.now();
        if (this.lastTimerVisualHeartbeatSentAtMs !== null) {
            const actualTickMs = Math.max(0, now - this.lastTimerVisualHeartbeatSentAtMs);
            const tickDelayMs = Math.max(0, actualTickMs - app_environment_1.TIMER_VISUAL_HEARTBEAT_MS);
            if (tickDelayMs > app_environment_1.TIMER_DIAGNOSTICS_TICK_DELAY_THRESHOLD_MS) {
                this.logTimerDiagnostics('timer-tick-delay', {
                    source: 'main.visual-heartbeat',
                    expectedTickMs: app_environment_1.TIMER_VISUAL_HEARTBEAT_MS,
                    actualTickMs,
                    tickDelayMs,
                    note: 'main-thread-stall-symptom'
                });
            }
        }
        this.lastTimerVisualHeartbeatSentAtMs = now;
        overlayWindow.webContents.send('timer:visual-tick', {
            now
        });
    }, app_environment_1.TIMER_VISUAL_HEARTBEAT_MS);
    if (typeof this.timerVisualHeartbeat?.unref === 'function') {
        this.timerVisualHeartbeat.unref();
    }
}
function runStopTimerVisualHeartbeat() {
    if (!this.timerVisualHeartbeat) {
        return;
    }
    clearInterval(this.timerVisualHeartbeat);
    this.timerVisualHeartbeat = null;
    this.lastTimerVisualHeartbeatSentAtMs = null;
}
function runEmitRunTimerState() {
    for (const win of [this.overlayWindow, this.settingsWindow, this.companionWindow, this.infoWindow, this.communityWindow, this.supportWindow]) {
        if (win && !win.isDestroyed()) {
            win.webContents.send('timer:state-changed', this.config.runTimer);
        }
    }
}
//# sourceMappingURL=app-timer-controller.js.map