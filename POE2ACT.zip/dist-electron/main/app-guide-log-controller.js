"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runLoadGuide = runLoadGuide;
exports.runRestoreLastZoneFromConfig = runRestoreLastZoneFromConfig;
exports.runRebindCurrentZoneAfterGuideReload = runRebindCurrentZoneAfterGuideReload;
exports.runEnsureLogFile = runEnsureLogFile;
exports.runFindAutoLogFile = runFindAutoLogFile;
exports.runIsReadable = runIsReadable;
exports.runClearLogFileInfoRefreshTimer = runClearLogFileInfoRefreshTimer;
exports.runScheduleLogFileInfoRefresh = runScheduleLogFileInfoRefresh;
exports.runRefreshLogFileInfo = runRefreshLogFileInfo;
exports.runStartLogWatcher = runStartLogWatcher;
exports.runSetCurrentZone = runSetCurrentZone;
exports.runHandleZoneLeave = runHandleZoneLeave;
exports.runSetSceneWithoutGuide = runSetSceneWithoutGuide;
exports.runSetTownScene = runSetTownScene;
exports.runRecordVisitedZone = runRecordVisitedZone;
exports.runOpenTownVisit = runOpenTownVisit;
exports.runCloseTownVisit = runCloseTownVisit;
exports.runHandleRunTimerAfterTownEntered = runHandleRunTimerAfterTownEntered;
exports.runRecordZoneTimeEntry = runRecordZoneTimeEntry;
exports.runCollectVisitedGuides = runCollectVisitedGuides;
exports.runBuildRunSummary = runBuildRunSummary;
exports.runGetActiveLevelReminder = runGetActiveLevelReminder;
exports.runNormalizeSceneSource = runNormalizeSceneSource;
exports.runGetZoneMatchActHint = runGetZoneMatchActHint;
exports.runGetFallbackActHintForScene = runGetFallbackActHintForScene;
exports.runIsUnknownOrNullScene = runIsUnknownOrNullScene;
exports.runIsActLabelScene = runIsActLabelScene;
exports.runIsLoginLikeScene = runIsLoginLikeScene;
exports.runIsTownScene = runIsTownScene;
exports.runIsTownSceneWithGuide = runIsTownSceneWithGuide;
exports.runIsValidGameplaySceneSource = runIsValidGameplaySceneSource;
exports.runGetIgnoredZoneEventReason = runGetIgnoredZoneEventReason;
exports.runLogZoneEventDecision = runLogZoneEventDecision;
exports.runShouldKeepPendingZoneAreaId = runShouldKeepPendingZoneAreaId;
exports.runExtractZoneMatchFromLogLine = runExtractZoneMatchFromLogLine;
const promises_1 = require("node:fs/promises");
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const electron_1 = require("electron");
const log_parser_1 = require("./services/log-parser");
const scene_classifier_1 = require("./scene-classifier");
const diagnostic_logger_1 = require("./diagnostic-logger");
function runLoadGuide() {
    try {
        this.guideService.load();
        this.runtime.guideLoadedAt = this.guideService.getLoadedAt();
    }
    catch (error) {
        const message = error instanceof Error && error.message
            ? `${this.t('main.guideLoadError')}: ${error.message}`
            : this.t('main.guideLoadError');
        this.setLogStatus('error', message);
    }
}
function runRestoreLastZoneFromConfig() {
    if (!this.config.lastZoneName) {
        return;
    }
    this.currentZone = {
        rawZoneName: this.config.lastZoneName,
        guide: this.guideService.findByZoneName(this.config.lastZoneName),
        sceneKind: this.guideService.findByZoneName(this.config.lastZoneName)
            ? 'gameplay'
            : 'unknown',
        actHint: this.guideService.findByZoneName(this.config.lastZoneName)?.act ?? null
    };
    this.syncRuntimeZoneFields(this.config.lastZoneName, this.currentZone.guide);
    this.runtime.lastZoneSource = 'config';
}
function runRebindCurrentZoneAfterGuideReload() {
    const currentGuideId = this.currentZone.guide?.id ?? this.runtime.lastMatchedGuideId;
    const reboundGuide = this.guideService.findById(currentGuideId) ??
        this.guideService.findByZoneName(this.currentZone.rawZoneName);
    this.currentZone = {
        rawZoneName: this.currentZone.rawZoneName,
        guide: reboundGuide,
        sceneKind: this.currentZone.sceneKind === 'town' || this.currentZone.sceneKind === 'login'
            ? this.currentZone.sceneKind
            : reboundGuide
                ? 'gameplay'
                : this.currentZone.sceneKind,
        actHint: reboundGuide?.act ?? this.currentZone.actHint
    };
    this.syncRuntimeZoneFields(this.currentZone.rawZoneName, this.currentZone.guide);
}
async function runEnsureLogFile() {
    if (this.config.logFilePath) {
        const shouldPreservePath = this.config.logFileSelectionMode !== 'auto';
        if (shouldPreservePath || (await this.isReadable(this.config.logFilePath))) {
            await this.refreshLogFileInfo(this.config.logFilePath);
            return;
        }
    }
    const discoveredPath = await this.findAutoLogFile();
    if (discoveredPath) {
        this.config = this.configStore.update({
            logFilePath: discoveredPath,
            logFileSelectionMode: 'auto'
        });
        await this.refreshLogFileInfo(discoveredPath);
        return;
    }
    this.config = this.configStore.update({
        logFilePath: this.config.logFileSelectionMode === 'manual' ? this.config.logFilePath : null,
        logFileSelectionMode: this.config.logFileSelectionMode === 'manual'
            ? 'manual'
            : null
    });
    await this.refreshLogFileInfo(this.config.logFilePath);
    if (!this.config.logFilePath) {
        this.setLogStatus('missing', this.t('system.logWatcher.missingManual'));
    }
}
async function runFindAutoLogFile() {
    const documents = electron_1.app.getPath('documents');
    const baseDirectories = [
        (0, node_path_1.join)(documents, 'My Games', 'Path of Exile 2', 'logs'),
        (0, node_path_1.join)(documents, 'My Games', 'Path of Exile 2'),
        'C:\\Program Files (x86)\\Steam\\steamapps\\common\\Path of Exile 2\\logs',
        'C:\\Program Files\\Steam\\steamapps\\common\\Path of Exile 2\\logs',
        'E:\\Steam\\steamapps\\common\\Path of Exile 2\\logs'
    ];
    const fileNamesByPriority = ['LatestClient.txt', 'Client.txt'];
    const candidates = fileNamesByPriority.flatMap((fileName) => baseDirectories.map((directory) => (0, node_path_1.join)(directory, fileName)));
    for (const candidate of candidates) {
        if (await this.isReadable(candidate)) {
            return candidate;
        }
    }
    return null;
}
async function runIsReadable(filePath) {
    try {
        await (0, promises_1.access)(filePath, node_fs_1.constants.R_OK);
        return true;
    }
    catch {
        return false;
    }
}
function runClearLogFileInfoRefreshTimer() {
    if (this.logInfoRefreshTimer) {
        clearTimeout(this.logInfoRefreshTimer);
        this.logInfoRefreshTimer = null;
    }
}
function runScheduleLogFileInfoRefresh() {
    if (this.isQuitting) {
        return;
    }
    this.clearLogFileInfoRefreshTimer();
    this.logInfoRefreshTimer = setTimeout(() => {
        this.logInfoRefreshTimer = null;
        void this.refreshLogFileInfo();
    }, 250);
}
async function runRefreshLogFileInfo(filePath = this.config.logFilePath) {
    const nextPath = filePath ?? null;
    let nextExists = false;
    let nextSize = null;
    if (nextPath) {
        try {
            const fileStat = await (0, promises_1.stat)(nextPath);
            if (fileStat.isFile()) {
                nextExists = true;
                nextSize = fileStat.size;
            }
        }
        catch {
            nextExists = false;
            nextSize = null;
        }
    }
    const hasChanges = this.runtime.logFileExists !== nextExists ||
        this.runtime.logFileSize !== nextSize;
    this.runtime.logFileExists = nextExists;
    this.runtime.logFileSize = nextSize;
    if (hasChanges) {
        this.broadcastState();
    }
}
async function runStartLogWatcher(filePath, skipBootstrap = false) {
    await this.refreshLogFileInfo(filePath);
    this.pendingZoneAreaId = null;
    await this.logWatcher.start(filePath, { skipBootstrap });
    if (skipBootstrap && this.config.ignoreExistingLogOnNextStart) {
        this.config = this.configStore.update({
            ignoreExistingLogOnNextStart: false
        });
    }
    this.scheduleLogFileInfoRefresh();
    this.broadcastState();
}
function runSetCurrentZone(rawZoneName, source, guide = this.guideService.findByZoneName(rawZoneName), actHint = null) {
    if (!guide) {
        this.setSceneWithoutGuide(rawZoneName, source, 'gameplay', actHint);
        return;
    }
    const now = Date.now();
    const previousGuide = this.currentZone.guide;
    const previousGuideId = previousGuide?.id ?? null;
    const nextGuideId = guide.id;
    const sceneChanged = this.currentZone.sceneKind !== 'gameplay' ||
        previousGuideId !== nextGuideId;
    if (previousGuide && previousGuideId !== nextGuideId) {
        this.handleZoneLeave(previousGuide);
    }
    else if (!previousGuide) {
        this.clearMissedWarning();
    }
    this.currentZone = {
        rawZoneName,
        guide,
        sceneKind: 'gameplay',
        actHint: guide.act
    };
    this.runtime.lastGameplayGuideId = guide.id;
    this.runtime.lastGameplayZoneRu = guide.zone_ru;
    this.runtime.lastGameplayAct = guide.act;
    this.runtime.lastValidGameplayZoneAt = new Date().toISOString();
    this.syncRuntimeZoneFields(rawZoneName, guide);
    this.runtime.lastZoneSource = source;
    this.updateZoneProgress(guide);
    this.config = this.configStore.update({
        lastZoneName: guide.zone_ru
    });
    if (sceneChanged) {
        this.recordVisitedZone(guide, now);
        this.handleRunTimerAfterZoneEntered(previousGuide, guide, now);
    }
    this.broadcastState();
}
function runHandleZoneLeave(_previousGuide) {
    // Do not mark missed rewards anymore. The overlay is a guide/reminder,
    // not a pass/fail checklist.
    this.clearMissedWarning();
}
function runSetSceneWithoutGuide(rawZoneName, source, sceneKind, actHint = null) {
    const now = Date.now();
    const previousActHint = this.currentZone.guide?.act ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null;
    const nextActHint = this.getFallbackActHintForScene(sceneKind, actHint);
    const previousRawZoneName = this.currentZone.rawZoneName;
    this.currentZone = {
        rawZoneName,
        guide: sceneKind === 'gameplay' || sceneKind === 'unknown' ? null : this.currentZone.guide,
        sceneKind,
        actHint: nextActHint
    };
    if ((sceneKind === 'gameplay' || sceneKind === 'unknown') && typeof nextActHint === 'number') {
        this.runtime.lastGameplayAct = nextActHint;
        this.runtime.lastValidGameplayZoneAt = new Date(now).toISOString();
        this.recordActTransitionByHint(previousActHint, nextActHint, now);
    }
    this.syncRuntimeZoneFields(rawZoneName, this.currentZone.guide);
    this.runtime.lastZoneSource = source;
    this.config = this.configStore.update({
        lastZoneName: rawZoneName
    });
    const runTimer = this.config.runTimer;
    if ((sceneKind === 'gameplay' || sceneKind === 'unknown' || sceneKind === 'town') &&
        previousRawZoneName !== rawZoneName &&
        (runTimer.status === 'running' ||
            runTimer.status === 'paused' ||
            runTimer.status === 'finished' ||
            runTimer.lastZoneEnteredAt !== null ||
            runTimer.currentZoneElapsedMs !== 0)) {
        this.logTimerDiagnostics('timer-zone-change', {
            source: `main.scene-${sceneKind}`,
            zoneName: rawZoneName ?? null,
            act: nextActHint,
            note: `zone-source:${source ?? 'unknown'}`
        });
    }
    this.broadcastState();
}
function runSetTownScene(rawZoneName, source) {
    const now = Date.now();
    const sceneChanged = this.currentZone.rawZoneName !== rawZoneName ||
        this.currentZone.sceneKind !== 'town';
    const matchedTownGuide = rawZoneName ? this.guideService.findByZoneName(rawZoneName) : null;
    const nextTownGuide = matchedTownGuide ??
        (this.normalizeSceneSource(rawZoneName) === 'clearfell encampment'
            ? null
            : this.currentZone.guide);
    // Town/hub scenes are part of the run. Do not pause timers and do not
    // start separate town tracking.
    this.currentZone = {
        rawZoneName,
        guide: nextTownGuide,
        sceneKind: 'town',
        actHint: nextTownGuide?.act ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null
    };
    this.syncRuntimeZoneFields(rawZoneName, this.currentZone.guide);
    this.runtime.lastZoneSource = source;
    this.updateZoneProgress(this.currentZone.guide);
    this.config = this.configStore.update({
        lastZoneName: rawZoneName
    });
    const runTimer = this.config.runTimer;
    if (sceneChanged) {
        if (runTimer.status === 'running' || runTimer.status === 'paused' || runTimer.status === 'finished') {
            this.logTimerDiagnostics('timer-zone-change', {
                source: 'main.zone-town',
                zoneName: rawZoneName ?? null,
                act: this.currentZone.actHint,
                note: nextTownGuide?.id ?? 'town-without-guide'
            });
        }
    }
    this.broadcastState();
}
function runRecordVisitedZone(guide, enteredAt) {
    const existing = this.config.visitedZones.find((entry) => entry.zoneId === guide.id);
    const nextVisitedZones = existing
        ? this.config.visitedZones.map((entry) => entry.zoneId === guide.id
            ? {
                ...entry,
                lastEnteredAt: enteredAt,
                visitCount: entry.visitCount + 1
            }
            : entry)
        : [
            ...this.config.visitedZones,
            {
                zoneId: guide.id,
                zone_ru: guide.zone_ru,
                act: guide.act,
                firstEnteredAt: enteredAt,
                lastEnteredAt: enteredAt,
                visitCount: 1
            }
        ];
    this.config = this.configStore.update({
        visitedZones: nextVisitedZones
    });
}
function runOpenTownVisit(_townName, _now) {
    // Town timer removed: towns are not tracked separately.
}
function runCloseTownVisit(_now) {
    // Town timer removed: nothing to close.
}
function runHandleRunTimerAfterTownEntered(_now) {
    // Towns no longer close or pause the active gameplay zone timer.
    // We keep only the global run timer and act splits in the UI.
}
function runRecordZoneTimeEntry(guide, now) {
    const runTimer = this.config.runTimer;
    const enteredAt = runTimer.lastZoneEnteredAt ??
        (runTimer.pausedAt !== null
            ? Math.max(0, runTimer.pausedAt - runTimer.currentZoneElapsedMs)
            : null);
    if (!guide || enteredAt === null) {
        return;
    }
    const elapsedMs = runTimer.status === 'running'
        ? this.getCurrentZoneElapsedMs(now)
        : runTimer.currentZoneElapsedMs;
    if (elapsedMs <= 0) {
        return;
    }
    const nextEntry = {
        zoneId: guide.id,
        zone_ru: guide.zone_ru,
        act: guide.act,
        elapsedMs,
        enteredAt,
        leftAt: now
    };
    const previousEntry = this.config.zoneTimeHistory[this.config.zoneTimeHistory.length - 1];
    if (previousEntry &&
        previousEntry.zoneId === nextEntry.zoneId &&
        previousEntry.enteredAt === nextEntry.enteredAt) {
        return;
    }
    this.config = this.configStore.update({
        zoneTimeHistory: [...this.config.zoneTimeHistory, nextEntry]
    });
}
function runCollectVisitedGuides() {
    const visitedIds = new Set(this.config.visitedZones.map((entry) => entry.zoneId));
    return this.guideService
        .getAll()
        .filter((guide) => guide.id === this.currentZone.guide?.id || visitedIds.has(guide.id));
}
function runBuildRunSummary(runTimer, totalElapsedMs, finishedAt) {
    const longestZones = [...this.config.zoneTimeHistory]
        .sort((left, right) => right.elapsedMs - left.elapsedMs)
        .slice(0, 5);
    const previousPb = this.config.bestRun;
    const isNewPb = previousPb === null || totalElapsedMs < previousPb.totalElapsedMs;
    return {
        totalElapsedMs,
        finishedAt,
        actSplits: [...runTimer.actSplits],
        missedRequiredRewards: [],
        skippedRequiredItems: [],
        unfinishedChecklistItems: [],
        pauseCount: runTimer.pauseCount,
        longestZones,
        townTimeTotalMs: 0,
        isNewPb
    };
}
function runGetActiveLevelReminder() {
    return this.guideService.findVendorCheckpointById(this.config.levelRemindersState.activeLevelReminderId);
}
function runNormalizeSceneSource(rawSceneSource) {
    return (0, scene_classifier_1.normalizeSceneText)(rawSceneSource);
}
function runGetZoneMatchActHint(zoneMatch) {
    return zoneMatch?.guide?.act ?? (0, scene_classifier_1.inferActHintFromInternalAreaId)(zoneMatch?.extractedInternalAreaId) ?? null;
}
function runGetFallbackActHintForScene(sceneKind, explicitActHint = null) {
    if (explicitActHint !== null && explicitActHint !== undefined) {
        return explicitActHint;
    }
    if (sceneKind === 'gameplay' || sceneKind === 'unknown' || sceneKind === 'town') {
        return this.currentZone.guide?.act ?? this.currentZone.actHint ?? this.runtime.lastGameplayAct ?? null;
    }
    return this.currentZone.actHint;
}
function runIsUnknownOrNullScene(rawSceneSource) {
    return (0, scene_classifier_1.isUnknownOrNullScene)(rawSceneSource);
}
function runIsActLabelScene(rawSceneSource) {
    return (0, scene_classifier_1.isActLabelScene)(rawSceneSource);
}
function runIsLoginLikeScene(rawSceneSource) {
    return (0, scene_classifier_1.isLoginLikeScene)(rawSceneSource);
}
function runIsTownScene(rawSceneSource) {
    return this.isTownSceneWithGuide(rawSceneSource, rawSceneSource ? this.guideService.findByZoneName(rawSceneSource) : null);
}
function runIsTownSceneWithGuide(rawSceneSource, guide) {
    return (0, scene_classifier_1.isTownSceneWithGuide)(rawSceneSource, guide);
}
function runIsValidGameplaySceneSource(rawSceneSource, guide = rawSceneSource ? this.guideService.findByZoneName(rawSceneSource) : null) {
    return (0, scene_classifier_1.isValidGameplaySceneSource)(rawSceneSource, guide);
}
function runGetIgnoredZoneEventReason(zoneMatch) {
    const currentGuideId = this.currentZone.guide?.id ?? null;
    const matchedGuideId = zoneMatch.guide?.id ?? null;
    if (matchedGuideId &&
        currentGuideId === matchedGuideId &&
        this.currentZone.sceneKind === 'gameplay') {
        return `same guide zone already active (${matchedGuideId})`;
    }
    // If the log names a gameplay scene but we do not have a guide entry for it,
    // do not keep the previous guide zone. Show an explicit “no info for this location”
    // state instead, so the overlay does not lie about the current location.
    return null;
}
function runLogZoneEventDecision(zoneMatch, action, reason = null) {
    (0, diagnostic_logger_1.diagnosticInfo)('ZoneEvent', 'Processed zone event', {
        rawLine: zoneMatch.rawLine,
        extractedInternalAreaId: zoneMatch.extractedInternalAreaId,
        extractedZoneName: zoneMatch.extractedZoneName,
        normalizedZoneName: zoneMatch.normalizedZoneName,
        source: zoneMatch.source,
        matchedGuideZoneId: zoneMatch.guide?.id ?? null,
        matchedGuideZoneRu: zoneMatch.guide?.zone_ru ?? null,
        currentZoneUpdated: action === 'updated',
        currentZoneIgnored: action === 'ignored',
        reason: reason ?? null
    });
}
function runShouldKeepPendingZoneAreaId(zoneName) {
    return (0, scene_classifier_1.shouldKeepPendingZoneAreaId)(zoneName);
}
function runExtractZoneMatchFromLogLine(line) {
    const trimmedLine = String(line ?? '').replace(/\u0000/g, '').trim();
    if (!trimmedLine) {
        return null;
    }
    const extractedInternalAreaId = (0, log_parser_1.extractGeneratedAreaId)(trimmedLine)?.trim() ?? null;
    if (extractedInternalAreaId) {
        this.pendingZoneAreaId = extractedInternalAreaId;
    }
    const extractedZoneName = (0, log_parser_1.extractNamedZoneFromLine)(trimmedLine)?.trim() ?? null;
    if (extractedZoneName) {
        const zoneMatch = this.guideService.resolveZoneMatch({
            rawLine: trimmedLine,
            extractedInternalAreaId: this.pendingZoneAreaId,
            extractedZoneName
        });
        if (!this.shouldKeepPendingZoneAreaId(extractedZoneName)) {
            this.pendingZoneAreaId = null;
        }
        return zoneMatch;
    }
    return this.guideService.extractZoneMatchFromLine(trimmedLine);
}
//# sourceMappingURL=app-guide-log-controller.js.map