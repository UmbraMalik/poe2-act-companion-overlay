"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runLogOverlayBoundsEvent = runLogOverlayBoundsEvent;
exports.runGetOverlayBoundsSourceHint = runGetOverlayBoundsSourceHint;
exports.runSetOverlayBoundsSourceHint = runSetOverlayBoundsSourceHint;
exports.runApplyOverlayWindowBounds = runApplyOverlayWindowBounds;
exports.runHandleOverlayWindowBoundsEvent = runHandleOverlayWindowBoundsEvent;
exports.runGetOverlayMinimumSize = runGetOverlayMinimumSize;
exports.runGetOverlayMaximumOffscreenX = runGetOverlayMaximumOffscreenX;
exports.runGetOverlayMinimumVisibleWidth = runGetOverlayMinimumVisibleWidth;
exports.runGetOverlayMinimumVisibleHeight = runGetOverlayMinimumVisibleHeight;
exports.runGetOverlayScaledDefaultBounds = runGetOverlayScaledDefaultBounds;
exports.runGetOverlayVirtualWorkArea = runGetOverlayVirtualWorkArea;
exports.runNormalizeOverlayBoundsForMode = runNormalizeOverlayBoundsForMode;
exports.runIsBoundsVisible = runIsBoundsVisible;
exports.runGetFullOverlayFallbackBounds = runGetFullOverlayFallbackBounds;
exports.runGetTimerOnlyOverlayFallbackBounds = runGetTimerOnlyOverlayFallbackBounds;
exports.runGetCompactOverlayFallbackBounds = runGetCompactOverlayFallbackBounds;
exports.runGetSavedOverlayBoundsForState = runGetSavedOverlayBoundsForState;
exports.runGetFallbackOverlayBoundsForState = runGetFallbackOverlayBoundsForState;
exports.runGetOverlayBoundsForMode = runGetOverlayBoundsForMode;
exports.runGetCompanionBounds = runGetCompanionBounds;
exports.runPersistOverlayBoundsForState = runPersistOverlayBoundsForState;
exports.runPersistOverlayBoundsForCurrentState = runPersistOverlayBoundsForCurrentState;
exports.runPersistOverlayBoundsImmediately = runPersistOverlayBoundsImmediately;
exports.runPersistOverlayBounds = runPersistOverlayBounds;
exports.runPersistCompanionBounds = runPersistCompanionBounds;
const electron_1 = require("electron");
const defaults_1 = require("../shared/defaults");
const overlay_layout_1 = require("../shared/overlay-layout");
const overlay_window_bounds_1 = require("./overlay-window-bounds");
const diagnostic_logger_1 = require("./diagnostic-logger");
function runLogOverlayBoundsEvent(level, payload) {
    if (level === 'warn') {
        (0, diagnostic_logger_1.diagnosticWarn)('OverlayBounds', 'Bounds event', payload);
        return;
    }
    (0, diagnostic_logger_1.diagnosticInfo)('OverlayBounds', 'Bounds event', payload);
}
function runGetOverlayBoundsSourceHint() {
    if (!this.overlayBoundsSourceHint) {
        return null;
    }
    if (Date.now() > this.overlayBoundsSourceHint.expiresAt) {
        this.overlayBoundsSourceHint = null;
        return null;
    }
    return this.overlayBoundsSourceHint;
}
function runSetOverlayBoundsSourceHint(source, applyMode) {
    this.overlayBoundsSourceHint = {
        source,
        applyMode,
        expiresAt: Date.now() + 250
    };
}
function runApplyOverlayWindowBounds(source, requestedBounds, options = {}) {
    const targetWindow = this.overlayWindow;
    if (!targetWindow || targetWindow.isDestroyed()) {
        return null;
    }
    const plan = (0, overlay_window_bounds_1.planOverlayBoundsChange)({
        source,
        currentBounds: targetWindow.getBounds(),
        requestedBounds
    });
    const shouldHintWindowEvent = Boolean(options.minimumSize) || plan.applyMode !== 'none';
    if (shouldHintWindowEvent) {
        this.setOverlayBoundsSourceHint(source, plan.applyMode === 'none' ? 'setBounds' : plan.applyMode);
    }
    if (options.minimumSize) {
        targetWindow.setMinimumSize(options.minimumSize.width, options.minimumSize.height);
    }
    this.logOverlayBoundsEvent(plan.suspiciousSizeChange ? 'warn' : 'info', {
        phase: 'request',
        source,
        applyMode: plan.applyMode,
        from: plan.currentBounds,
        requested: plan.requestedBounds,
        to: plan.nextBounds
    });
    if (plan.applyMode === 'none') {
        this.lastOverlayKnownBounds = plan.currentBounds;
        return plan.currentBounds;
    }
    if (plan.applyMode === 'setPosition') {
        targetWindow.setPosition(plan.nextBounds.x, plan.nextBounds.y);
        return plan.nextBounds;
    }
    targetWindow.setBounds(plan.nextBounds);
    return plan.nextBounds;
}
function runHandleOverlayWindowBoundsEvent(eventName) {
    const targetWindow = this.overlayWindow;
    if (!targetWindow || targetWindow.isDestroyed()) {
        return;
    }
    const nextBounds = targetWindow.getBounds();
    const previousBounds = this.lastOverlayKnownBounds ?? nextBounds;
    if ((0, overlay_window_bounds_1.areOverlayBoundsEqual)(previousBounds, nextBounds)) {
        this.lastOverlayKnownBounds = nextBounds;
        return;
    }
    const hint = this.getOverlayBoundsSourceHint();
    let source = hint?.source ?? 'unknown';
    const sizeChanged = !(0, overlay_window_bounds_1.areOverlayBoundsSizeEqual)(previousBounds, nextBounds);
    if ((eventName === 'resize' && source === 'dragMove' && hint?.applyMode === 'setPosition') ||
        (sizeChanged && source === 'dragMove')) {
        source = 'unknown';
    }
    const suspiciousSizeChange = sizeChanged && !(0, overlay_window_bounds_1.canSourceChangeOverlaySize)(source);
    this.logOverlayBoundsEvent(suspiciousSizeChange ? 'warn' : 'info', {
        phase: 'window-event',
        eventName,
        source,
        hintSource: hint?.source ?? null,
        hintApplyMode: hint?.applyMode ?? null,
        from: previousBounds,
        to: nextBounds
    });
    this.lastOverlayKnownBounds = nextBounds;
    if (this.overlayDragInProgress &&
        this.overlayDragBounds &&
        !(0, overlay_window_bounds_1.areOverlayBoundsSizeEqual)(nextBounds, this.overlayDragBounds)) {
        const correctedBounds = {
            x: nextBounds.x,
            y: nextBounds.y,
            width: this.overlayDragBounds.width,
            height: this.overlayDragBounds.height
        };
        this.logOverlayBoundsEvent('warn', {
            phase: 'drag-size-correction',
            source: 'unknown',
            from: nextBounds,
            to: correctedBounds
        });
        this.applyOverlayWindowBounds('unknown', correctedBounds);
    }
}
function runGetOverlayMinimumSize(mode, density = this.config.overlayDensity, scale = this.config.overlayScale) {
    return (0, overlay_layout_1.getOverlayMinimumSize)(mode, density, scale);
}
function runGetOverlayMaximumOffscreenX(width) {
    return Math.min(120, Math.round(width * 0.35));
}
function runGetOverlayMinimumVisibleWidth(width) {
    return Math.min(width, Math.max(120, Math.min(160, Math.round(width * 0.4))));
}
function runGetOverlayMinimumVisibleHeight(height) {
    return Math.min(height, 120);
}
function runGetOverlayScaledDefaultBounds(mode, density = this.config.overlayDensity) {
    const minimumSize = this.getOverlayMinimumSize(mode, density);
    if (mode === 'timer_only') {
        return {
            width: Math.max(minimumSize.width, Math.round((defaults_1.DEFAULT_TIMER_ONLY_OVERLAY_BOUNDS.width * this.config.overlayScale) / 100)),
            height: Math.max(minimumSize.height, Math.round((defaults_1.DEFAULT_TIMER_ONLY_OVERLAY_BOUNDS.height * this.config.overlayScale) / 100))
        };
    }
    if (density === 'compact') {
        return {
            width: Math.max(minimumSize.width, Math.round((defaults_1.DEFAULT_COMPACT_OVERLAY_BOUNDS.width * this.config.overlayScale) / 100)),
            height: Math.max(minimumSize.height, Math.round((defaults_1.DEFAULT_COMPACT_OVERLAY_BOUNDS.height * this.config.overlayScale) / 100))
        };
    }
    return {
        width: Math.max(minimumSize.width, Math.round((defaults_1.DEFAULT_OVERLAY_BOUNDS.width * this.config.overlayScale) / 100)),
        height: Math.max(minimumSize.height, Math.round((defaults_1.DEFAULT_OVERLAY_BOUNDS.height * this.config.overlayScale) / 100))
    };
}
function runGetOverlayVirtualWorkArea() {
    const displays = electron_1.screen.getAllDisplays();
    if (displays.length === 0) {
        return electron_1.screen.getPrimaryDisplay().workArea;
    }
    const left = Math.min(...displays.map((display) => display.workArea.x));
    const top = Math.min(...displays.map((display) => display.workArea.y));
    const right = Math.max(...displays.map((display) => display.workArea.x + display.workArea.width));
    const bottom = Math.max(...displays.map((display) => display.workArea.y + display.workArea.height));
    return {
        x: left,
        y: top,
        width: right - left,
        height: bottom - top
    };
}
function runNormalizeOverlayBoundsForMode(bounds, mode, density = this.config.overlayDensity) {
    const minimumSize = this.getOverlayMinimumSize(mode, density);
    const roundedBounds = {
        x: Math.round(bounds.x),
        y: Math.round(bounds.y),
        width: Math.round(bounds.width),
        height: Math.round(bounds.height)
    };
    const display = electron_1.screen.getDisplayMatching(roundedBounds);
    const area = display.workArea;
    const virtualArea = this.getOverlayVirtualWorkArea();
    const width = Math.min(Math.max(minimumSize.width, area.width), Math.max(minimumSize.width, roundedBounds.width));
    const height = Math.min(Math.max(minimumSize.height, area.height - 16), Math.max(minimumSize.height, roundedBounds.height));
    const minVisibleWidth = this.getOverlayMinimumVisibleWidth(width);
    const minVisibleHeight = this.getOverlayMinimumVisibleHeight(height);
    const minX = virtualArea.x - this.getOverlayMaximumOffscreenX(width);
    const maxX = virtualArea.x + virtualArea.width - minVisibleWidth;
    const minY = virtualArea.y;
    const maxY = virtualArea.y + virtualArea.height - minVisibleHeight;
    return {
        x: Math.min(Math.max(roundedBounds.x, minX), Math.max(minX, maxX)),
        y: Math.min(Math.max(roundedBounds.y, minY), Math.max(minY, maxY)),
        width,
        height
    };
}
function runIsBoundsVisible(bounds) {
    return electron_1.screen.getAllDisplays().some((display) => {
        const area = display.workArea;
        const intersectionWidth = Math.min(bounds.x + bounds.width, area.x + area.width) - Math.max(bounds.x, area.x);
        const intersectionHeight = Math.min(bounds.y + bounds.height, area.y + area.height) - Math.max(bounds.y, area.y);
        return (intersectionWidth >= this.getOverlayMinimumVisibleWidth(bounds.width) &&
            intersectionHeight >= this.getOverlayMinimumVisibleHeight(bounds.height));
    });
}
function runGetFullOverlayFallbackBounds() {
    const fallbackDisplay = electron_1.screen.getPrimaryDisplay();
    const fallbackWorkArea = fallbackDisplay.workArea;
    const defaultBounds = this.getOverlayScaledDefaultBounds('full', 'normal');
    return {
        x: fallbackWorkArea.x + Math.max(20, fallbackWorkArea.width - defaultBounds.width - 40),
        y: fallbackWorkArea.y + 80,
        width: defaultBounds.width,
        height: defaultBounds.height
    };
}
function runGetTimerOnlyOverlayFallbackBounds() {
    const baseBounds = this.config.overlayBounds ?? this.getFullOverlayFallbackBounds();
    const defaultBounds = this.getOverlayScaledDefaultBounds('timer_only');
    return {
        x: baseBounds.x,
        y: baseBounds.y,
        width: Math.max(this.getOverlayMinimumSize('timer_only').width, Math.min(baseBounds.width, defaultBounds.width)),
        height: defaultBounds.height
    };
}
function runGetCompactOverlayFallbackBounds() {
    const baseBounds = this.config.overlayBounds ?? this.getFullOverlayFallbackBounds();
    const defaultBounds = this.getOverlayScaledDefaultBounds('full', 'compact');
    return {
        x: baseBounds.x,
        y: baseBounds.y,
        width: Math.max(this.getOverlayMinimumSize('full', 'compact').width, Math.min(baseBounds.width, defaultBounds.width)),
        height: Math.max(this.getOverlayMinimumSize('full', 'compact').height, Math.min(baseBounds.height, defaultBounds.height))
    };
}
function runGetSavedOverlayBoundsForState(mode, density = this.config.overlayDensity) {
    if (mode === 'timer_only') {
        return this.config.overlayTimerOnlyBounds;
    }
    if (density === 'compact') {
        return this.config.overlayCompactBounds;
    }
    return this.config.overlayBounds;
}
function runGetFallbackOverlayBoundsForState(mode, density = this.config.overlayDensity) {
    if (mode === 'timer_only') {
        return this.getTimerOnlyOverlayFallbackBounds();
    }
    if (density === 'compact') {
        return this.getCompactOverlayFallbackBounds();
    }
    return this.getFullOverlayFallbackBounds();
}
function runGetOverlayBoundsForMode(mode, density = this.config.overlayDensity) {
    const saved = this.getSavedOverlayBoundsForState(mode, density);
    const fallbackBounds = this.getFallbackOverlayBoundsForState(mode, density);
    if (!saved || !this.isBoundsVisible(saved)) {
        return this.normalizeOverlayBoundsForMode(fallbackBounds, mode, density);
    }
    return this.normalizeOverlayBoundsForMode({
        x: saved.x,
        y: saved.y,
        width: saved.width,
        height: saved.height
    }, mode, density);
}
function runGetCompanionBounds() {
    const fallbackDisplay = electron_1.screen.getPrimaryDisplay();
    const fallbackWorkArea = fallbackDisplay.workArea;
    const fallbackBounds = {
        x: Math.max(0, fallbackWorkArea.x + Math.floor((fallbackWorkArea.width - defaults_1.DEFAULT_COMPANION_BOUNDS.width) / 2)),
        y: Math.max(20, fallbackWorkArea.y + 60),
        width: defaults_1.DEFAULT_COMPANION_BOUNDS.width,
        height: defaults_1.DEFAULT_COMPANION_BOUNDS.height
    };
    const saved = this.config.companionBounds;
    if (!saved) {
        return fallbackBounds;
    }
    const visibleOnSomeDisplay = electron_1.screen.getAllDisplays().some((display) => {
        const area = display.workArea;
        return (saved.x < area.x + area.width - 80 &&
            saved.x + saved.width > area.x + 80 &&
            saved.y < area.y + area.height - 80 &&
            saved.y + saved.height > area.y + 80);
    });
    if (!visibleOnSomeDisplay) {
        return fallbackBounds;
    }
    return {
        x: saved.x,
        y: saved.y,
        width: Math.max(720, saved.width),
        height: Math.max(520, saved.height)
    };
}
function runPersistOverlayBoundsForState(mode, density, bounds) {
    if (mode === 'timer_only') {
        this.config = this.configStore.setOverlayTimerOnlyBounds(bounds);
        return;
    }
    this.config = density === 'compact'
        ? this.configStore.setOverlayCompactBounds(bounds)
        : this.configStore.setOverlayBounds(bounds);
}
function runPersistOverlayBoundsForCurrentState(bounds) {
    this.persistOverlayBoundsForState(this.overlayMode, this.config.overlayDensity, bounds);
}
function runPersistOverlayBoundsImmediately() {
    if (!this.overlayWindow || this.overlayWindow.isDestroyed()) {
        return;
    }
    if (this.overlayBoundsTimer) {
        clearTimeout(this.overlayBoundsTimer);
        this.overlayBoundsTimer = null;
    }
    this.persistOverlayBoundsForCurrentState(this.overlayWindow.getBounds());
}
function runPersistOverlayBounds() {
    if (!this.overlayWindow) {
        return;
    }
    if (this.overlayBoundsTimer) {
        clearTimeout(this.overlayBoundsTimer);
    }
    this.overlayBoundsTimer = setTimeout(() => {
        if (!this.overlayWindow || this.overlayWindow.isDestroyed()) {
            return;
        }
        const bounds = this.overlayWindow.getBounds();
        this.persistOverlayBoundsForCurrentState(bounds);
        this.broadcastState();
    }, 350);
}
function runPersistCompanionBounds() {
    if (!this.companionWindow) {
        return;
    }
    if (this.companionBoundsTimer) {
        clearTimeout(this.companionBoundsTimer);
    }
    this.companionBoundsTimer = setTimeout(() => {
        if (!this.companionWindow || this.companionWindow.isDestroyed()) {
            return;
        }
        const bounds = this.companionWindow.getBounds();
        this.config = this.configStore.setCompanionBounds(bounds);
        this.broadcastState();
    }, 350);
}
//# sourceMappingURL=app-overlay-bounds-controller.js.map