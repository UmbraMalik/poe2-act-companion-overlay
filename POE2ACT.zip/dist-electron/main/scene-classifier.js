"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeSceneText = normalizeSceneText;
exports.inferActHintFromInternalAreaId = inferActHintFromInternalAreaId;
exports.isUnknownOrNullScene = isUnknownOrNullScene;
exports.isActLabelScene = isActLabelScene;
exports.isLoginLikeScene = isLoginLikeScene;
exports.isTownSceneWithGuide = isTownSceneWithGuide;
exports.isValidGameplaySceneSource = isValidGameplaySceneSource;
exports.shouldKeepPendingZoneAreaId = shouldKeepPendingZoneAreaId;
const town_scenes_json_1 = __importDefault(require("../data/town-scenes.json"));
const TOWN_ZONE_HINTS = ['encampment', 'camp', 'town', 'hideout', 'лагерь', 'город', 'убежище'];
const NON_GAMEPLAY_SCENES = new Set([
    '(null)',
    '(unknown)',
    'null',
    'unknown',
    'акт 1',
    'акт 2',
    'акт 3',
    'акт 4',
    'акт 5',
    'логин',
    'login',
    'меню',
    'menu'
]);
const LOGIN_SCENE_HINTS = [
    'логин',
    'login',
    'меню',
    'menu',
    'character select',
    'character selection',
    'select character',
    'screen login',
    'login screen'
];
const PENDING_AREA_ID_HOLD_SCENES = new Set([
    '(null)',
    '(unknown)',
    'null',
    'unknown',
    'act 1',
    'act 2',
    'act 3',
    'act 4',
    'act 5',
    'акт 1',
    'акт 2',
    'акт 3',
    'акт 4',
    'акт 5',
    'interlude',
    'интерлюдия'
]);
const TOWN_SCENES = new Set((Array.isArray(town_scenes_json_1.default) ? town_scenes_json_1.default : [])
    .map((entry) => normalizeSceneText(String(entry ?? '')))
    .filter(Boolean));
function normalizeSceneText(input) {
    return String(input ?? '')
        .toLowerCase()
        .replace(/\u0451/g, 'е')
        .trim();
}
function inferActHintFromInternalAreaId(areaId) {
    const normalized = normalizeSceneText(areaId).replace(/^c_/, '');
    if (/^g1(?:_|$)/.test(normalized)) {
        return 1;
    }
    if (/^g2(?:_|$)/.test(normalized)) {
        return 2;
    }
    if (/^g3(?:_|$)/.test(normalized)) {
        return 3;
    }
    if (/^g4(?:_|$)/.test(normalized)) {
        return 4;
    }
    if (/^g5(?:_|$)/.test(normalized) || /^p[123](?:_|$)/.test(normalized)) {
        return 5;
    }
    return null;
}
function isUnknownOrNullScene(rawSceneSource) {
    const normalized = normalizeSceneText(rawSceneSource);
    return normalized === '(null)' || normalized === '(unknown)' || normalized === 'null' || normalized === 'unknown';
}
function isActLabelScene(rawSceneSource) {
    const normalized = normalizeSceneText(rawSceneSource);
    return /^акт\s+\d+$/.test(normalized) || /^act\s+\d+$/.test(normalized);
}
function isLoginLikeScene(rawSceneSource) {
    const normalized = normalizeSceneText(rawSceneSource);
    return Boolean(normalized) && LOGIN_SCENE_HINTS.some((hint) => normalized.includes(hint));
}
function isTownSceneWithGuide(rawSceneSource, guide) {
    const normalized = normalizeSceneText(rawSceneSource);
    if (!normalized || guide) {
        return false;
    }
    if (TOWN_SCENES.has(normalized)) {
        return true;
    }
    return TOWN_ZONE_HINTS.some((hint) => normalized.includes(hint));
}
function isValidGameplaySceneSource(rawSceneSource, guide) {
    const normalized = normalizeSceneText(rawSceneSource);
    if (!normalized) {
        return false;
    }
    if (isTownSceneWithGuide(rawSceneSource, guide)) {
        return false;
    }
    if (guide) {
        return true;
    }
    if (NON_GAMEPLAY_SCENES.has(normalized)) {
        return false;
    }
    if (isActLabelScene(rawSceneSource) || isLoginLikeScene(rawSceneSource)) {
        return false;
    }
    return true;
}
function shouldKeepPendingZoneAreaId(zoneName) {
    return PENDING_AREA_ID_HOLD_SCENES.has(normalizeSceneText(zoneName));
}
//# sourceMappingURL=scene-classifier.js.map